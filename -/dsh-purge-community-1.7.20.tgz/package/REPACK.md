# 重打包说明

本包是 **dsh-purge-community 1.7.20** 的原样重打包，仅去掉 docs/test/market/packages 与 scripts 字段，代码未改，用于自建静态注册表安装。

## 上游与作者

- **kingcharleslzy-ai** — dsh-purge Community 维护：https://github.com/kingcharleslzy-ai/dsh-purge
- **YuJunZhiXue** — dsh-purge 原始作者
- **NANA7MI0** — dsh-go 适配线：https://github.com/NANA7MI0/dsh-purge-go

## 许可与声明

见 LICENSE / NOTICE.md。本项目免费，收费代装与作者无关。仅供个人学习研究，使用后果自负。
