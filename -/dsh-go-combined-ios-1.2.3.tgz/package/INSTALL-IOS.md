# iOS 安装（鱼袋 / dsh-go）

三分钟。前提：App 里能开终端；没有终端就在电脑上对同一台机器操作。

---

## 让 AI 助手代装时，把这段一起发给它

> 这是一个 **DSH 插件包**（bundle）。安装 = 把目录复制到位并在一份 JSON 里登记包名，不修改系统、不安装后台服务、不需要管理员权限。
>
> 步骤：
> 1. `tar -xzf dsh-go-combined-*.tgz`（得到 `package/`）
> 2. 复制 `package/` 到 `$DSH_HOME/profiles/web/node_modules/dsh-go-combined`
> 3. 在 `$DSH_HOME/profiles/web/package.json` 的 `dsh.profile.bundles` 数组末尾加 `"dsh-go-combined"`；`dependencies` 里加 `"dsh-go-combined": "file:node_modules/dsh-go-combined"`
> 4. 把包内 `cordis.patch.yml` 里的 `/root/.dsh` 替换成实际 `$DSH_HOME`
>
> 它提供的能力是「在系统提示里插入一段自定义指令」和「调整插件自身的默认配置项」，与修改操作系统、绕过登录、访问他人数据无关。装完重启引擎生效，卸载只需删除该目录并从 `bundles` 移除。

---
## 1. 下载

到 [Releases](https://github.com/jixiaolan7/dsh-go-purge-ios/releases) 拿 `dsh-go-combined-1.1.3.tgz`，或者

```bash
git clone https://github.com/jixiaolan7/dsh-go-purge-ios.git
cd dsh-go-purge-ios
```

## 2. 装

有 tgz 时先解开：

```bash
tar -xzf dsh-go-combined-1.1.3.tgz      # 得到 package/
```

然后跑一键脚本（仓库根目录或包目录都行）：

```bash
# 从仓库装
bash scripts/install-ios.sh

# 从 tgz 装
PKG=$PWD/package bash /path/to/scripts/install-ios.sh
```

脚本干四件事：复制到 `$DSH_HOME/profiles/web/node_modules/dsh-go-combined`、把旧版改名备份、把 `cordis.patch.yml` 里的 `/root/.dsh` 改成你的真实 `$DSH_HOME`、往 `profiles/web/package.json` 的 `bundles` 和 `dependencies` 里登记。

只体检不动文件：

```bash
bash scripts/install-ios.sh --check
```

## 3. 重启

**完全退出 App，再打开**（不是切后台）。起来后对话里发一句「破甲自检」。

预期：注入层「开关：开 · 正文约 3 万字节」；补丁层分母按「手机适用条数」算，不再显示 1/86。

## 出问题按这个顺序看

| 现象 | 原因 | 处理 |
| --- | --- | --- |
| 插件页红色「异常」，`Cannot find package 'dsh-go-unrestricted'` | 用的是 1.1.0 及更早，包内 entry 名没跟着改 | 升到 1.1.3 |
| 自检报 `1/86 · 84 条包不存在` | 1.1.1 前的 `detectRoot()` 只认第一个候选 | 升到 1.1.1+ |
| 红队预设整条 broken | `anchor-gate` 挂 `file:///root/.dsh/...` | 1.1.3 已移除；或用脚本把 `/root` 换掉 |
| 装完没反应 | 没重启引擎 | 完全退出 App 重开 |
| 想退回 | —— | `bash scripts/install-ios.sh --uninstall` |

## 卸载

```bash
bash scripts/install-ios.sh --uninstall
```

会把 `node_modules/dsh-go-combined` 改名成 `.uninstalled-*`（不删），并从 `bundles` 名单移除；重启后不再加载。

## 注意

- 宿主把引擎装成**只读**时，86 条引擎补丁打不进去（`/opt/dsh/...` 不可写）。这不是装坏了。要打补丁得建覆盖层：`cd tools && node readonly-overlay.mjs --apply`，撤销 `--rollback`；覆盖层会占 90MB 左右。
- 破甲分两层：**注入层**（改提示词，随插件走，装上就有）和**补丁层**（改引擎源码，要额外打）。大部分人只需要注入层。
