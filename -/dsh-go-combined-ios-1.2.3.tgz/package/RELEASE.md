# 发布到 GitHub

这台机器上没有 `git`（`dsh` 的运行环境也没装），所以发布不走 `git push`，走 **GitHub REST API**：
`tools/publish-github.mjs` 用 fetch 逐文件 base64 上传、建 tag、建 Release、再把 `dist/install.sh` 挂成附件。

## 一次发布

```bash
# 1. 先在本地把安装器重新生成一遍（改过 lib/ 就必须重跑，install.sh 内嵌了所有文件）
node tools/make-installer.mjs
node tools/verify-installer.mjs     # 期望：OK：46 个文件逐字节一致…

# 2. 看一眼要传什么，不写远端
node tools/publish-github.mjs --dry-run

# 3. 真发
GITHUB_TOKEN=ghp_xxxxxxxx node tools/publish-github.mjs
```

Windows PowerShell 里：

```powershell
$env:Path = "C:\Users\A1799\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin;" + $env:Path
$env:GITHUB_TOKEN = "ghp_xxxxxxxx"
node tools\publish-github.mjs
```

## token 要什么权限

| 类型 | 需要的权限 |
| --- | --- |
| classic PAT | `repo`（公开仓库也要，因为要建仓库 + 建 release） |
| fine-grained PAT | `Contents: Read and write`、`Administration: Read and write`（建仓库用）、`Metadata: Read`（自动带上） |

token 只在本进程里用，不落盘、不写进任何文件。

## 常用参数

```bash
node tools/publish-github.mjs --repo my-fork --private
node tools/publish-github.mjs --tag v1.3.4 --message "hotfix: #74 锚点"
node tools/publish-github.mjs --owner someoneelse     # 默认从 token 的 /user 取
```

幂等：仓库在就复用、文件内容一致就跳过、Release 同 tag 存在就复用、`install.sh` 附件已挂就跳过。
所以改完代码重跑一次就是增量更新，不会产生重复 tag。

## 发什么、不发什么

`tools/publish-github.mjs` 的 `INCLUDE_DIRS` / `INCLUDE_FILES` 就是白名单，当前 65 个文件 / 约 1.4 MB：

- `lib/**`（33）、`presets/**`（三套模板 + anchor-gate）、`test/**`、`tools/**`
- `package.json`、`cordis.patch.yml`（71 KB，生成的）、`README.md`、`CHANGELOG.md`、`LICENSE`、`.gitignore`、`install-presets.sh`
- `dist/install.sh`（657 KB，手机端只要这一个文件）

不进仓库的：`tutorial/`、根目录那两个教程 zip、`dist/*.zip|docx|pdf`、`_reports/`、`_*.mjs` 临时脚本（`.gitignore` 里也挡了一层）。

## 手机端装法（Release 说明里写的就是这段）

```bash
cp /sdcard/Download/install.sh /root/ && cd /root && bash install.sh
bash /root/.dsh/dsh-go/plugins/dsh-go-unrestricted/install-presets.sh --force
```

装完彻底关掉 dsh-go 再打开；面板在「对话详情 → 插件」页签、全部功能页、或输入框上方胶囊行最后一枚「插件」。

## 没有 git 时的备选

1. **网页拖拽**：GitHub 仓库页 → Add file → Upload files → 把 `dist/dsh-go-unrestricted-1.3.3.zip` 解压后拖进去（一次能传 100 个文件，65 个够）。
2. **curl + API**（分步版）：

```bash
# 建仓库
curl -sS -X POST https://api.github.com/user/repos \
  -H "Authorization: Bearer $GITHUB_TOKEN" \
  -H "Accept: application/vnd.github+json" \
  -d '{"name":"dsh-go-unrestricted","description":"DSH 破甲插件","private":false}'

# 传一个文件
CONTENT=$(base64 -w0 README.md)
curl -sS -X PUT https://api.github.com/repos/OWNER/dsh-go-unrestricted/contents/README.md \
  -H "Authorization: Bearer $GITHUB_TOKEN" \
  -H "Content-Type: application/json" \
  -d "{\"message\":\"add README\",\"content\":\"$CONTENT\",\"branch\":\"main\"}"
```

3. **装个 git 再说**：`winget install --id Git.Git -e` 或下载 MinGit 便携包解压到 `D:\dsh\_git\mingit`，然后把 `cmd` 目录加进 PATH。本机实测从 GitHub Releases 下 MinGit（45 MB）速度只有 ~6 KB/s，两小时都下不完，所以当前选的是 API 路线。国内网络可以换 `https://mirrors.tuna.tsinghua.edu.cn/github-release/git-for-windows/git/` 或 npmmirror 的 git 镜像。
