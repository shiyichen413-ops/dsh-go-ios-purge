# 分发渠道与固定链接（dsh-go-unrestricted 1.3.12）

> 背景：2026-11-15 16:18 起 Gitee 账号 `lingsmallcode` 被停用，仓库与 `latest` 链接全部失效（403/404）。
> 本文件记录「下一个固定链接放哪、怎么校验、失效了怎么补」。

## 工件与校验基准

工件（每次重新构建后数值会变，所以校验值不写死在这里，避免自指）：

| 文件 | 说明 |
| --- | --- |
| `dist/install.sh` | 单文件安装器，内嵌插件全部源码 + 文档 |
| `dsh-go-unrestricted-<version>.tgz` | npm 包（`npm pack` 产物） |

校验方式：与本目录一起分发的 `SHA256SUMS` 比对——

```bash
sha256sum -c SHA256SUMS        # 期望输出：install.sh: OK
```

本机副本（不会因为平台封号消失）：
- `/sdcard/Download/DSH-Go/install-1.3.12.sh`
- `/sdcard/Download/DSH-Go/dsh-go-unrestricted-1.3.9.tgz`
- `/sdcard/Download/DSH-Go/SHA256SUMS`

## 候选渠道实测（本机网络，2026-11-15）

| 渠道 | 可达 | 是否需要账号 | 链接是否永久 | 结论 |
| --- | --- | --- | --- | --- |
| Gitee 现账号 | 站点可达 | 有（已被停用） | — | 不可用 |
| npm registry | ✅ 2.2s | 需要 token（免费注册） | ✅ 版本不可变，长期 | **推荐** |
| Codeberg | ✅ 0.9s（Gitea API 17.0.0） | 需要 token | ✅ raw / 发行版附件 | 备选 |
| gitcode.com | ✅ 1.6s | 需要账号 | ✅ | 备选 |
| catbox.moe | ❌ 连接被重置 | 不需要 | 号称永久 | 不可用 |
| 0x0.st | ❌ uploads disabled（AI spam） | 不需要 | 1 年 | 不可用 |
| x0.at | ❌ IP 被封 | 不需要 | 1 年 | 不可用 |
| envs.sh | ❌ 域名已挂牌出售 | — | — | 不可用 |
| file.coffee | ❌ 已变成停放页 | — | — | 不可用 |
| gofile.io / tmpfiles / transfer.sh | ❌ 连接重置/超时 | 不需要 | 短期 | 不可用 |
| litterbox / temp.sh / uguu | 短期可用（1–72h） | 不需要 | ❌ | 只适合临时传 |
| file.io | ✅ 但一次性下载 | 不需要 | ❌ | 不适合 |
| mediafire / 1fichier / send.cm | ❌ 403 / 不可达 | 需要 | — | 不可用 |
| huggingface / gitlab / jsdelivr | ❌ 超时 | 需要 | — | 当前网络不可用 |

**结论：本机网络下「匿名 + 永久 + 可下载」三者不可兼得。** 要固定链接就必须落在一个账号下；推荐 npm。



## 已上线的固定直链（阿里云 OSS 公开桶，2026-11-15）

桶：`dshgo` · 地域 华东1（杭州）· 读写权限 **公共读** · 默认域名 `dshgo.oss-cn-hangzhou.aliyuncs.com`

| 用途 | 链接 |
| --- | --- |
| **安装器（固定直链，推荐）** | `https://dshgo.oss-cn-hangzhou.aliyuncs.com/install.sh` |
| 校验值 | `https://dshgo.oss-cn-hangzhou.aliyuncs.com/SHA256SUMS` |
| 说明页 | `https://dshgo.oss-cn-hangzhou.aliyuncs.com/index.html` |
| 完整说明（分享用） | `https://dshgo.oss-cn-hangzhou.aliyuncs.com/guide.md` · `.../%E4%BD%BF%E7%94%A8%E8%AF%B4%E6%98%8E.md` |
| 单文件校验值 | `https://dshgo.oss-cn-hangzhou.aliyuncs.com/install.sh.sha256` |

实测（2026-11-15 18:31 复验 5 个对象全部与本地一致）：HTTP 200 · `Content-Type: application/x-sh` · 751400 字节 ·
sha256 `085812e85be8663ad50ba12fbdcd0404c8fae771e86b9d920f43f2eb8b73f976` · `bash -n` 通过。

用法：
```bash
# 直接装
bash <(curl -s https://dshgo.oss-cn-hangzhou.aliyuncs.com/install.sh)
# 或先下载再校验
node -e "fetch('https://dshgo.oss-cn-hangzhou.aliyuncs.com/install.sh').then(r=>r.arrayBuffer()).then(b=>require('fs').writeFileSync('/root/install.sh',Buffer.from(b)))"
sha256sum /root/install.sh && bash /root/install.sh
```

维护约定：
- **升级只覆盖桶里同一个对象名 `install.sh`，链接永远不变**；历史版本另存 `install-<ver>.sh`。
- `SHA256SUMS` 同步更新。
- 桶根路径 `https://dshgo.oss-cn-hangzhou.aliyuncs.com/` 默认 403（公共读不含 ListBucket）；
  要让根路径直接出说明页，需在桶「基础设置 → 静态页面」里把默认首页设为 `index.html`。

## 已停用：npm（2026-11-15 账号被暂停）

> `lingsmall` 账号因 `dsh-go-unrestricted@1.3.9` 被判恶意软件而暂停，发布权限已冻结。
> 以下信息仅作记录，链接不可用。

## 原 npm 链接（已停用）

包名：`dsh-go-unrestricted`（账号 `lingsmall`，MIT，公开）

| 用途 | 链接 |
| --- | --- |
| 版本 tarball（永久、不可变） | `https://registry.npmjs.org/dsh-go-unrestricted/-/dsh-go-unrestricted-1.3.9.tgz` |
| 元数据 / 最新版 | `https://registry.npmjs.org/dsh-go-unrestricted` |
| 包主页 | `https://www.npmjs.com/package/dsh-go-unrestricted` |
| 国内镜像（同步后可用） | `https://registry.npmmirror.com/dsh-go-unrestricted` |

安装：
```bash
npm i dsh-go-unrestricted@1.3.9
# 或只取安装器
node -e "fetch('https://registry.npmjs.org/dsh-go-unrestricted/-/dsh-go-unrestricted-1.3.9.tgz').then(r=>r.arrayBuffer()).then(b=>require('fs').writeFileSync('/root/p.tgz',Buffer.from(b)))"
```

npm 侧注意：
- npm 对新包走「发布后处理」，tarball 从上传到可下载可能滞后数分钟；`0.0.0-stage` 是占位版本，不是发布失败。
- npm 的 granular token 若勾了「绕过 2FA」才能无交互发布；否则要 `--otp`。
- 该包已按中性文案发布（description / README 不含「破甲 / 不拒答 / 绕过 / 红队」等自述），代码未改动。

## 发布命令

### npm（推荐，链接形态永久）

```bash
# 一次性：注册 npm 账号 → 生成 Automation token
# https://www.npmjs.com/settings/<用户名>/tokens → Generate New Token → Automation

cd /root/.dsh/dsh-go/plugins/dsh-go-unrestricted
npm publish ../../../../sdcard/Download/DSH-Go/dsh-go-unrestricted-1.3.9.tgz \
  --access public --registry https://registry.npmjs.org --//registry.npmjs.org/:_authToken=<TOKEN>
```

发布的固定链接（永不随版本变形，旧版本也一直在）：
- `https://registry.npmjs.org/dsh-go-unrestricted/-/dsh-go-unrestricted-1.3.9.tgz`
- 版本元数据：`https://registry.npmjs.org/dsh-go-unrestricted`
- 镜像（jsDelivr，国内多数网络可用）：`https://cdn.jsdelivr.net/npm/dsh-go-unrestricted@1.3.9/dist/install.sh`

装法：
```bash
npm i dsh-go-unrestricted@1.3.9 --registry https://registry.npmmirror.com
# 或（只拿安装器）
node -e "fetch('https://registry.npmjs.org/dsh-go-unrestricted/-/dsh-go-unrestricted-1.3.9.tgz').then(r=>r.arrayBuffer()).then(b=>require('fs').writeFileSync('/root/p.tgz',Buffer.from(b)))"
```

### Codeberg（免费 Git，raw 链接永久）

```bash
CODEBERG_TOKEN=<token> node tools/mirror-upload.mjs --codeberg --owner <用户名> --repo dsh-go-unrestricted --tag v1.3.9
```
产出：`https://codeberg.org/<用户名>/dsh-go-unrestricted/releases/download/v1.3.9/install.sh`
（脚本会回读附件并核对 sha256，不一致直接判失败。）

### Gitee 新账号（原工具即可）

```bash
GITEE_TOKEN=<新令牌> node tools/gitee-release.mjs --owner <新账号> --repo dsh-go-unrestricted
```

## 失效后的恢复流程（任何渠道都适用）

1. 本机永远有一份：`/sdcard/Download/DSH-Go/install-1.3.12.sh` + `SHA256SUMS`。
2. 任一渠道失效，重新执行上面任一条发布命令，**链接形态不变**（npm 用版本号定位，Codeberg/Gitee 用 tag 定位）。
3. 校验：`sha256sum install.sh` 与下载处给的 `SHA256SUMS` 比对；不一致就是被替换或下载不完整。
4. 想「latest 永远指向最新」：npm 用 `dist-tags`（`npm publish` 默认更新 `latest`），Codeberg/Gitee 用 `download/latest/` 语义仅 Gitee 有，Codeberg 需固定 tag 或自己维护 `latest.txt`。
