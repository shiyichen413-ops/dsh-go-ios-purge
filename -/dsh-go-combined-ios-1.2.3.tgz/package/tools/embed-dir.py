#!/usr/bin/env python3
"""把某个子目录下的文件补成 dist/install.sh 里的 heredoc 块（幂等）。

用法：python3 tools/embed-dir.py lib/redteam skills/redteam
"""
import os, re, sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(BASE, 'dist', 'install.sh')
MARK = '# ── 挂进 profile ─'

text = open(SRC, encoding='utf-8').read()
lines = text.split('\n')
existing = set()
for line in lines:
    m = re.match(r'^cat > "\$DIR/(.+)" <<\'.+\'$', line)
    if m:
        existing.add(m.group(1))

blocks = []
added = []
for rel in sys.argv[1:]:
    root = os.path.join(BASE, rel)
    for dirpath, _dirs, files in os.walk(root):
        for f in sorted(files):
            path = os.path.join(dirpath, f)
            r = os.path.relpath(path, BASE).replace(os.sep, '/')
            if r in existing:
                continue
            tag = '__DSHGO__' + re.sub(r'[^A-Za-z0-9]+', '_', r).upper() + '__'
            body = open(path, encoding='utf-8').read()
            if body.endswith('\n'):
                body = body[:-1]
            if tag in body:
                sys.exit(f'!! {r} 正文里出现标记 {tag}')
            blocks.append(f'cat > "$DIR/{r}" <<\'{tag}\'\n{body}\n{tag}')
            added.append(r)

if not blocks:
    print('没有新文件需要补块')
    sys.exit(0)

at = text.index(MARK)
new = text[:at] + '\n'.join(blocks) + '\n' + text[at:]
open(SRC, 'w', encoding='utf-8').write(new)
print(f'补了 {len(added)} 个块：', ', '.join(added[:6]), '…' if len(added) > 6 else '')
# 补块会带来新的子目录（例如 lib/panel），必须让 build-installer.py 重算 header 的 mkdir
import subprocess
subprocess.run([sys.executable, os.path.join(BASE, 'tools', 'build-installer.py')], check=False)
