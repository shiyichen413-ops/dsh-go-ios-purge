# -*- coding: utf-8 -*-
"""把 tutorial 下的 PDF 逐页渲染成 PNG。

用法：python tools/render-pages.py <pdf 路径> <输出目录> [dpi]
      python tools/render-pages.py            # 默认完整版
      python tools/render-pages.py lite       # 精简版
"""
import os
import shutil
import sys

import pymupdf

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TUT = os.path.join(ROOT, "tutorial")

args = sys.argv[1:]
if not args:
    PDF = os.path.join(TUT, "tutorial.pdf")
    OUT = os.path.join(TUT, "pages")
    DPI = 160
elif args[0] == "lite":
    PDF = os.path.join(TUT, "lite.pdf")
    OUT = os.path.join(TUT, "pages-lite")
    DPI = int(args[1]) if len(args) > 1 else 160
else:
    PDF = args[0]
    OUT = args[1] if len(args) > 1 else os.path.join(TUT, "pages")
    DPI = int(args[2]) if len(args) > 2 else 160


def main():
    if not os.path.exists(PDF):
        print("missing pdf:", PDF)
        return 1

    if os.path.isdir(OUT):
        shutil.rmtree(OUT)
    os.makedirs(OUT, exist_ok=True)

    doc = pymupdf.open(PDF)
    zoom = DPI / 72.0
    mat = pymupdf.Matrix(zoom, zoom)
    total = 0
    count = 0
    for i, page in enumerate(doc, start=1):
        pix = page.get_pixmap(matrix=mat, alpha=False)
        name = "%02d.png" % i
        path = os.path.join(OUT, name)
        pix.save(path)
        total += os.path.getsize(path)
        count = i
        text = page.get_text().strip()
        print("%s  %4dx%-4d  %6d B  %s" % (name, pix.width, pix.height,
                                           os.path.getsize(path),
                                           "EMPTY" if not text else text.splitlines()[0][:42]))
    doc.close()
    print("pages:", count, "dir:", OUT, "total:", total, "bytes")
    return 0


if __name__ == "__main__":
    sys.exit(main())
