// 本机没有可用的 bash（wsl.exe 不可用），所以用解析的方式验证 dist/install.sh：
// 把每个 heredoc 抽出来，跟源文件逐字节比对。内容一致 = 拷到手机上 bash 执行
// 得到的文件与这里完全一样。
//
//   node tools/verify-installer.mjs
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = dirname(dirname(fileURLToPath(import.meta.url)))
const script = readFileSync(join(root, 'dist', 'install.sh'), 'utf8')
const lines = script.split('\n')

const found = []
for (let i = 0; i < lines.length; i += 1) {
  const open = /^cat > "\$DIR\/(.+)" <<'(__DSHGO_[A-Z0-9_]+__)'$/.exec(lines[i])
  if (open === null) continue
  const [, path, marker] = open
  const body = []
  let j = i + 1
  for (; j < lines.length; j += 1) {
    if (lines[j] === marker) break
    body.push(lines[j])
  }
  assert.ok(j < lines.length, `heredoc ${marker} 没有闭合`)
  found.push({ path, text: body.join('\n') })
  i = j
}

assert.ok(found.length >= 6, `只找到 ${found.length} 个 heredoc`)

let checked = 0
for (const { path, text } of found) {
  const src = readFileSync(join(root, path), 'utf8').replace(/\n$/, '')
  assert.equal(text, src, `${path} 在 install.sh 里与源文件不一致`)
  checked += 1
}

// 脚本骨架的几处硬要求
assert.ok(script.startsWith('#!/usr/bin/env bash'), '缺少 shebang')
assert.ok(script.includes('set -eu'), '缺少 set -eu')
assert.ok(/dsh plugin --profile web add "\$DIR"/.test(script), '缺少安装命令')
assert.ok(script.includes("grep -q 'dsh-go-unrestricted:begin'"), 'AGENTS.md 兜底块没做幂等判断')
assert.ok(script.includes('--agents-only'), '缺少 --agents-only 模式')
assert.ok(script.includes('--uninstall'), '缺少 --uninstall 模式')
assert.ok(!script.includes('\r'), 'install.sh 不能带 CRLF（手机上是 bash）')

// 别把未替换的模板变量残留写进脚本
assert.ok(!script.includes('${blocks}'), '模板变量 ${blocks} 没被替换')
assert.ok(!script.includes('${PKG}'), '模板变量 ${PKG} 没被替换')

// AGENTS_BLOCK 必须真的被内联进了脚本（否则兜底是空的）
const { AGENTS_BLOCK } = await import('../lib/directive.js')
assert.ok(script.includes(AGENTS_BLOCK.split('\n')[0]), '兜底块首行没进 install.sh')
assert.ok(script.includes(AGENTS_BLOCK.split('\n').at(-1)), '兜底块末行没进 install.sh')

// ── 结构配对粗检：heredoc 正文之外，if/fi、case/esac、循环/done 必须配平 ──
// 本机没有 bash，跑不了 `bash -n`，所以用行首关键字计数代替。heredoc 里是 JS/HTML，
// 必须整段跳过，否则会被误计。
const markers = new Set(found.map((_, i) => lines.find((l) => l.startsWith('__DSHGO_') && l.endsWith('__')) ?? ''))
const skip = new Set()
for (let i = 0; i < lines.length; i += 1) {
  if (/^cat > "\$DIR\/.+ <<'__DSHGO_[A-Z0-9_]+__'$/.test(lines[i])) {
    const marker = lines[i].slice(lines[i].lastIndexOf("<<'") + 3, -1)
    let j = i + 1
    for (; j < lines.length; j += 1) {
      skip.add(j)
      if (lines[j] === marker) break
    }
    skip.add(i)
    i = j
  }
}

const tally = { if: 0, fi: 0, case: 0, esac: 0, loop: 0, done: 0 }
for (let i = 0; i < lines.length; i += 1) {
  if (skip.has(i)) continue
  const t = lines[i].replace(/^\s+/, '')
  if (/^if\s/.test(t)) tally.if += 1
  else if (t === 'fi' || /^fi\s/.test(t)) tally.fi += 1
  else if (/^case\s/.test(t)) tally.case += 1
  else if (/^esac\b/.test(t)) tally.esac += 1
  else if (/^(for|while)\s/.test(t)) tally.loop += 1
  else if (t === 'done' || /^done\b/.test(t)) tally.done += 1
}
assert.equal(tally.if, tally.fi, `if/fi 不配对：${tally.if} vs ${tally.fi}`)
assert.equal(tally.case, tally.esac, `case/esac 不配对：${tally.case} vs ${tally.esac}`)
assert.equal(tally.loop, tally.done, `循环/done 不配对：${tally.loop} vs ${tally.done}`)
void markers

console.log(
  `OK：${checked} 个文件逐字节一致，脚本骨架完好，无 CRLF；结构配平 if×${tally.if} case×${tally.case} loop×${tally.loop}`,
)
