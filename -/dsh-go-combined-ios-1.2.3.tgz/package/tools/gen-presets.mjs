// 生成三个可选 agent 预设的「派生件」——手写模板之后跑这一个命令即可：
//
//   node tools/gen-presets.mjs
//
// 它做三件事，全部幂等（同输入必得同输出，测试里直接拿来做「两份不许漂」的断言）：
//
//   1. presets/unrestricted-child-b5beb73b2d/{preset.yml,agent.cordis.yml}
//      上游 dsh-purge 的这份子预设是 presets-plugin 在注册瞬间用
//      lib/preset-compat.js 的 migratePresetDefinition 派生的（磁盘上没有）。
//      dsh-go 没有那次运行时派生（也不会去 require 宿主包），所以在这里静态生成：
//        · id      = `unrestricted-child-` + sha256(JSON.stringify({id,deny:排序})).slice(0,10)
//        · name    = `${父 name} · 子任务`
//        · desc    = `兼容子预设：继承父预设提示词和设置，排除 ${deny.join('、')}。主会话请选择 ${父 name}。`
//        · order   = 父 order + 0.1
//        · plugins = 父模板剔除 deny 三行 + 去掉父行自己的 agentPreset（子预设不再往下派生）
//   2. cordis.patch.yml 里三条 @deepseek-ai/dsh-agent-preset 声明行
//      宿主侧只有这一种注册方式：registry 不会扫 $DSH_HOME/.agent-presets，
//      必须把整份 plugins 内联进声明行。
//   3. install-presets.sh（手动的等效脚本，给没法跑 node 的场合兜底）
//
// 注意：声明行里的 plugins 用的是「补丁 #24 已应用」的文本（tool-web fetch: true），
// 因为 cordis.patch.yml 不是补丁 #24 的目标文件；而磁盘模板保持 fetch: false，
// 由 lib/presets/files.mjs 的 installPreset 在落盘后应用 #24，两条路径产物逐字节相同。
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

import { ALL_PATCHES } from '../lib/purge/patches/index.mjs'
import { applyReplacementsToText } from '../lib/purge/core/verify.mjs'

export const ROOT = dirname(dirname(fileURLToPath(import.meta.url)))

/** 上游 migratePresetDefinition 的 deny 集，排序后参与 id 与文案。 */
export const DENY = ['ralph', 'subagent_fork', 'workflow']
/** 父预设 id。 */
export const PARENT_ID = 'unrestricted'
/** 子预设 id：与上游同一套算法（排序后的 identity 再取 sha256 前 10 位）。 */
export const CHILD_ID = `${PARENT_ID}-child-${createHash('sha256')
  .update(JSON.stringify({ id: PARENT_ID, deny: DENY }))
  .digest('hex')
  .slice(0, 10)}`

/** 三个模式的目录名、预设 id、以及它们在注册表里的 order。 */
export const PRESETS = [
  { dir: 'unrestricted', id: PARENT_ID, order: 20 },
  { dir: CHILD_ID, id: CHILD_ID, order: 20.1, derived: true },
  { dir: 'redteam', id: 'redteam', order: 10 },
]

export const presetDir = (dir) => join(ROOT, 'presets', dir)

/** 读 preset.yml 的三个单行标量（这文件只有这三行，不做通用 YAML 解析）。 */
export function readPresetMeta(dir) {
  const text = readFileSync(join(presetDir(dir), 'preset.yml'), 'utf8')
  const pick = (key) => {
    const hit = new RegExp(`^${key}:[ \\t]*(.+)$`, 'm').exec(text)
    if (hit === null) throw new Error(`${dir}/preset.yml 缺少 ${key}`)
    return hit[1].trim()
  }
  const order = Number(pick('order'))
  if (!Number.isFinite(order)) throw new Error(`${dir}/preset.yml 的 order 不是数字`)
  return { name: pick('name'), description: pick('description'), order }
}

const readAgent = (dir) => readFileSync(join(presetDir(dir), 'agent.cordis.yml'), 'utf8')

/** 补丁 #24：打开 preset 里的 tool-web fetch（锚点与上游 dsh-purge 逐字一致）。 */
export function applyFetchPatch(text) {
  const patch = ALL_PATCHES.find((p) => p.id === 24)
  if (patch === undefined) throw new Error('补丁表里没有 id=24')
  const out = applyReplacementsToText(text, patch, 'agent.cordis.yml')
  return { text: out.text, changed: out.changed, hitMismatch: out.hitMismatch ?? null }
}

function replaceOnce(text, from, to, label) {
  const hits = text.split(from).length - 1
  if (hits !== 1) throw new Error(`${label}：期望命中 1 次，实际 ${hits} 次`)
  return text.replace(from, to)
}

const PARENT_AGENT_PRESET_BLOCK = `        # [dsh-go] 上游这里是 toolFilter.deny，由 presets-plugin 在注册时派生子预设。
        # dsh >= 0.2.1 的 dsh-tool-subagent 会拒收 toolFilter（整条预设判 broken、
        # 模式下拉里直接看不到本项目），所以本仓库把那次派生提前做完，静态落成
        # 第二份预设（presets/unrestricted-child-b5beb73b2d，id 取自上游同一套 sha256）。
        agentPreset: ${CHILD_ID}
`

/** 从父模板（已应用 #24 的文本）派生自带子预设。 */
export function deriveChildText(parentText) {
  let t = replaceOnce(
    parentText,
    '# managed-by: dsh-go-unrestricted（模板来源；已有用户文件仅在明确要求重置时覆盖）\n',
    '# managed-by: dsh-go-unrestricted（派生件；改父模板后重跑 node tools/gen-presets.mjs）\n' +
      '# [dsh-go] 本文件由 tools/gen-presets.mjs 自动生成，对应上游 presets-plugin 在注册时用\n' +
      '# migratePresetDefinition 派生出的那份子预设（磁盘上原本不存在）。差异只有两处：\n' +
      '#   1) 去掉父行的 agentPreset（子预设不再指向第三份预设）；\n' +
      `#   2) 递归剔除 deny 集里的 ${DENY.join(' / ')} 三行。\n`,
    'child header',
  )

  t = replaceOnce(
    t,
    PARENT_AGENT_PRESET_BLOCK,
    '        # [dsh-go] 子预设：不再把子会话指向第三份预设（递归一层到底），其余与父预设一致。\n',
    'child agentPreset',
  )

  t = replaceOnce(
    t,
    `    # Fork omits model selection so provider/model stay equal to the parent and
    # the inherited history remains eligible for KV Cache reuse. This preset
    # keeps fork continuable; parent and child inherit the same messaging tool,
    # while the parent id and return guidance follow the inherited history.
    - id: tool-subagent-fork
      name: '@deepseek-ai/dsh-tool-subagent'
      disabled: false
      config:
        provider: fork
        toolName: subagent_fork
        backgroundMode: continuable
`,
    '    # [dsh-go] 子预设：subagent_fork 在 deny 集里，整行剔除（子智能体看不到它）。\n',
    'child drop fork',
  )

  t = replaceOnce(
    t,
    `    - id: tool-workflow
      name: '@deepseek-ai/dsh-tool-workflow'

    - id: tool-ralph
      name: '@deepseek-ai/dsh-tool-ralph'
      config:
        subagentProvider: spawn
        maxRounds: 64
`,
    '    # [dsh-go] 子预设：tool-workflow / tool-ralph 在 deny 集里，整行剔除。\n',
    'child drop workflow+ralph',
  )

  return t
}

/** 子预设的 preset.yml：字段与取值逐字对齐上游 migratePresetDefinition。 */
export function childPresetYml() {
  const parent = readPresetMeta('unrestricted')
  const name = `${parent.name} · 子任务`
  const description = `兼容子预设：继承父预设提示词和设置，排除 ${DENY.join('、')}。主会话请选择 ${parent.name}。`
  return `name: ${name}\ndescription: ${description}\norder: ${parent.order + 0.1}\n`
}

/** 把这个文件写成磁盘上的子预设（幂等）。 */
export function writeChildPreset() {
  const dir = presetDir(CHILD_ID)
  mkdirSync(dir, { recursive: true })
  const parentText = applyFetchPatch(readAgent('unrestricted')).text
  writeFileSync(join(dir, 'agent.cordis.yml'), deriveChildText(parentText), 'utf8')
  writeFileSync(join(dir, 'preset.yml'), childPresetYml(), 'utf8')
  return dir
}

/** YAML 里内联 plugins：把顶层列表整体右移 10 空格（相对缩进不变，等价于嵌到 plugins: 下）。 */
export function indentPlugins(text, spaces = 10) {
  const pad = ' '.repeat(spaces)
  return text
    .split('\n')
    .map((line) => (line.trim() === '' ? '' : pad + line))
    .join('\n')
}

const yamlScalar = (value, label) => {
  if (value.includes("'")) throw new Error(`${label} 里有单引号，需要换引法`)
  return `'${value}'`
}

/** 一条声明行：宿主 @deepseek-ai/dsh-agent-preset 只认这种内联 plugins 的写法。 */
export function declarationBlock(preset, plugins) {
  const meta = readPresetMeta(preset.dir)
  return [
    `    # ── ${meta.name}（id: ${preset.id}，order: ${meta.order}）──────────────────────────────`,
    `    - id: preset-${preset.id}`,
    `      name: '@deepseek-ai/dsh-agent-preset'`,
    `      config:`,
    `        id: ${preset.id}`,
    `        name: ${meta.name}`,
    `        description: ${yamlScalar(meta.description, `${preset.dir} description`)}`,
    `        order: ${meta.order}`,
    `        plugins:`,
    indentPlugins(plugins),
  ].join('\n')
}

/** 声明用的 plugins 文本：磁盘模板 + 补丁 #24（cordis.patch.yml 不在 #24 的目标里）。 */
export function declarationPlugins(preset) {
  if (preset.derived) {
    // 子预设磁盘上已经是 #24 过的文本
    return readAgent(preset.dir).replace(/\n+$/, '')
  }
  const { text, hitMismatch } = applyFetchPatch(readAgent(preset.dir))
  if (hitMismatch !== null) throw new Error(`#24 命中数不符：${JSON.stringify(hitMismatch)}`)
  return text.replace(/\n+$/, '')
}

export const HEADER = `# dsh-go-unrestricted —— 破甲插件 + 三个可选 agent 预设
#
# 三行长什么样、谁注册、依赖哪个宿主包：
#   · 无限制模式（unrestricted, order 20）        —— 操作者意图优先的通用执行模式
#   · 无限制模式 · 子任务（unrestricted-child-…）  —— 上面那条派生的子预设（派活时子会话用）
#   · 红队模式（redteam, order 10）                —— 攻防演练指挥人设（原生工具，不带 redteam_* 后端）
#
# 注册方式：宿主 @deepseek-ai/dsh-agent-preset 读这几条声明 → 把 plugins 内联挂载，
# 再在 [Service.init] 里 ctx.agentPresets.register(config) 进模式下拉。registry 不会
# 扫 $DSH_HOME/.agent-presets，所以 plugins 必须整份内联在这里（别改成路径引用）。
#
# 依赖的宿主包（任一缺失 = 那条预设判 broken，下拉里会被过滤掉）：
#   @deepseek-ai/dsh-agent-preset          声明行本体（必需）
#   @deepseek-ai/dsh-agent-preset-registry agentPresets 服务（宿主自带）
#   @deepseek-ai/dsh-tool-subagent-control 派活三行（tool-subagent / -list-agents / -control）
#   @deepseek-ai/dsh-tool-executor-native  bash/pwsh 的执行器（缺了只有 shell 不可用）
#   @deepseek-ai/dsh-workflow-ptc          workflow 引擎（workflow-worker-thread 已 disabled: true）
#
# 本文件由 node tools/gen-presets.mjs 生成；要改预设内容请改 presets/*/agent.cordis.yml。
- insert:
    # ── 插件本体 ──────────────────────────────────────────────────────────────
    - id: dsh-go-unrestricted
      name: dsh-go-unrestricted
`

/** 生成 cordis.patch.yml 全文。 */
export function buildPatchYaml() {
  const parts = PRESETS.map((preset) => declarationBlock(preset, declarationPlugins(preset)))
  return `${HEADER}\n${parts.join('\n\n')}\n`
}

/** 生成 install-presets.sh：不带 node 的手动兜底，产物与 installPreset 逐字节相同。 */
export function buildInstallScript() {
  const files = []
  for (const preset of PRESETS) {
    const yml = readFileSync(join(presetDir(preset.dir), 'preset.yml'), 'utf8')
    files.push([`${preset.dir}/preset.yml`, yml])
    files.push([`${preset.dir}/agent.cordis.yml`, `${declarationPlugins(preset)}\n`])
    if (preset.dir === 'redteam') {
      files.push([
        'redteam/anchor-gate.mjs',
        readFileSync(join(presetDir('redteam'), 'anchor-gate.mjs'), 'utf8'),
      ])
    }
  }

  const heredocs = files
    .map(([rel, body]) => {
      const marker = `__DSHGO_PRESET_${rel.replace(/[^A-Za-z0-9]/g, '_').toUpperCase()}__`
      return [
        `if [ -f "$PRESET_ROOT/${rel}" ] && [ "$FORCE" = 0 ]; then`,
        `  echo "→ 已存在，跳过：$PRESET_ROOT/${rel}"`,
        `else`,
        `  cat > "$PRESET_ROOT/${rel}" <<'${marker}'`,
        body.replace(/\n$/, ''),
        marker,
        `  echo "→ 已写入 $PRESET_ROOT/${rel}"`,
        `fi`,
      ].join('\n')
    })
    .join('\n')

  const dirNames = [...new Set(files.map(([rel]) => rel.slice(0, rel.lastIndexOf('/'))))]
  const mkdirs = dirNames.map((d) => `mkdir -p "$PRESET_ROOT/${d}"`).join('\n')
  const chmods = ['chmod 700 "$PRESET_ROOT"', ...dirNames.map((d) => `"$PRESET_ROOT/${d}"`)].join(' ')

  return `#!/bin/sh
# dsh-go-unrestricted —— 把三个可选 agent 预设模板落到 $DSH_HOME/.agent-presets/
#
#   sh install-presets.sh          # 只补缺失的文件（已有文件不覆盖）
#   sh install-presets.sh --force  # 全部重写（等于上游 installPreset({force:true})）
#
# 注意：真正让模式出现在下拉里的是插件目录下的 cordis.patch.yml（声明行内联 plugins）；
# 这里写的是模板副本，给「想改文案 / 想被补丁 #24 与 #76 处理」的场合用。
# 插件正常加载时 lib/presets/install.mjs 会自动做同样的事，通常不需要手动跑本脚本。
set -eu

DSH_HOME_DIR="\${DSH_HOME:-$HOME/.dsh}"
PRESET_ROOT="$DSH_HOME_DIR/.agent-presets"
FORCE=0
if [ "\${1:-}" = "--force" ]; then FORCE=1; fi

umask 077
${mkdirs}
${chmods}

${heredocs}

echo
echo "完成：三个预设模板在 $PRESET_ROOT/{${dirNames.join(',')}}"
echo "改完文案要重启引擎（预设的 plugins 来自 cordis.patch.yml，热改不生效）。"
`
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const dir = writeChildPreset()
  writeFileSync(join(ROOT, 'cordis.patch.yml'), buildPatchYaml(), 'utf8')
  writeFileSync(join(ROOT, 'install-presets.sh'), buildInstallScript(), 'utf8')
  process.stdout.write(`wrote ${dir}\nwrote cordis.patch.yml\nwrote install-presets.sh\n`)
}
