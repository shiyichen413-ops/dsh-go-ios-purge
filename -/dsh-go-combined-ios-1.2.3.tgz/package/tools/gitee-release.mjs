#!/usr/bin/env node
// 给 Gitee 建发行版并把 dist/install.sh 挂成附件 —— 得到一个「点开就下载」的文件链接。
//
//   node tools/gitee-release.mjs                      # tag 取 package.json 的 version
//   node tools/gitee-release.mjs --tag v1.3.7
//   node tools/gitee-release.mjs --dry-run            # 只看会怎么做
//
// 令牌：GITEE_TOKEN 环境变量，或 --token。
// 为什么需要发行版：仓库里的 raw 链接打开是「网页里的文本」，附件链接才会触发浏览器下载
// （响应头 Content-Disposition: attachment）。Gitee 的 releases/download/latest/install.sh
// 永远指向最新一个发行版的同名附件，所以文档里写它就不用随版本改。
import { readFileSync, statSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const API = "https://gitee.com/api/v5";
const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const FILE = "dist/install.sh";
const ASSET_NAME = "install.sh";

const args = process.argv.slice(2);
const flag = (name) => args.includes(`--${name}`);
const opt = (name, fallback) => {
  const i = args.indexOf(`--${name}`);
  return i >= 0 && args[i + 1] && !args[i + 1].startsWith("--") ? args[i + 1] : fallback;
};

const pkg = JSON.parse(readFileSync(join(ROOT, "package.json"), "utf8"));
const TOKEN = opt("token", process.env.GITEE_TOKEN || process.env.GITEE_ACCESS_TOKEN || "");
const OWNER = opt("owner", process.env.GITEE_OWNER || "lingsmallcode");
const REPO = opt("repo", process.env.GITEE_REPO || "dsh-go-unrestricted");
const TAG = opt("tag", `v${pkg.version}`);
const DRY = flag("dry-run");

if (!TOKEN && !DRY) {
  console.error("缺令牌：设 GITEE_TOKEN，或传 --token（Gitee → 设置 → 私人令牌，勾 projects）");
  process.exit(2);
}

const localPath = join(ROOT, FILE);
let size = 0;
try {
  size = statSync(localPath).size;
} catch {
  console.error(`找不到 ${FILE}，先跑 node tools/make-installer.mjs`);
  process.exit(2);
}

async function call(method, path, body) {
  const url = `${API}${path}${path.includes("?") ? "&" : "?"}access_token=${encodeURIComponent(TOKEN)}`;
  const res = await fetch(url, {
    method,
    headers: body ? { "Content-Type": "application/json" } : {},
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  const text = await res.text();
  let json = null;
  try { json = text ? JSON.parse(text) : null; } catch { json = { raw: text }; }
  if (!res.ok) {
    const flat = json?.error?.base?.join("; ") || json?.message || text.slice(0, 200);
    const err = new Error(`${method} ${path} → ${res.status} ${flat}`);
    err.status = res.status;
    throw err;
  }
  return json;
}

function releaseBody() {
  const url = `https://gitee.com/${OWNER}/${REPO}`;
  return [
    `## dsh-go-unrestricted ${TAG}`,
    "",
    "把 dsh-purge v1.7.14 的能力搬进 dsh-go：88 条宿主补丁（本机该打的按 applicable 计分母）、破甲自检、三个可选模式、四个对话内面板。",
    "",
    "### 装（Android / proot 终端，一条命令）",
    "",
    "```bash",
    `node -e "fetch('${url}/releases/download/latest/${ASSET_NAME}').then(r=>{if(!r.ok)throw new Error(r.status);return r.arrayBuffer()}).then(b=>{require('fs').writeFileSync('/root/install.sh',Buffer.from(b));console.log('已下载',b.byteLength,'字节')})"`,
    "cd /root && bash install.sh",
    "```",
    "",
    "也可以直接点下面的 `install.sh` 附件下载（返回的是文件，不是网页）。",
    "",
    "装完彻底退出 dsh-go 再打开，然后：",
    "",
    "```bash",
    "cd /root/.dsh/dsh-go/plugins/dsh-go-unrestricted && node lib/engine.js selfcheck",
    "```",
    "",
    "看到 `自检 · 宿主 20/20 层 · 注入 1/1 · 权限 1/1 · 补丁 69/69 · 全通过` 即完成。",
  ].join("\n");
}

async function main() {
  console.log(`目标：${OWNER}/${REPO} @ ${TAG} · 附件 ${FILE} · ${size} 字节`);
  if (DRY) {
    console.log("dry-run：不建发行版、不上传");
    return;
  }

  // 1) 找/建发行版（Gitee 的 /releases/tags/{tag} 会返 200+空体，只能用列表接口判断）
  let release = null;
  const list = await call("GET", `/repos/${OWNER}/${REPO}/releases?per_page=100`);
  if (Array.isArray(list)) release = list.find((r) => r.tag_name === TAG) || null;

  if (release) {
    console.log(`发行版已存在：${release.name} (id=${release.id})`);
  } else {
    release = await call("POST", `/repos/${OWNER}/${REPO}/releases`, {
      tag_name: TAG,
      name: `dsh-go-unrestricted ${TAG}`,
      body: releaseBody(),
      target_commitish: "master",
      prerelease: false,
    });
    console.log(`已创建发行版：${release.name} (id=${release.id})`);
  }

  // 2) 删同名旧附件（重发同版本时避免出现两个 install.sh）
  const stale = (release.assets || []).filter((a) => a.name === ASSET_NAME);
  for (const a of stale) {
    try {
      await call("DELETE", `/repos/${OWNER}/${REPO}/releases/${release.id}/attach_files/${a.id}`);
      console.log(`删除旧附件 id=${a.id}`);
    } catch (err) {
      console.warn(`删除旧附件 id=${a.id} 失败：${err.message}`);
    }
  }

  // 3) 上传
  const form = new FormData();
  form.append("access_token", TOKEN);
  form.append("file", new Blob([readFileSync(localPath)], { type: "application/octet-stream" }), ASSET_NAME);
  const res = await fetch(`${API}/repos/${OWNER}/${REPO}/releases/${release.id}/attach_files`, {
    method: "POST",
    body: form,
  });
  const text = await res.text();
  let asset = null;
  try { asset = JSON.parse(text); } catch { /* 非 JSON */ }
  if (!res.ok) {
    console.error(`上传失败 HTTP ${res.status}：${text.slice(0, 300)}`);
    process.exit(1);
  }

  console.log(`上传成功 attach id=${asset?.id ?? "-"} size=${asset?.size ?? size}`);
  console.log("");
  console.log(`文件直链（点开即下载）：https://gitee.com/${OWNER}/${REPO}/releases/download/${TAG}/${ASSET_NAME}`);
  console.log(`永久最新入口        ：https://gitee.com/${OWNER}/${REPO}/releases/download/latest/${ASSET_NAME}`);
  console.log(`发行版页            ：https://gitee.com/${OWNER}/${REPO}/releases/tag/${TAG}`);
}

await main();
