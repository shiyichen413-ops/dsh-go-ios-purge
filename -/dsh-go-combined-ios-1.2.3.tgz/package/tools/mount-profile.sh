#!/usr/bin/env bash
# 把 dsh-go-unrestricted 真正挂进 dsh profile。
#
# 为什么不能只靠 dsh plugin add：
#   手机端 dsh-go 通常没有 pnpm/npm 联网能力，`dsh plugin --profile web add`
#   只把名字写进 package.json 的 bundles 名单，不会把包实体落到
#   profiles/web/node_modules。下次启动 dsh 解析 bundle 时就报
#     cannot resolve profile bundle "dsh-go-unrestricted" from ... profiles/web
#   于是插件红字「加载失败」，它自带的 cordis.patch.yml 也不会被读到
#   （红队模式、无限制模式·子任务两个预设正是靠那份 patch 注册的）。
#
# 本脚本做两件事：
#   1. 复制包实体到 profiles/<profile>/node_modules/<pkg>（真实目录，不用软链）
#   2. 幂等登记 package.json 的 dsh.profile.bundles 名单
#
# 用法：
#   bash mount-profile.sh <插件目录>              挂载
#   bash mount-profile.sh --remove                摘除
#   DSH_PROFILE=desktop bash mount-profile.sh ... 指定 profile（默认 web）

set -u

PKG=dsh-go-unrestricted
DSH_HOME_DIR=${DSH_HOME:-$HOME/.dsh}
PROFILE=${DSH_PROFILE:-web}
PROFILE_DIR=$DSH_HOME_DIR/profiles/$PROFILE
PJ=$PROFILE_DIR/package.json
NM=$PROFILE_DIR/node_modules

DIR=
REMOVE=0
for a in "$@"; do
  case "$a" in
    --remove) REMOVE=1 ;;
    -*) ;;
    *) DIR=$a ;;
  esac
done

if [ ! -d "$PROFILE_DIR" ]; then
  echo "！没有 $PROFILE_DIR：这个宿主不是 profile 布局，跳过挂载"
  echo "  插件文件留在 ${DIR:-$PKG}，供插件目录扫描"
  exit 0
fi

# ── 摘除 ────────────────────────────────────────────────────────────────────
if [ "$REMOVE" = 1 ]; then
  rm -rf "$NM/$PKG"
  echo "→ 已删除 $NM/$PKG"
  if [ -f "$PJ" ]; then
    cp "$PJ" "$PJ.mount-bak"
    awk -v pkg="$PKG" '
      /"bundles"[[:space:]]*:/ { sect="bundles" }
      sect=="bundles" && /^[[:space:]]*\]/ { sect="" }
      sect=="bundles" && index($0, pkg) { next }
      { print }
    ' "$PJ.mount-bak" > "$PJ"
    rm -f "$PJ.mount-bak"
    echo "→ 已从 profile bundles 摘掉 $PKG"
  fi
  exit 0
fi

if [ -z "$DIR" ] || [ ! -f "$DIR/package.json" ]; then
  echo "！用法：bash mount-profile.sh <插件目录>，或 --remove"
  exit 1
fi

# ── 实体 ────────────────────────────────────────────────────────────────────
mkdir -p "$NM"
rm -rf "$NM/$PKG"
cp -a "$DIR" "$NM/$PKG"
echo "→ 包实体：$NM/$PKG"

# ── 名单 ────────────────────────────────────────────────────────────────────
if [ -f "$PJ" ]; then
  if awk -v pkg="$PKG" '
      /"bundles"[[:space:]]*:/ { f=1 }
      f && /^[[:space:]]*\]/ { f=0 }
      f && index($0, "\"" pkg "\"") { hit=1 }
      END { exit hit?0:1 }
    ' "$PJ"; then
    echo "→ profile bundles 已登记 $PKG"
  else
    cp "$PJ" "$PJ.mount-bak"
    awk -v pkg="$PKG" '
      /"bundles"[[:space:]]*:[[:space:]]*\[/ { print; printf "        \"%s\",\n", pkg; next }
      { print }
    ' "$PJ.mount-bak" > "$PJ"
    rm -f "$PJ.mount-bak"
    echo "→ 已把 $PKG 写进 profile bundles"
  fi

  if ! grep -q "\"$PKG\": *" "$PJ"; then
    cp "$PJ" "$PJ.mount-bak"
    awk -v pkg="$PKG" -v dir="$DIR" '
      /"dependencies"[[:space:]]*:[[:space:]]*\{/ { print; printf "    \"%s\": \"file:%s\",\n", pkg, dir; next }
      { print }
    ' "$PJ.mount-bak" > "$PJ"
    rm -f "$PJ.mount-bak"
    echo "→ 已在 profile dependencies 登记 file:$DIR"
  fi
fi

echo "完成：重启 dsh-go 后插件与三个预设模式才会加载。"
