#!/usr/bin/env bash
# dsh-go-unrestricted —— 完整卸载
#
#   bash tools/uninstall.sh                 # 回滚引擎层补丁 → 摘 profile → 删插件目录
#   bash tools/uninstall.sh --keep-backups  # 保留 *.dshpurge.bak 备份文件
#   bash tools/uninstall.sh --keep-patches  # 不回滚引擎层补丁，只卸载插件
#
# 顺序很重要：先回滚补丁（否则宿主文件停在被改状态），再摘 profile 挂载，最后删目录。
set -u

DIR="$(cd "$(dirname "$0")/.." && pwd)"
HOME_DIR="${DSH_HOME:-$HOME/.dsh}"
AGENTS="$HOME_DIR/AGENTS.md"
AI_BASE="${DSH_GO_AI_BASE:-/opt/dsh}"
KEEP_BACKUPS=0
KEEP_PATCHES=0
for a in "$@"; do
  case "$a" in
    --keep-backups) KEEP_BACKUPS=1 ;;
    --keep-patches) KEEP_PATCHES=1 ;;
    -h|--help) sed -n '2,9p' "$0"; exit 0 ;;
  esac
done

echo "插件目录：$DIR"
echo "DSH_HOME：$HOME_DIR"

if [ "$KEEP_PATCHES" != 1 ] && [ -f "$DIR/lib/engine.js" ]; then
  echo "→ 回滚引擎层补丁"
  node "$DIR/lib/engine.js" revert "$AI_BASE" 2>&1 | tail -5 || echo "！回滚失败，可稍后手动重试"
else
  echo "→ 跳过引擎层回滚"
fi

if [ -f "$DIR/tools/mount-profile.sh" ]; then
  echo "→ 摘除 profile 挂载"
  bash "$DIR/tools/mount-profile.sh" --remove 2>&1 | tail -3 || true
fi

if command -v dsh >/dev/null 2>&1; then
  echo "→ 从 profile 名单移除"
  dsh plugin --profile web remove dsh-go-unrestricted >/dev/null 2>&1 || true
fi

if [ -f "$AGENTS" ] && grep -q 'dsh-go-unrestricted:begin' "$AGENTS"; then
  tmp="$AGENTS.tmp.$$"
  awk '/<!-- dsh-go-unrestricted:begin/{skip=1} !skip{print} /<!-- dsh-go-unrestricted:end -->/{skip=0}' "$AGENTS" > "$tmp"
  cat "$tmp" > "$AGENTS" && rm -f "$tmp"
  echo "→ 已移除 AGENTS.md 兜底块"
fi

if [ "$KEEP_BACKUPS" = 1 ]; then
  echo "→ 保留 $(find "$AI_BASE/node_modules/@deepseek-ai" -name '*.dshpurge.bak' 2>/dev/null | wc -l) 个 .dshpurge.bak"
else
  n=$(find "$AI_BASE/node_modules/@deepseek-ai" -name '*.dshpurge.bak' 2>/dev/null | wc -l)
  find "$AI_BASE/node_modules/@deepseek-ai" -name '*.dshpurge.bak' -delete 2>/dev/null || true
  echo "→ 已删除 $n 个 .dshpurge.bak（--keep-backups 可保留）"
fi

rm -rf "$DIR"
echo
echo "完成：$DIR 已删除。重开引擎后破甲不再加载。"
echo "技能库（$HOME_DIR/skills/redteam-* 或 23 个红队技能目录）不受影响，需要时自行删除。"
