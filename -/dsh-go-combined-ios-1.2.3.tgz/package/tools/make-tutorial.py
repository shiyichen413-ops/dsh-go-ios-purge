# -*- coding: utf-8 -*-
"""把 tutorial/教程-dsh-go破甲.md 渲染成 A4 Word 文档。

用法：
    python tools/make-tutorial.py
输出：
    tutorial/dsh-go破甲教程.docx
"""
import os
import re
import sys
from datetime import date

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VARIANT = sys.argv[1] if len(sys.argv) > 1 else "full"
if VARIANT == "lite":
    SRC = os.path.join(ROOT, "tutorial", "教程-dsh-go破甲-精简版.md")
    OUT = os.path.join(ROOT, "tutorial", "dsh-go破甲步骤.docx")
    INTRO = "六个步骤，全部命令可直接粘贴。装好重启引擎即生效，全程不改系统文件、不需要 root。"
    FOOTER = "dsh-go 破甲 · 操作步骤　·　"
else:
    SRC = os.path.join(ROOT, "tutorial", "教程-dsh-go破甲.md")
    OUT = os.path.join(ROOT, "tutorial", "dsh-go破甲教程.docx")
    INTRO = "本记录包含两次失败路径的完整证据、一次成功路径的完整代码，以及支撑判断的源码级依据。所有文件尺寸、命令输出、模型原话均可核对。"
    FOOTER = "dsh-go 破甲全记录　·　"

BODY_CN = "微软雅黑"
BODY_EN = "Segoe UI"
MONO = "Consolas"

INK = RGBColor(0x1A, 0x1A, 0x1A)
MUTED = RGBColor(0x6B, 0x6B, 0x6B)
ACCENT = RGBColor(0x0B, 0x5C, 0x8A)


def set_run_font(run, cn=BODY_CN, en=BODY_EN, size=None, bold=None, color=None, mono=False):
    if mono:
        cn, en = MONO, MONO
    run.font.name = en
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    rfonts.set(qn("w:ascii"), en)
    rfonts.set(qn("w:hAnsi"), en)
    rfonts.set(qn("w:eastAsia"), cn)
    rfonts.set(qn("w:cs"), en)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.font.bold = bold
    if color is not None:
        run.font.color.rgb = color


def shade_paragraph(p, fill="F4F5F7", border="D8DBE0"):
    ppr = p._p.get_or_add_pPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill)
    ppr.append(shd)
    bdr = OxmlElement("w:pBdr")
    for side, sz in (("left", 18), ("top", 4), ("bottom", 4), ("right", 4)):
        el = OxmlElement("w:%s" % side)
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), str(sz))
        el.set(qn("w:space"), "4")
        el.set(qn("w:color"), border)
        bdr.append(el)
    ppr.append(bdr)


def bottom_rule(p, color="0B5C8A", sz=8):
    ppr = p._p.get_or_add_pPr()
    bdr = OxmlElement("w:pBdr")
    el = OxmlElement("w:bottom")
    el.set(qn("w:val"), "single")
    el.set(qn("w:sz"), str(sz))
    el.set(qn("w:space"), "4")
    el.set(qn("w:color"), color)
    bdr.append(el)
    ppr.append(bdr)


def shade_cell(cell, fill):
    tcpr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill)
    tcpr.append(shd)


def repeat_header(row):
    trpr = row._tr.get_or_add_trPr()
    el = OxmlElement("w:tblHeader")
    el.set(qn("w:val"), "true")
    trpr.append(el)
    el2 = OxmlElement("w:cantSplit")
    el2.set(qn("w:val"), "true")
    trpr.append(el2)


def add_page_field(paragraph):
    run = paragraph.add_run()
    f1 = OxmlElement("w:fldChar"); f1.set(qn("w:fldCharType"), "begin")
    it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = " PAGE "
    f2 = OxmlElement("w:fldChar"); f2.set(qn("w:fldCharType"), "end")
    run._r.append(f1); run._r.append(it); run._r.append(f2)
    return run


INLINE = re.compile(r"(\*\*[^*]+\*\*|`[^`]+`)")
CODE = re.compile(r"(`[^`]+`)")


def add_rich(p, text, size=10.5, color=INK, bold=False):
    """把 **粗体** 与 `代码` 拆成 run，支持粗体内部嵌行内代码。"""
    for piece in re.split(r"(\*\*[^*]+\*\*)", text):
        if not piece:
            continue
        is_bold = piece.startswith("**") and piece.endswith("**") and len(piece) > 4
        inner = piece[2:-2] if is_bold else piece
        for sub in CODE.split(inner):
            if not sub:
                continue
            if sub.startswith("`") and sub.endswith("`") and len(sub) > 2:
                r = p.add_run(sub[1:-1])
                set_run_font(r, size=size - 0.5, mono=True, color=RGBColor(0x9B, 0x2C, 0x2C))
            else:
                r = p.add_run(sub)
                set_run_font(r, size=size, bold=(bold or is_bold), color=color)


def build():
    with open(SRC, "r", encoding="utf-8") as fh:
        lines = fh.read().splitlines()

    # 抽出封面标题与副标题
    title = "dsh-go 破甲全记录"
    subtitle = ""
    body_start = 0
    for i, ln in enumerate(lines):
        if ln.startswith("# ") and not title:
            pass
    idx = 0
    while idx < len(lines) and not lines[idx].strip():
        idx += 1
    if idx < len(lines) and lines[idx].startswith("# "):
        title = lines[idx][2:].strip()
        idx += 1
    while idx < len(lines) and not lines[idx].strip():
        idx += 1
    if idx < len(lines) and lines[idx].startswith("## "):
        subtitle = lines[idx][3:].strip()
        idx += 1
    body_start = idx

    doc = Document()

    # 页面
    sec = doc.sections[0]
    sec.page_width = Cm(21.0)
    sec.page_height = Cm(29.7)
    sec.left_margin = Cm(2.1)
    sec.right_margin = Cm(2.1)
    sec.top_margin = Cm(2.2)
    sec.bottom_margin = Cm(1.9)
    sec.header_distance = Cm(1.0)
    sec.footer_distance = Cm(1.0)

    normal = doc.styles["Normal"]
    normal.font.name = BODY_EN
    normal.font.size = Pt(10.5)
    normal.element.rPr.rFonts.set(qn("w:eastAsia"), BODY_CN)
    normal.paragraph_format.line_spacing = 1.45
    normal.paragraph_format.space_after = Pt(5)

    # ---------- 封面 ----------
    for _ in range(3):
        doc.add_paragraph()

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    r = p.add_run(title)
    set_run_font(r, size=30, bold=True, color=RGBColor(0x0E, 0x1F, 0x2B))
    p.paragraph_format.space_after = Pt(10)

    if subtitle:
        p = doc.add_paragraph()
        r = p.add_run(subtitle)
        set_run_font(r, size=13, color=MUTED)
        p.paragraph_format.space_after = Pt(4)

    p = doc.add_paragraph()
    bottom_rule(p, color="0B5C8A", sz=12)
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(26)

    meta = [
        ("适用环境", "Android · dsh-go（App 内 PRoot Ubuntu + 内置 Node.js）"),
        ("关键文件", "/root/.dsh/dsh-go/plugins/unrestricted-mini/"),
        ("生效机制", "system-prompt/assemble 瀑布钩子 · order -5000"),
        ("验证状态", "已实测生效"),
        ("整理日期", date.today().isoformat()),
    ]
    for k, v in meta:
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(3)
        r = p.add_run(k + "　")
        set_run_font(r, size=10, bold=True, color=ACCENT)
        r = p.add_run(v)
        set_run_font(r, size=10, color=INK)

    doc.add_paragraph()
    p = doc.add_paragraph()
    r = p.add_run(INTRO)
    set_run_font(r, size=9.5, color=MUTED)
    p.paragraph_format.line_spacing = 1.5

    doc.add_page_break()

    # ---------- 正文 ----------
    i = body_start
    n = len(lines)
    first_chapter = True
    while i < n:
        line = lines[i]
        stripped = line.strip()

        # 代码块
        if stripped.startswith("```"):
            i += 1
            buf = []
            while i < n and not lines[i].strip().startswith("```"):
                buf.append(lines[i])
                i += 1
            i += 1
            code = "\n".join(buf).rstrip()
            if code:
                p = doc.add_paragraph()
                p.paragraph_format.left_indent = Cm(0.35)
                p.paragraph_format.right_indent = Cm(0.15)
                p.paragraph_format.space_before = Pt(5)
                p.paragraph_format.space_after = Pt(7)
                p.paragraph_format.line_spacing = 1.18
                p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
                r = p.add_run(code)
                set_run_font(r, size=8.6, mono=True, color=RGBColor(0x24, 0x29, 0x2E))
                shade_paragraph(p)
            continue

        # 表格
        if stripped.startswith("|") and stripped.count("|") >= 2:
            rows = []
            while i < n and lines[i].strip().startswith("|"):
                raw = lines[i].strip()
                cells = [c.strip() for c in raw.strip("|").split("|")]
                if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells if c):
                    rows.append(cells)
                i += 1
            if rows:
                cols = max(len(r) for r in rows)
                table = doc.add_table(rows=len(rows), cols=cols)
                table.style = "Table Grid"
                table.alignment = WD_TABLE_ALIGNMENT.LEFT
                table.autofit = True
                for ri, row in enumerate(rows):
                    if ri == 0:
                        repeat_header(table.rows[0])
                    for ci in range(cols):
                        cell = table.cell(ri, ci)
                        cell.text = ""
                        cp = cell.paragraphs[0]
                        cp.paragraph_format.space_after = Pt(2)
                        cp.paragraph_format.space_before = Pt(2)
                        cp.paragraph_format.line_spacing = 1.2
                        txt = row[ci] if ci < len(row) else ""
                        add_rich(cp, txt, size=9, bold=(ri == 0),
                                 color=RGBColor(0x0E, 0x1F, 0x2B) if ri == 0 else INK)
                        if ri == 0:
                            shade_cell(cell, "E8EEF3")
                doc.add_paragraph().paragraph_format.space_after = Pt(2)
            continue

        # 分隔线（后面紧跟章标题时直接跳过，避免空白页）
        if re.fullmatch(r"-{3,}", stripped):
            j = i + 1
            while j < n and not lines[j].strip():
                j += 1
            if j < n and lines[j].strip().startswith("## "):
                i += 1
                continue
            p = doc.add_paragraph()
            bottom_rule(p, color="D8DBE0", sz=4)
            p.paragraph_format.space_before = Pt(4)
            p.paragraph_format.space_after = Pt(10)
            i += 1
            continue

        # 标题
        if stripped.startswith("## "):
            p = doc.add_paragraph()
            first_chapter = False
            p.paragraph_format.space_before = Pt(22)
            p.paragraph_format.space_after = Pt(10)
            p.paragraph_format.keep_with_next = True
            r = p.add_run(stripped[3:])
            set_run_font(r, size=17, bold=True, color=RGBColor(0x0E, 0x1F, 0x2B))
            bottom_rule(p, color="0B5C8A", sz=10)
            i += 1
            continue

        if stripped.startswith("### "):
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(12)
            p.paragraph_format.space_after = Pt(5)
            p.paragraph_format.keep_with_next = True
            r = p.add_run(stripped[4:])
            set_run_font(r, size=12.5, bold=True, color=ACCENT)
            i += 1
            continue

        if stripped.startswith("#### "):
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(9)
            p.paragraph_format.space_after = Pt(3)
            p.paragraph_format.keep_with_next = True
            r = p.add_run(stripped[5:])
            set_run_font(r, size=11, bold=True, color=RGBColor(0x2A, 0x2A, 0x2A))
            i += 1
            continue

        # 引用
        if stripped.startswith("> "):
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.5)
            p.paragraph_format.space_before = Pt(4)
            p.paragraph_format.space_after = Pt(6)
            add_rich(p, stripped[2:], size=10, color=RGBColor(0x4A, 0x4A, 0x4A))
            shade_paragraph(p, fill="FBF7EC", border="E0D2A8")
            i += 1
            continue

        # 列表
        m = re.match(r"^(\s*)([-*]|\d+\.)\s+(.*)$", line)
        if m:
            indent, marker, text = m.group(1), m.group(2), m.group(3)
            level = len(indent) // 2
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.6 + 0.55 * level)
            p.paragraph_format.first_line_indent = Cm(-0.42)
            p.paragraph_format.space_after = Pt(3)
            p.paragraph_format.line_spacing = 1.4
            bullet = "• " if marker in ("-", "*") else marker + " "
            r = p.add_run(bullet)
            set_run_font(r, size=10.5, color=ACCENT, bold=(marker not in ("-", "*")))
            add_rich(p, text, size=10.5)
            i += 1
            continue

        # 空行
        if not stripped:
            i += 1
            continue

        # 普通段落
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(6)
        add_rich(p, stripped, size=10.5)
        i += 1

    # ---------- 页脚 ----------
    footer = doc.sections[0].footer
    fp = footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = fp.add_run(FOOTER)
    set_run_font(r, size=8.5, color=MUTED)
    add_page_field(fp)
    for rr in fp.runs:
        set_run_font(rr, size=8.5, color=MUTED)

    cp = doc.core_properties
    cp.title = title
    cp.subject = subtitle or title
    cp.author = "DSH 工程记录"
    cp.comments = "dsh-go 破甲：插件注入系统提示词的完整实现与机制分析"

    doc.save(OUT)
    size = os.path.getsize(OUT)
    print("saved:", OUT)
    print("bytes:", size)


if __name__ == "__main__":
    sys.exit(build())
