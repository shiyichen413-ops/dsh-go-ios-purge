// 把插件目录打成一个自包含的安装脚本：手机端 dsh-go 的「终端」里只要能拿到
// 这一个文件，就能在没有网络、没有 adb、没有 root 文件管理器的情况下装好。
//
//   node tools/make-installer.mjs        → dist/install.sh
//
// 脚本做三件事：写出插件全部文件 → 挂进 profile → 追加 AGENTS.md 兜底块。
import { mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'

import { AGENTS_BLOCK } from '../lib/directive.js'

const root = dirname(dirname(fileURLToPath(import.meta.url)))
const PKG = 'dsh-go-unrestricted'

/** lib/ 下一律递归收进来：引擎层现在是整份 dsh-purge 补丁表（lib/purge/**），手写清单必然漏。 */
function walkLib(dir, rel = 'lib') {
  const out = []
  for (const ent of readdirSync(join(root, dir), { withFileTypes: true })) {
    const childDir = `${dir}/${ent.name}`
    const childRel = `${rel}/${ent.name}`
    if (ent.isDirectory()) out.push(...walkLib(childDir, childRel))
    else if (/\.(js|mjs|cjs|json)$/.test(ent.name)) out.push(childRel)
  }
  return out
}

/** 任意扩展名整棵收（presets/** 里有 .yml，还有 redteam 的 anchor-gate.mjs）。 */
function walkAll(dir, rel = dir) {
  const out = []
  for (const ent of readdirSync(join(root, dir), { withFileTypes: true })) {
    const childDir = `${dir}/${ent.name}`
    const childRel = `${rel}/${ent.name}`
    if (ent.isDirectory()) out.push(...walkAll(childDir, childRel))
    else out.push(childRel)
  }
  return out
}

const FILES = [
  'package.json',
  'cordis.patch.yml',
  ...walkLib('lib').sort(),
  // 三个可选模式的模板：插件注册走 cordis.patch.yml 里内联的 plugins，但模板副本
  // （以及安装后由 #24/#76 处理的那份）要能一起落到手机上，install-presets.sh 同理。
  ...walkAll('presets').sort(),
  'install-presets.sh',
  'README.md',
]

const heredoc = (target, body) => {
  const marker = `__DSHGO_${target.replace(/[^A-Za-z0-9]/g, '_').toUpperCase()}__`
  // 内容里若意外出现同一标记就换一个
  const m = body.includes(marker) ? `${marker}_X` : marker
  return `cat > "${target}" <<'${m}'\n${body.replace(/\n$/, '')}\n${m}\n`
}

const blocks = FILES.map((rel) => {
  const dir = rel.includes('/') ? rel.slice(0, rel.lastIndexOf('/')) : ''
  const mkdir = dir ? `mkdir -p "$DIR/${dir}"\n` : ''
  return mkdir + heredoc(`$DIR/${rel}`, readFileSync(join(root, rel), 'utf8'))
}).join('\n')

const script = `#!/usr/bin/env bash
# dsh-go-unrestricted 破甲插件 —— 一键安装（在 dsh-go App 的「终端」里跑）
#
#   bash install.sh                # 装到 /root/.dsh/dsh-go/plugins/dsh-go-unrestricted
#   bash install.sh --agents-only  # 只写 AGENTS.md 兜底，不装插件（最快的临时方案）
#   bash install.sh --dir /别的    # 换插件目录
#   bash install.sh --no-fallback  # 装插件但不写 AGENTS.md 兜底块
#   bash install.sh --uninstall    # 移除插件链接与兜底块
#
# 只写文件与 profile 里的一条插件链接，不改任何系统配置。
set -eu

PLUGINS=/root/.dsh/dsh-go/plugins
FALLBACK=1
AGENTS_ONLY=0
UNINSTALL=0
while [ $# -gt 0 ]; do
  case "$1" in
    --dir) PLUGINS="$2"; shift 2 ;;
    --no-fallback) FALLBACK=0; shift ;;
    --agents-only) AGENTS_ONLY=1; shift ;;
    --uninstall) UNINSTALL=1; shift ;;
    -h|--help) sed -n '2,10p' "$0"; exit 0 ;;
    *) PLUGINS="$1"; shift ;;
  esac
done
DIR="$PLUGINS/${PKG}"
DSH_HOME_DIR="\${DSH_HOME:-$HOME/.dsh}"
AGENTS="$DSH_HOME_DIR/AGENTS.md"

# ── 卸载 ──────────────────────────────────────────────────────────────────
if [ "$UNINSTALL" = 1 ]; then
  command -v dsh >/dev/null 2>&1 && dsh plugin --profile web remove ${PKG} || true
  if [ -f "$AGENTS" ] && grep -q 'dsh-go-unrestricted:begin' "$AGENTS"; then
    tmp="$AGENTS.tmp.$$"
    awk '/<!-- dsh-go-unrestricted:begin/{skip=1} !skip{print} /<!-- dsh-go-unrestricted:end -->/{skip=0}' "$AGENTS" > "$tmp"
    # 用 cat 覆写而不是 mv：保住原文件的权限与 inode
    cat "$tmp" > "$AGENTS"
    rm -f "$tmp"
    echo "→ 已移除 AGENTS.md 兜底块"
  fi
  rm -rf "$DIR"
  echo "→ 已删除 $DIR。重开引擎生效。"
  exit 0
fi

# ── 只写兜底块 ────────────────────────────────────────────────────────────
if [ "$AGENTS_ONLY" = 1 ]; then
  mkdir -p "$DSH_HOME_DIR"
  if [ -f "$AGENTS" ] && grep -q 'dsh-go-unrestricted:begin' "$AGENTS"; then
    echo "→ AGENTS.md 已有兜底块，无需重复写入"
  else
    printf '%s\\n' '' "${AGENTS_BLOCK.replace(/\n/g, '\n')}" >> "$AGENTS"
    echo "→ 已写入兜底块：$AGENTS"
  fi
  echo "完成。重开引擎即可生效。移除：bash install.sh --uninstall"
  exit 0
fi

mkdir -p "$DIR/lib"
echo "→ 写入 $DIR"
${blocks}
echo "→ 插件文件就位"

# ── AGENTS.md 兜底块（带标记，重复执行不会叠份，卸载只删块） ──────────────
if [ "$FALLBACK" = 1 ]; then
  mkdir -p "$DSH_HOME_DIR"
  if [ -f "$AGENTS" ] && grep -q 'dsh-go-unrestricted:begin' "$AGENTS"; then
    echo "→ AGENTS.md 已有兜底块，跳过"
  else
    printf '%s\\n' '' "${AGENTS_BLOCK.replace(/\n/g, '\n')}" >> "$AGENTS"
    echo "→ 已写入兜底块：$AGENTS"
  fi
fi

# ── 挂进 profile（失败不中断：可能还没有 dsh 命令） ────────────────────────
echo
if command -v dsh >/dev/null 2>&1; then
  echo "→ dsh plugin --profile web add $DIR"
  dsh plugin --profile web add "$DIR" || echo "！挂载失败，可稍后手动执行上面这条"
else
  echo "！找不到 dsh 命令，稍后在 App 终端里手动执行："
  echo "   dsh plugin --profile web add $DIR"
fi

echo
echo "完成。回到对话页，输入框上方会出现「破甲 ON」；点开是面板。"
echo "改了 lib/ 之后要重启引擎才生效。"
`

mkdirSync(join(root, 'dist'), { recursive: true })
const out = join(root, 'dist', 'install.sh')
writeFileSync(out, script, 'utf8')
console.log('wrote', relative(root, out), script.length, 'chars')
