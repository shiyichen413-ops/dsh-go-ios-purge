#!/usr/bin/env python3
"""用模板渲染 dist-site/index.html：把 guide 全文、校验值、构建标记全部内嵌进页面。

用法：
  python3 tools/render-site.py <version> <size> <sha256> <sha256_short>

产物写到 dist-site/index.html（依赖 dist-site/guide.md 与 dist-site/SHA256SUMS 已存在）。
"""
import hashlib
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / "dist-site"
TPL = ROOT / "static-site-src" / "index.html.tpl"


def main() -> int:
    if len(sys.argv) < 5:
        print("用法: render-site.py <version> <size> <sha256> <sha256_short>", file=sys.stderr)
        return 2
    ver, size, sha, short = sys.argv[1:5]

    guide = (DIST / "guide.md").read_text(encoding="utf-8")
    sums = (DIST / "SHA256SUMS").read_text(encoding="utf-8")
    tpl = TPL.read_text(encoding="utf-8")

    now = datetime.now()
    stamp = now.strftime("%Y-%m-%d %H:%M")
    token = hashlib.sha256(f"{ver}|{sha}|{stamp}".encode()).hexdigest()[:8]

    values = {
        "VERSION": ver,
        "SIZE": str(size),
        "SHA256": sha,
        "SHA256_SHORT": short,
        "SHA256SUMS_TEXT": sums.rstrip("\n"),
        "GUIDE_HTML": guide,
        "BUILD_STAMP": stamp,
        "BUILD_TOKEN": token,
    }

    out = tpl
    for key, val in values.items():
        out = out.replace("{{%s}}" % key, val)
    if "{{" in out:
        print("！还有未替换的占位符", file=sys.stderr)
        return 1

    (DIST / "index.html").write_text(out, encoding="utf-8")
    print(f"   index.html {len(out.encode())} 字节 · 构建标记 {stamp} / {token} · 内嵌 guide {len(guide.encode())} 字节")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
