#!/usr/bin/env node
// 把 dist/install.sh 挂到「不会因为某个账号被封就全灭」多个渠道，并打印固定链接。
//
//   node tools/mirror-upload.mjs --list                  # 只看会传什么、现在有哪些渠道可用
//   npm publish <tgz> --access public                    # npm 渠道用官方命令（见 README 片段）
//   CODEBERG_TOKEN=... node tools/mirror-upload.mjs --codeberg --owner <user> --repo <repo> --tag v1.3.9
//   GITEE_TOKEN=...   node tools/mirror-upload.mjs --gitea --base https://gitcode.com/api/v5 --owner <user> --repo <repo> --tag v1.3.9
//
// 设计要点：
//   · 每个渠道独立成败，一个 403 不影响其他渠道；
//   · 上传后立刻回读校验 sha256，不匹配就把该渠道标成失败；
//   · 只依赖 fetch / FormData（node ≥18 自带），不装任何包。

import { readFileSync, statSync } from "node:fs";
import { createHash } from "node:crypto";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const FILE = process.env.MIRROR_FILE || join(ROOT, "dist/install.sh");
const ASSET = "install.sh";

const args = process.argv.slice(2);
const flag = (n) => args.includes(`--${n}`);
const opt = (n, d) => {
  const i = args.indexOf(`--${n}`);
  return i >= 0 && args[i + 1] && !args[i + 1].startsWith("--") ? args[i + 1] : d;
};

const pkg = JSON.parse(readFileSync(join(ROOT, "package.json"), "utf8"));
const TAG = opt("tag", `v${pkg.version}`);
const OWNER = opt("owner", "");
const REPO = opt("repo", pkg.name);
const BASE = opt("base", "https://codeberg.org/api/v1");

let buf;
try {
  buf = readFileSync(FILE);
} catch {
  console.error(`找不到 ${FILE}，先跑 node tools/make-installer.mjs`);
  process.exit(2);
}
const sha = createHash("sha256").update(buf).digest("hex");
const size = statSync(FILE).size;

const channels = [];
if (flag("list") || (!flag("codeberg") && !flag("gitea"))) {
  console.log(`工件：${FILE}`);
  console.log(`大小：${size} 字节 · sha256 ${sha}`);
  console.log("");
  console.log("可用渠道（按持久度）：");
  console.log("  npm          需要 npm token；版本号不可变，链接永久：");
  console.log(`               https://registry.npmjs.org/${pkg.name}/-/${pkg.name}-${pkg.version}.tgz`);
  console.log("  Codeberg     CODEBERG_TOKEN + --codeberg --owner <user> --repo <repo>");
  console.log("  Gitea 兼容   --gitea --base <https://主机/api/v1>（gitcode / 自建 Gitea 同理）");
  console.log("  Gitee        被封账号没法用；新账号请用 tools/gitee-release.mjs --owner 新账号");
  console.log("");
  console.log("匿名站实测（2026-11-15，本机网络）：catbox / 0x0 / x0.at / gofile / 1fichier / mediafire");
  console.log("全部不可用或被封 IP，所以「匿名永久托管」这条路当前不成立。");
  if (!flag("codeberg") && !flag("gitea")) process.exit(0);
}

async function giteaChannel({ token, base, kind }) {
  if (!token) return { channel: kind, ok: false, error: "缺 token" };
  if (!OWNER) return { channel: kind, ok: false, error: "缺 --owner" };
  const api = `${base}/repos/${OWNER}/${REPO}`;
  const headers = { Authorization: `token ${token}` };
  const j = async (res) => {
    const t = await res.text();
    try { return t ? JSON.parse(t) : null; } catch { return { raw: t.slice(0, 200) }; }
  };
  try {
    let rel = null;
    const listRes = await fetch(`${api}/releases?limit=50`, { headers });
    const list = await j(listRes);
    if (Array.isArray(list)) rel = list.find((r) => r.tag_name === TAG) || null;
    if (rel) {
      console.log(`[${kind}] 发行版已存在：${rel.name || rel.tag_name} (id=${rel.id})`);
    } else {
      const res = await fetch(`${api}/releases`, {
        method: "POST",
        headers: { ...headers, "Content-Type": "application/json" },
        body: JSON.stringify({
          tag_name: TAG,
          name: `${pkg.name} ${TAG}`,
          body: `sha256: ${sha}\n\n下载后校验：\n\n    sha256sum ${ASSET}\n`,
          target_commitish: opt("branch", "main"),
        }),
      });
      rel = await j(res);
      if (!res.ok) throw new Error(`建发行版 HTTP ${res.status} ${JSON.stringify(rel).slice(0, 200)}`);
      console.log(`[${kind}] 已建发行版 id=${rel.id}`);
    }
    const assets = Array.isArray(rel.assets) ? rel.assets : [];
    for (const a of assets.filter((x) => x.name === ASSET)) {
      const del = await fetch(`${api}/releases/${rel.id}/assets/${a.id}`, { method: "DELETE", headers });
      console.log(`[${kind}] 删旧附件 id=${a.id} → HTTP ${del.status}`);
    }
    const form = new FormData();
    form.append("attachment", new Blob([buf], { type: "application/octet-stream" }), ASSET);
    const up = await fetch(`${api}/releases/${rel.id}/assets?name=${ASSET}`, { method: "POST", headers, body: form });
    const asset = await j(up);
    if (!up.ok) throw new Error(`上传 HTTP ${up.status} ${JSON.stringify(asset).slice(0, 200)}`);
    const dl = asset?.browser_download_url || `${base.replace(/\/api\/v1$/, "")}/${OWNER}/${REPO}/releases/download/${TAG}/${ASSET}`;
    // 回读校验
    const back = Buffer.from(await (await fetch(dl)).arrayBuffer());
    const backSha = createHash("sha256").update(back).digest("hex");
    if (backSha !== sha) throw new Error(`回读 sha256 不一致：${backSha}`);
    return { channel: kind, ok: true, url: dl, bytes: back.length };
  } catch (e) {
    return { channel: kind, ok: false, error: String(e?.message ?? e) };
  }
}

if (flag("codeberg")) channels.push(await giteaChannel({ token: opt("token", process.env.CODEBERG_TOKEN || ""), base: "https://codeberg.org/api/v1", kind: "codeberg" }));
if (flag("gitea")) channels.push(await giteaChannel({ token: opt("token", process.env.GITEA_TOKEN || ""), base: BASE, kind: "gitea" }));

console.log("");
console.log("结果：");
for (const c of channels) {
  console.log(c.ok ? `  ✓ ${c.channel}  ${c.url}  (${c.bytes} 字节)` : `  ✗ ${c.channel}  ${c.error}`);
}
if (!channels.length) console.log("  （没有指定渠道：加 --codeberg / --gitea，或直接用 npm publish）");
console.log("");
console.log(`校验基准：sha256 ${sha}`);
process.exit(channels.some((c) => c.ok) || channels.length === 0 ? 0 : 1);
