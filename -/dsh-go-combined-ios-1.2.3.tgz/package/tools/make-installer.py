#!/usr/bin/env python3
"""从当前插件目录重建 dist/install.sh —— 用它自己当模板做「块替换」，不依赖任何外部样板。

用法：
    python3 tools/make-installer.py            # 就地重建 dist/install.sh
    python3 tools/make-installer.py --check    # 只比对，不写盘（返回 0=一致）

原理：dist/install.sh 里每个文件都是一段
    cat > "$DIR/<相对路径>" <<'<MARKER>'
    ...正文...
    <MARKER>
把正文换成工作树里对应文件的最新内容，其余（header / AGENTS 兜底块 / 挂载逻辑）原样保留。
"""
import os, re, sys, hashlib

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(BASE, "dist", "install.sh")
CHECK = "--check" in sys.argv

if not os.path.exists(SRC):
    sys.exit("找不到 dist/install.sh，先拿到一个可用的安装器当模板")

text = open(SRC, encoding="utf-8").read()
lines = text.split("\n")
out, i, replaced, missing = [], 0, 0, []
while i < len(lines):
    line = lines[i]
    m = re.match(r'^cat > "\$DIR/(.+)" <<\'.+\'$', line)
    if m:
        rel = m.group(1)
        marker = line.split("<<'", 1)[1][:-1]
        j = i + 1
        while j < len(lines) and lines[j] != marker:
            j += 1
        if j >= len(lines):
            sys.exit(f"!! 块 {rel} 找不到结束标记 {marker}")
        path = os.path.join(BASE, rel)
        if os.path.isfile(path):
            body = open(path, encoding="utf-8").read()
            if body.endswith("\n"):
                body = body[:-1]
            if marker in body.split("\n"):
                sys.exit(f"!! {rel} 正文里出现结束标记，换一个标记")
            out.append(line); out.extend(body.split("\n")); out.append(marker)
            replaced += 1
        else:
            missing.append(rel)
        i = j + 1
        continue
    out.append(line); i += 1

res = "\n".join(out)
old_sha = hashlib.sha256(text.encode()).hexdigest()
new_sha = hashlib.sha256(res.encode()).hexdigest()

if CHECK:
    print(f"{'一致' if old_sha == new_sha else '不一致'} · {replaced} 个块 · {len(res.encode())} 字节")
    sys.exit(0 if old_sha == new_sha else 1)

if old_sha != new_sha:
    open(SRC, "w", encoding="utf-8").write(res)
print(f"重建完成：{replaced} 个内嵌文件 · {len(res.encode())} 字节 · sha256 {new_sha}")
if missing:
    print(f"⚠ 工作树里缺 {len(missing)} 个文件（保留原内容）：{missing[:5]}")
