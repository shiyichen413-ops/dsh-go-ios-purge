$ErrorActionPreference = 'Stop'
$dir = 'D:\dsh\dsh-go-unrestricted\tutorial'
$src = Join-Path $dir 'dsh-go破甲教程.docx'
$pdf = Join-Path $dir 'dsh-go破甲教程.pdf'
if (Test-Path $pdf) { Remove-Item $pdf -Force }
"src exists: " + (Test-Path $src)

$app = $null
$doc = $null
try {
    $app = New-Object -ComObject KWPS.Application
    $app.Visible = $false
    try { $app.DisplayAlerts = 0 } catch {}
    "COM ok: " + $app.Name + " " + $app.Version
    $doc = $app.Documents.Open($src, $false, $true)
    "opened pages: " + $doc.ComputeStatistics(2)
    $ok = $false
    try {
        $doc.ExportAsFixedFormat($pdf, 17)
        $ok = $true
        "export via ExportAsFixedFormat"
    } catch {
        "ExportAsFixedFormat failed: " + $_.Exception.Message
    }
    if (-not $ok) {
        try {
            $doc.SaveAs2($pdf, 17)
            $ok = $true
            "export via SaveAs2"
        } catch {
            "SaveAs2 failed: " + $_.Exception.Message
        }
    }
    if (-not $ok) { throw "no export path worked" }
} finally {
    if ($doc) { try { $doc.Close(0) } catch {} }
    if ($app) { try { $app.Quit() } catch {} }
}

if (Test-Path $pdf) {
    "PDF bytes: " + (Get-Item $pdf).Length
} else {
    "PDF MISSING"
}
