// 只读引擎的「最小覆盖层」生成器（iOS Fish Pocket / 沙盒只读宿主）
//
// 背景：有些宿主把 @deepseek-ai 放在只读的 App 包里，补丁写不进去。
// 做法：只把「补丁实际命中的那几个包」复制到 ~/.dsh/host-patch，
//      框架依赖（cordis/schemastery/…）用转发壳指回原件 —— ESM 按 URL 缓存，实例不会分裂；
//      再往 profile 的 cordis.patch.yml 写 insert 行（改前备份）。
//
//   node tools/readonly-overlay.mjs                  # 只看计划，不动文件
//   node tools/readonly-overlay.mjs --apply          # 真做
//   node tools/readonly-overlay.mjs --rollback       # 撤销（恢复 patch 文件 + 删覆盖层）
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

const APPLY = process.argv.includes('--apply');
const ROLLBACK = process.argv.includes('--rollback');
const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh');
const OVERLAY = path.join(HOME, 'host-patch', 'node_modules', '@deepseek-ai');
const PROFILE = path.join(HOME, 'profiles', 'web', 'cordis.patch.yml');
const BACKUP = PROFILE + '.overlay.bak';

const FRAMEWORK = ['cordis', 'dsh-scope', 'schemastery', 'dsh-llm', 'dsh-fs', 'dsh-fs-local', 'dsh-sandbox'];

// 只覆盖「拆闸」真正相关的包。其余命中项要么是描述文本中性化（收益低），
// 要么是 session / llm / app-boot 这类核心服务 —— 挂第二份会把引擎拆坏。
const KEY_PKGS = [
  'dsh-user-approval',
  'dsh-sandbox-local',
  'dsh-sandbox-policy',
  'dsh-fs-sandbox',
  'dsh-fs-observation-policy',
  'dsh-system-prompt',
];
const ALL = process.argv.includes('--all');

/** 找宿主 @deepseek-ai：环境变量 > 常见位置 > 运行时自带 */
function findHostRoot() {
  const cands = [
    process.env.DSH_AI_ROOT,
    '/opt/dsh/nodejs-project/node_modules/@deepseek-ai',
    path.join(path.dirname(process.execPath), '..', 'node_modules', '@deepseek-ai'),
    '/private/var/mobile/Containers/Data/Application/../dsh-runtime/tree/node_modules/@deepseek-ai',
  ].filter(Boolean);
  for (const c of cands) {
    try {
      if (fs.existsSync(path.join(c, 'dsh-base', 'package.json'))) return c;
    } catch {}
  }
  // 逐级向上找
  for (const start of [process.cwd(), path.dirname(process.execPath)]) {
    let cur = start;
    for (let i = 0; i < 10; i++) {
      const c = path.join(cur, 'node_modules', '@deepseek-ai');
      if (fs.existsSync(path.join(c, 'dsh-base', 'package.json'))) return c;
      const up = path.dirname(cur);
      if (up === cur) break;
      cur = up;
    }
  }
  throw new Error('找不到宿主 @deepseek-ai');
}

function isWritable(dir) {
  try {
    const probe = path.join(dir, '.wtest-' + process.pid);
    fs.writeFileSync(probe, 'x');
    fs.unlinkSync(probe);
    return true;
  } catch {
    return false;
  }
}

function entryOf(pkgDir) {
  const pj = JSON.parse(fs.readFileSync(path.join(pkgDir, 'package.json'), 'utf8'));
  const ex = pj.exports && (pj.exports['.'] || pj.exports);
  const cands = [];
  if (typeof ex === 'string') cands.push(ex);
  else if (ex) cands.push(ex.node, ex.import, ex.default);
  cands.push(pj.module, pj.main, 'lib/index.js', 'dist/index.js', 'index.js');
  for (const c of cands) {
    if (typeof c !== 'string') continue;
    const abs = path.join(pkgDir, c);
    if (fs.existsSync(abs) && fs.statSync(abs).isFile()) return abs;
  }
  return null;
}

/**
 * 生成转发壳：入口和**所有子路径**（package.json 的 exports）都指回原件。
 * 保留 exports 映射是关键 —— node-addon-system 这类包会被 `pkg/landlock-run` 这样引用，
 * 删掉 exports 就变成 Cannot find module。
 */
function writeShim(srcDir, dstDir) {
  const entry = entryOf(srcDir);
  if (!entry) return false;
  fs.mkdirSync(dstDir, { recursive: true });
  fs.writeFileSync(
    path.join(dstDir, 'index.js'),
    `import * as m from '${entry}'\nexport * from '${entry}'\nexport default m.default\n`,
  );
  const pj = JSON.parse(fs.readFileSync(path.join(srcDir, 'package.json'), 'utf8'));
  let n = 0;
  const forward = (target) => {
    if (typeof target !== 'string' || !target.startsWith('./')) return target;
    const abs = path.join(srcDir, target);
    if (!fs.existsSync(abs)) return target;
    const local = `shim-${n++}.js`;
    fs.writeFileSync(
      path.join(dstDir, local),
      `import * as m from '${abs}'\nexport * from '${abs}'\nexport default m.default\n`,
    );
    return './' + local;
  };
  const walk = (node) => {
    if (typeof node === 'string') return forward(node);
    if (Array.isArray(node)) return node.map(walk);
    if (node && typeof node === 'object') {
      const out = {};
      for (const [k, v] of Object.entries(node)) out[k] = walk(v);
      return out;
    }
    return node;
  };
  if (pj.exports) pj.exports = walk(pj.exports);
  pj.main = 'index.js';
  delete pj.module;
  delete pj.types;
  fs.writeFileSync(path.join(dstDir, 'package.json'), JSON.stringify(pj, null, 2) + '\n');
  return true;
}

const rollback = () => {
  if (fs.existsSync(BACKUP)) {
    fs.copyFileSync(BACKUP, PROFILE);
    fs.rmSync(BACKUP);
    console.log('已恢复 profile patch');
  }
  fs.rmSync(path.join(HOME, 'host-patch'), { recursive: true, force: true });
  console.log('已删除覆盖层');
};

if (ROLLBACK) {
  rollback();
  process.exit(0);
}

const root = findHostRoot();
const writable = isWritable(root);
console.log(`宿主引擎: ${root}`);
console.log(`可写: ${writable ? '是（不需要覆盖层）' : '否（只读，走覆盖层）'}`);
if (writable) {
  console.log('这台机器直接跑 purge_patch_apply 就行，不需要本脚本。');
  process.exit(0);
}

// 命中哪些包：用补丁表 probe 一遍
const core = await import(new URL('../lib/core/patches/lib/core.mjs', import.meta.url).href);
const rows = core.probe(root);
const hitPkgs = new Set();
for (const r of rows) {
  if (!['hit', 'partial'].includes(r.status)) continue;
  for (const f of r.files || []) {
    const rel = path.relative(root, f).split(path.sep)[0];
    if (rel) hitPkgs.add(rel);
  }
}
let pkgs = [...hitPkgs].filter((p) => !FRAMEWORK.includes(p) && !p.startsWith('node-addon-'));
const skipped = ALL ? [] : pkgs.filter((p) => !KEY_PKGS.includes(p));
if (!ALL) pkgs = pkgs.filter((p) => KEY_PKGS.includes(p));
console.log(`\n命中的包里挑出 ${pkgs.length} 个要覆盖（安全名单）：`);
for (const p of pkgs) console.log('  ' + p);
if (skipped.length) console.log(`\n跳过 ${skipped.length} 个（核心服务或收益低，硬挂会拆坏引擎）：\n  ` + skipped.join(', '));

if (!APPLY) {
  console.log('\n（预览模式。加 --apply 执行）');
  process.exit(0);
}

// 1) 覆盖层：只复制命中包
fs.rmSync(path.join(HOME, 'host-patch'), { recursive: true, force: true });
fs.mkdirSync(OVERLAY, { recursive: true });
for (const p of pkgs) {
  fs.cpSync(path.join(root, p), path.join(OVERLAY, p), { recursive: true });
}
console.log(`\n已复制 ${pkgs.length} 个包 → ${OVERLAY}`);

// 1.5) 普通依赖（zod 这类）直接整包复制，否则副本里的 import 解析不到
const HOST_NM = path.dirname(root); // …/node_modules
const overNm = path.dirname(OVERLAY); // …/host-patch/node_modules
const needDeps = new Set();
for (const p of pkgs) {
  try {
    const pj = JSON.parse(fs.readFileSync(path.join(root, p, 'package.json'), 'utf8'));
    for (const d of Object.keys(pj.dependencies || {})) {
      if (!d.startsWith('@deepseek-ai/') && !FRAMEWORK.includes(d)) needDeps.add(d);
    }
  } catch {}
}
let copiedDeps = 0;
for (const d of needDeps) {
  const src = path.join(HOST_NM, d);
  const dst = path.join(overNm, d);
  if (!fs.existsSync(src) || fs.existsSync(dst)) continue;
  fs.cpSync(src, dst, { recursive: true });
  copiedDeps++;
}
console.log(`依赖补齐 ${copiedDeps} 个${needDeps.size ? '（' + [...needDeps].join(', ') + '）' : ''}`);


// 2) 框架依赖转发壳（防第二套 cordis）
let shims = 0;
for (const p of FRAMEWORK) {
  const src = path.join(root, p);
  if (!fs.existsSync(src)) continue;
  const dir = path.join(OVERLAY, p);
  if (writeShim(src, dir)) shims++;
  shims++;
}
console.log(`转发壳 ${shims} 个（${FRAMEWORK.join(', ')}）`);

// 2.5) 覆盖包自己的 @deepseek-ai 依赖（例如 node-addon-system）也做转发壳：
//      这类包常带原生 .node，复制会变成第二份绑定；转发壳指回原件才是同一个实例。
const scopedNeed = new Set();
for (const p of pkgs) {
  try {
    const pj = JSON.parse(fs.readFileSync(path.join(root, p, 'package.json'), 'utf8'));
    for (const d of Object.keys(pj.dependencies || {})) {
      if (!d.startsWith('@deepseek-ai/')) continue;
      const short = d.slice('@deepseek-ai/'.length);
      if (!pkgs.includes(short) && !FRAMEWORK.includes(short)) scopedNeed.add(short);
    }
  } catch {}
}
let scopedShims = 0;
for (const p of scopedNeed) {
  const src = path.join(root, p);
  if (!fs.existsSync(src)) continue;
  const dir = path.join(OVERLAY, p);
  if (writeShim(src, dir)) scopedShims++;
}
console.log(`作用域依赖转发壳 ${scopedShims} 个${scopedNeed.size ? '（' + [...scopedNeed].join(', ') + '）' : ''}`);

// 3) 补丁层：给覆盖层里的副本打补丁
const report = core.apply(OVERLAY, { backupDir: path.join(HOME, 'dsh-purge', 'overlay-backup') });
console.log(`\n副本打补丁：ok ${report.applied} · 失败 ${report.failed}`);
for (const e of report.errors || []) console.log('  ERR', e.rel, e.error);

// 这些包注册的是同名服务，挂第二份会冲突 —— 必须先 disable 原行。
const ROW_ID = {
  'dsh-user-approval': 'approval',
  'dsh-sandbox-local': 'sandbox',
  'dsh-sandbox-policy': 'sandbox-policy',
  'dsh-fs-sandbox': 'fs-sandbox',
  'dsh-system-prompt': 'system-prompt',
  'dsh-fs-observation-policy': 'fs-observation-policy',
};

// 4) 写 profile 的 insert 行（改前备份）
if (!fs.existsSync(PROFILE)) {
  console.log(`\n没有 ${PROFILE}（宿主用默认装配），覆盖层无法挂载 —— 请把下面这段交给作者或手动加进 profile 配置：`);
} else {
  if (!fs.existsSync(BACKUP)) fs.copyFileSync(PROFILE, BACKUP);
  let yml = fs.readFileSync(PROFILE, 'utf8');
  const marker = '# dsh-go-combined-ios readonly overlay';
  if (!yml.includes(marker)) {
    const dis = pkgs.filter((p) => ROW_ID[p]).map((p) => `    - { id: ${ROW_ID[p]}, disabled: true }`);
    const lines = [marker];
    if (dis.length) lines.push('# 先关掉原来的行（按 id 覆盖）', '- update:', ...dis);
    lines.push('- insert:');
    for (const p of pkgs) {
      lines.push(`    - id: ${p.replace(/^dsh-/, '')}-overlay`);
      lines.push(`      name: file://${path.join(OVERLAY, p, 'lib', 'index.js')}`);
    }
    fs.appendFileSync(PROFILE, '\n' + lines.join('\n') + '\n');
    console.log(`\n已写入 ${PROFILE}（备份 ${path.basename(BACKUP)}）`);
  } else {
    console.log('\nprofile 里已有覆盖层登记，跳过');
  }
}

console.log('\n重启引擎生效。撤销：node tools/readonly-overlay.mjs --rollback');
