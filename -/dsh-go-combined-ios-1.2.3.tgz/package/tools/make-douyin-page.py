# -*- coding: utf-8 -*-
"""生成抖音图文用的「一页纸」安装说明 docx（A4 单页，手机截图直接用）。

用法：
    python3 tools/make-douyin-page.py <version> <size> <sha256> [输出路径]

默认输出 /sdcard/Download/DSH-Go/抖音图文-破甲安装说明.docx
"""
import os
import sys

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

CN = "微软雅黑"
MONO = "Consolas"
INK = RGBColor(0x1A, 0x1A, 0x1A)
MUTED = RGBColor(0x70, 0x70, 0x70)
ACCENT = RGBColor(0x0B, 0x5C, 0x8A)

BASE = "https://dshgo.oss-cn-hangzhou.aliyuncs.com"


def set_font(run, size, bold=False, color=INK, mono=False):
    name = MONO if mono else CN
    run.font.name = name
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    for attr in ("w:ascii", "w:hAnsi", "w:cs"):
        rfonts.set(qn(attr), name)
    rfonts.set(qn("w:eastAsia"), name)
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color


def shade(par, fill="F2F4F7"):
    ppr = par._p.get_or_add_pPr()
    el = OxmlElement("w:shd")
    el.set(qn("w:val"), "clear")
    el.set(qn("w:color"), "auto")
    el.set(qn("w:fill"), fill)
    ppr.append(el)


def tight(par, before=0, after=2.4, line=1.08):
    pf = par.paragraph_format
    pf.space_before = Pt(before)
    pf.space_after = Pt(after)
    pf.line_spacing = line


def para(doc, text, size, bold=False, color=INK, mono=False, before=0, after=1.5, fill=None, indent=0.0):
    p = doc.add_paragraph()
    tight(p, before, after)
    if indent:
        p.paragraph_format.left_indent = Cm(indent)
    set_font(p.add_run(text), size, bold=bold, color=color, mono=mono)
    if fill:
        shade(p, fill)
    return p


def code(doc, text, size=8.1):
    p = doc.add_paragraph()
    tight(p, 1.5, 3)
    p.paragraph_format.left_indent = Cm(0.3)
    p.paragraph_format.right_indent = Cm(0.1)
    set_font(p.add_run(text), size, mono=True)
    shade(p, "F2F4F7")


def step(doc, n, text):
    p = doc.add_paragraph()
    tight(p, 12, 2)
    set_font(p.add_run(f"{n}　"), 12.4, bold=True, color=ACCENT)
    set_font(p.add_run(text), 12.4, bold=True)


def bullet(doc, text, size=9.6, color=INK):
    p = doc.add_paragraph()
    tight(p, 0.5, 2.5)
    p.paragraph_format.left_indent = Cm(0.45)
    set_font(p.add_run("· " + text), size, color=color)


def rule(doc, before=9, after=9):
    p = doc.add_paragraph()
    tight(p, before, after)
    ppr = p._p.get_or_add_pPr()
    borders = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "6")
    bottom.set(qn("w:color"), "D0D5DD")
    borders.append(bottom)
    ppr.append(borders)


def cell_text(cell, text, size=8.4, bold=False, mono=False, color=INK, align=None):
    cell.text = ""
    p = cell.paragraphs[0]
    tight(p, 0.5, 0.5)
    if align is not None:
        p.alignment = align
    set_font(p.add_run(text), size, bold=bold, mono=mono, color=color)


def adapt_table(doc):
    rows = [
        ("宿主 dsh", "自检结果"),
        ("0.2.2-rc.1", "20/20 层 · 注入 1/1 · 权限 1/1 · 补丁 72/72 · 全通过"),
        ("0.2.2-rc.2", "20/20 层 · 注入 1/1 · 权限 1/1 · 补丁 70/70 · 全通过"),
        ("0.2.2-rc.3", "20/20 层 · 注入 1/1 · 权限 1/1 · 补丁 70/70 · 全通过"),
    ]
    t = doc.add_table(rows=len(rows), cols=2)
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, (a, b) in enumerate(rows):
        cell_text(t.cell(i, 0), a, 8.4, bold=(i == 0), mono=(i > 0),
                  color=(MUTED if i == 0 else INK))
        cell_text(t.cell(i, 1), b, 8.4, bold=(i == 0), color=(MUTED if i == 0 else INK))
        t.rows[i].height = Cm(0.58)
    t.columns[0].width = Cm(3.2)
    t.columns[1].width = Cm(14.4)
    return t


def build(ver, size, sha, out):
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21), Cm(29.7)
    sec.left_margin = sec.right_margin = Cm(1.5)
    sec.top_margin = Cm(1.1)
    sec.bottom_margin = Cm(0.9)

    p = doc.add_paragraph()
    tight(p, 0, 1)
    set_font(p.add_run("dsh-go 破甲插件"), 10, color=MUTED)
    set_font(p.add_run("　v" + ver + "　·　Android / proot，不需要 root"), 10, bold=True, color=ACCENT)

    p = doc.add_paragraph()
    tight(p, 0, 3)
    set_font(p.add_run("一条命令装好，不再拒答"), 20, bold=True)

    para(doc, "适配的宿主版本（真装到隔离目录、打完补丁再跑自检的结果）", 9.2, color=MUTED, after=2)
    adapt_table(doc)

    rule(doc)

    cmd = (
        "node -e \"fetch('" + BASE + "/install.sh').then(r=>r.arrayBuffer()).then(b=>"
        "{require('fs').writeFileSync('/root/install.sh',Buffer.from(b));"
        "console.log('已下载',b.byteLength,'字节')})\" && echo \""
        + sha + "  /root/install.sh\" | sha256sum -c - && bash /root/install.sh"
    )

    step(doc, "1", "打开 dsh-go 的「终端」")
    para(doc, "不是系统终端，是 App 自带那个。不需要 root，也不用装 curl。", 9.6, color=MUTED)

    step(doc, "2", "整条粘进去，回车")
    code(doc, cmd, 7.7)
    para(doc, "它会：下载 → 校验 sha256（对不上就中止）→ 安装。2.1 MB，手机上两三秒。", 9.6, color=MUTED)

    step(doc, "3", "彻底退出 dsh-go，再打开")
    para(doc, "宿主只在启动时读插件：切后台不算，要从最近任务里划掉。", 9.6, color=MUTED)

    step(doc, "4", "输入框上方出现「破甲」，跑一次自检")
    code(doc, "cd /root/.dsh/dsh-go/plugins/dsh-go-unrestricted && node lib/engine.js selfcheck", 8.1)
    para(doc, "看到「补丁 xx/xx · 全通过」就成了（rc.1 是 72/72，rc.2/rc.3 是 70/70；分母随宿主变，关键是最后三个字）。", 9.6, color=MUTED)

    rule(doc)

    para(doc, "装完你会看到", 10.8, bold=True, color=ACCENT, after=1.5)
    bullet(doc, "输入框上方多一条「破甲」，点开是面板：状态 / 补丁 / 备份维护 / 模式")
    bullet(doc, "三个可选模式预设：无限制 · 无限制（子任务）· 红队")
    bullet(doc, "红队资产库与 23 篇技能，对话里直接调")

    rule(doc)

    para(doc, "它到底改了什么", 10.8, bold=True, color=ACCENT, after=1.5)
    bullet(doc, "提示词层：每一步系统提示里带授权段，另写 AGENTS.md 兜底块（三路注入，哪条通走哪条）")
    bullet(doc, "引擎层：90 条本地补丁，改宿主 node_modules/@deepseek-ai/dsh-*（每改一个文件先备份 .dshpurge.bak）")
    bullet(doc, "自检层：20 层逐层核对上面这些改写真的在位，锚点漂了就明确报断点，不静默跳过")

    rule(doc)

    para(doc, "三个常见坑", 10.8, bold=True, color=ACCENT, after=1.5)
    bullet(doc, "sha256 报 FAILED：文件下断了，删掉 /root/install.sh 重下，别硬装")
    bullet(doc, "自检不是「全通过」：把 node lib/engine.js status 的输出发我")
    bullet(doc, "换过宿主版本：先删旧备份 find /opt/dsh/node_modules/@deepseek-ai -name '*.dshpurge.bak' -delete")

    rule(doc)

    p = doc.add_paragraph()
    tight(p, 2, 1)
    set_font(p.add_run("校验值　"), 9.0, bold=True, color=MUTED)
    set_font(p.add_run(f"{size} 字节　sha256 "), 9.0, color=INK)
    set_font(p.add_run(sha), 7.0, mono=True)

    p = doc.add_paragraph()
    tight(p, 2, 1)
    set_font(p.add_run("说明页　"), 9.0, bold=True, color=MUTED)
    set_font(p.add_run(BASE + "/index.html"), 9.0, mono=True, color=ACCENT)
    set_font(p.add_run("　（自包含，全文在这一页里；微信里点 .md 打不开是正常的）"), 8.2, color=MUTED)

    p = doc.add_paragraph()
    tight(p, 2, 1)
    set_font(p.add_run("卸载 / 还原　"), 9.0, bold=True, color=MUTED)
    set_font(p.add_run("bash /root/install.sh --uninstall　·　node lib/engine.js revert"), 8.2, mono=True)

    para(doc, "它会削弱宿主的安全阀（不拒答、少审批、沙箱直通），装之前自己判断；每改一个文件都留 .dshpurge.bak，可完整回滚。",
         8.0, color=MUTED, before=6)

    doc.save(out)
    print(f"已生成 {out} · {os.path.getsize(out)} 字节")


if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("用法: make-douyin-page.py <version> <size> <sha256> [out]", file=sys.stderr)
        raise SystemExit(2)
    ver, size, sha = sys.argv[1:4]
    out = sys.argv[4] if len(sys.argv) > 4 else "/sdcard/Download/DSH-Go/抖音图文-破甲安装说明.docx"
    build(ver, size, sha, out)
