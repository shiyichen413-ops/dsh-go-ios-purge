#!/usr/bin/env bash
# dsh-go-unrestricted —— 重启本机引擎
#
#   bash tools/restart.sh            # 只看状态（pid / 运行时长 / 端口）
#   bash tools/restart.sh --force    # 给引擎发 SIGTERM，并等它退出
#
# 说明：dsh-go 的引擎由 App 拉起，插件没有「自我重启」的权限。
# 这里做的是把进程干净地停掉，然后在 App 的「引擎」页点一次启动（或让自动启动接管）。
set -u

PORT="${DSH_WEB_PORT:-3080}"
PIDFILE=/tmp/dsh-web.pid
FORCE=0
[ "${1:-}" = "--force" ] && FORCE=1

pid=""
if [ -f "$PIDFILE" ]; then
  pid="$(cat "$PIDFILE" 2>/dev/null | tr -dc '0-9')"
fi
if [ -z "$pid" ] || ! kill -0 "$pid" 2>/dev/null; then
  pid="$(ps -eo pid,cmd 2>/dev/null | grep -E 'dsh( |/).*( web)( |$)|bin\.js web' | grep -v grep | awk '{print $1}' | head -1)"
fi

if [ -z "$pid" ]; then
  echo "→ 没发现运行中的引擎（端口 $PORT）"
  echo "  在 App 的「引擎」页点启动即可。"
  exit 0
fi

uptime="$(ps -o etime= -p "$pid" 2>/dev/null | tr -d ' ')"
echo "→ 引擎 pid=$pid 运行时长=${uptime:-?}"
echo "  端口：http://127.0.0.1:$PORT（token 每次启动都会变，旧链接会 401）"

if [ "$FORCE" != 1 ]; then
  echo
  echo "只查看模式。要停掉并让 App 重新拉起："
  echo "  bash tools/restart.sh --force"
  exit 0
fi

echo "→ 发送 SIGTERM 给 $pid"
kill -TERM "$pid" 2>/dev/null || { echo "！kill 失败（权限或已退出）"; exit 1; }
for i in $(seq 1 20); do
  kill -0 "$pid" 2>/dev/null || { echo "→ 已退出（${i}00ms）"; break; }
  sleep 0.1
done
if kill -0 "$pid" 2>/dev/null; then
  echo "！10 秒内没退出，改发 SIGKILL"
  kill -KILL "$pid" 2>/dev/null || true
fi
echo
echo "完成。回到 App 的「引擎」页点一次启动；本会话会断开重连。"
