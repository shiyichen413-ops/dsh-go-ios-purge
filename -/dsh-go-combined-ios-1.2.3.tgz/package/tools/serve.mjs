// 手机取文件用的小静态服务：只读，只服务插件目录，不写任何东西。
//
//   node tools/serve.mjs [端口]     → http://<本机局域网IP>:<端口>/
//
// 手机连同一个 WiFi，浏览器打开上面地址即可下载 install.sh / zip。
import { createReadStream, statSync, readdirSync } from 'node:fs'
import { createServer } from 'node:http'
import { networkInterfaces } from 'node:os'
import { dirname, join, normalize } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = dirname(dirname(fileURLToPath(import.meta.url)))
const port = Number(process.argv[2] ?? 8899)

const MIME = {
  '.sh': 'text/plain; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.yml': 'text/plain; charset=utf-8',
  '.md': 'text/plain; charset=utf-8',
  '.zip': 'application/zip',
}

const index = () => {
  const files = ['dist/install.sh', 'dsh-go-unrestricted.zip', 'README.md', 'package.json', 'lib/directive.js']
  const items = files
    .map((f) => {
      try {
        const size = statSync(join(root, f)).size
        return `<li><a href="/${f}">${f}</a> <small>${size} B</small></li>`
      } catch {
        return `<li>${f} <small>（未生成）</small></li>`
      }
    })
    .join('\n')
  const top = readdirSync(join(root, 'lib')).map((f) => `<li><a href="/lib/${f}">lib/${f}</a></li>`).join('\n')
  return `<!doctype html><meta charset="utf-8"><title>dsh-go-unrestricted</title>
<h3>dsh-go 破甲插件</h3><ul>${items}</ul><h4>lib/</h4><ul>${top}</ul>`
}

const server = createServer((req, res) => {
  const url = decodeURIComponent((req.url ?? '/').split('?')[0])
  if (url === '/') {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
    res.end(index())
    return
  }
  const rel = normalize(url).replace(/^([/\\])+/, '')
  if (rel.includes('..')) {
    res.writeHead(403).end('no')
    return
  }
  const file = join(root, rel)
  try {
    const st = statSync(file)
    if (!st.isFile()) throw new Error('dir')
    res.writeHead(200, {
      'content-type': MIME[file.slice(file.lastIndexOf('.'))] ?? 'application/octet-stream',
      'content-length': st.size,
      'content-disposition': `attachment; filename="${rel.split('/').pop()}"`,
    })
    createReadStream(file).pipe(res)
  } catch {
    res.writeHead(404).end('not found')
  }
})

server.listen(port, '0.0.0.0', () => {
  const ips = Object.values(networkInterfaces())
    .flat()
    .filter((i) => i && i.family === 'IPv4' && !i.internal)
    .map((i) => i.address)
  console.log(`listening on ${port}`)
  for (const ip of ips) console.log(`  http://${ip}:${port}/`)
})
