#!/usr/bin/env bash
# 一条命令发版到阿里云 OSS 公开桶：重建安装器 → 生成站点 → 上传 → 回读校验。
#
#   bash tools/publish-oss.sh              # 重建 + 上传（需要 OSS 凭据）
#   bash tools/publish-oss.sh --dry-run    # 只重建、只打印计划，不联网
#   bash tools/publish-oss.sh --guides     # 顺带把 guide.md / 使用说明.md 也传一遍
#
# 凭据（二选一）：
#   环境变量 OSS_AK / OSS_SK / OSS_BUCKET / OSS_ENDPOINT
#   或 ~/.dsh/oss-put.env（KEY=VALUE 每行一条，chmod 600）
set -euo pipefail

ROOT=$(cd "$(dirname "$0")/.." && pwd)
cd "$ROOT"

DRY=0; GUIDES=0
for a in "$@"; do
  case "$a" in
    --dry-run) DRY=1 ;;
    --guides) GUIDES=1 ;;
    *) echo "未知参数：$a"; exit 2 ;;
  esac
done

ENVF="${DSH_HOME:-$HOME/.dsh}/oss-put.env"
if [ -f "$ENVF" ]; then set -a; . "$ENVF"; set +a; fi
OSS_BUCKET=${OSS_BUCKET:-dshgo}
OSS_ENDPOINT=${OSS_ENDPOINT:-oss-cn-hangzhou.aliyuncs.com}
BASE="https://${OSS_BUCKET}.${OSS_ENDPOINT}"

VERSION=$(node -e "console.log(require('./package.json').version)")
echo "→ 版本 $VERSION"

# 先重建，再核对内嵌版本是否一致（顺序不能反：重建前必然不一致）
# 发布物只允许来自干净树：本机私改由 local/clean-build.py 反向还原后再打包。
echo "→ 重建 dist/install.sh（干净版：剔除本机私改）"
CLEAN_BUILD="${DSHGO_CLEAN_BUILD:-$HOME/.dsh/dsh-go/local/clean-build.py}"
if [ ! -f "$CLEAN_BUILD" ]; then
  echo "！找不到干净构建脚本：$CLEAN_BUILD"
  echo "  拒绝发布 —— 避免把本机私改打进安装器。"
  exit 3
fi
python3 "$CLEAN_BUILD" --base "$ROOT" >/dev/null
PREFLIGHT="${DSHGO_PREFLIGHT:-$HOME/.dsh/dsh-go/local/preflight-clean.sh}"
if [ -f "$PREFLIGHT" ]; then
  bash "$PREFLIGHT" "$ROOT/dist/install.sh" || exit 3
else
  for sig in "webAppPreset""Yml" "local-patches"".json" "clean-build"".py"; do
    if grep -q -F -- "$sig" dist/install.sh; then
      echo "！安装器含本机私改特征「$sig」，拒绝发布"; exit 3
    fi
  done
fi
IN_INST=$(grep -m1 '"version"' dist/install.sh | sed 's/.*"\(.*\)".*/\1/')
if [ "$VERSION" != "$IN_INST" ]; then
  echo "！重建后 dist/install.sh 内嵌版本仍是 $IN_INST（package.json 是 $VERSION）；检查 package.json 是否被写坏"
  exit 2
fi
cp dist/install.sh install.sh
SIZE=$(wc -c < dist/install.sh | tr -d ' ')
SHA=$(sha256sum dist/install.sh | cut -d' ' -f1)
SHORT="${SHA:0:8}…${SHA: -7}"
echo "→ $SIZE 字节 · sha256 $SHA"

echo "→ 生成站点 dist-site/"
rm -rf dist-site && mkdir -p dist-site
cp dist/install.sh dist-site/install.sh
( cd dist-site && sha256sum install.sh > SHA256SUMS && cp SHA256SUMS install.sh.sha256 )
# 指南先渲染（index.html 要把全文内嵌进去，顺序不能反）
python3 - "$VERSION" "$SIZE" "$SHA" <<'PYG'
import sys, pathlib
ver, size, sha = sys.argv[1:4]
html = pathlib.Path("static-site-src/guide.md.tpl").read_text(encoding="utf-8")
for k, v in {"{{VERSION}}": ver, "{{SIZE}}": size, "{{SHA256}}": sha}.items():
    html = html.replace(k, v)
assert "{{" not in html, "guide 还有未替换的占位符"
pathlib.Path("dist-site/guide.md").write_text(html, encoding="utf-8")
pathlib.Path("dist-site/使用说明.md").write_text(html, encoding="utf-8")
print(f"   guide.md {len(html.encode())} 字节")
PYG
# 首页自包含：内嵌 guide 全文 + 校验值 + 构建标记（子页面点不开也能看全内容）
python3 tools/render-site.py "$VERSION" "$SIZE" "$SHA" "$SHORT"

if [ "$DRY" = 1 ]; then
  echo "→ dry-run：不联网。产物在 dist-site/"
  ls -l dist-site
  echo "   将上传：install.sh  SHA256SUMS  index.html$([ $GUIDES = 1 ] && echo '  guide.md  使用说明.md')"
  echo "   目标桶：$BASE/"
  exit 0
fi

if [ -z "${OSS_AK:-}" ] || [ -z "${OSS_SK:-}" ]; then
  echo "！缺 OSS 凭据：设 OSS_AK / OSS_SK（或写进 $ENVF）"; exit 2
fi

echo "→ 上传"
node tools/oss-put.mjs --bucket "$OSS_BUCKET" --endpoint "$OSS_ENDPOINT" \
  --file dist-site/install.sh --key install.sh --disposition 'attachment; filename="install.sh"'
node tools/oss-put.mjs --bucket "$OSS_BUCKET" --endpoint "$OSS_ENDPOINT" \
  --file dist-site/index.html --key index.html --disposition '' \
  --cache-control 'no-store, no-cache, must-revalidate, max-age=0'
node tools/oss-put.mjs --bucket "$OSS_BUCKET" --endpoint "$OSS_ENDPOINT" \
  --file dist-site/SHA256SUMS --key SHA256SUMS --disposition '' \
  --ctype 'text/plain; charset=utf-8' --cache-control 'no-cache'
if [ "$GUIDES" = 1 ]; then
  node tools/oss-put.mjs --bucket "$OSS_BUCKET" --endpoint "$OSS_ENDPOINT" \
    --file dist-site/guide.md --key guide.md --disposition '' \
    --ctype 'text/plain; charset=utf-8' --cache-control 'no-cache'
  node tools/oss-put.mjs --bucket "$OSS_BUCKET" --endpoint "$OSS_ENDPOINT" \
    --file "dist-site/使用说明.md" --key "使用说明.md" --disposition '' \
    --ctype 'text/plain; charset=utf-8' --cache-control 'no-cache'
fi

echo "→ 回读校验"
python3 - "$BASE" "$SIZE" "$SHA" <<'PY'
import sys, hashlib, urllib.request
base, size, sha = sys.argv[1], int(sys.argv[2]), sys.argv[3]
d = urllib.request.urlopen(urllib.request.Request(base + "/install.sh", headers={"User-Agent": "curl/8"}), timeout=60).read()
ok = len(d) == size and hashlib.sha256(d).hexdigest() == sha
print(f"   install.sh {len(d)} 字节 · sha256 {'一致 ✅' if ok else '不一致 ❌'}")
if not ok: sys.exit(1)
PY

echo
echo "完成。固定链接（升级后不变）："
echo "  安装器：$BASE/install.sh"
echo "  说明页：$BASE/index.html"
echo "  指南　：$BASE/guide.md"
