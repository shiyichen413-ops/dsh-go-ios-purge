#!/usr/bin/env bash
# 一条命令发版：改版本号 → 写 CHANGELOG → 重建安装器 → 生成站点 → 上传 → 回读校验 → 同步 profile。
#
#   bash tools/release.sh 1.3.12 "面板：补丁分组支持折叠"      # 真发版
#   bash tools/release.sh 1.3.12 --dry-run                     # 改号 + 重建 + 生成站点，不联网
#   bash tools/release.sh 1.3.12 --preview                     # 只打印计划，什么都不写
#
# 凭据走 ~/.dsh/oss-put.env 或 OSS_AK / OSS_SK / OSS_BUCKET / OSS_ENDPOINT。
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd); cd "$ROOT"

NEW=""; NOTE=""; MODE=real
for a in "$@"; do
  case "$a" in
    --dry-run) MODE=dry ;;
    --preview) MODE=preview ;;
    -*) echo "未知参数：$a"; exit 2 ;;
    *) if [ -z "$NEW" ]; then NEW="$a"; else NOTE="$NOTE${NOTE:+ · }$a"; fi ;;
  esac
done
[ -n "$NEW" ] || { echo "用法：bash tools/release.sh <版本号> [变更摘要] [--dry-run|--preview]"; exit 2; }
echo "$NEW" | grep -Eq '^[0-9]+\.[0-9]+\.[0-9]+$' || { echo "版本号要形如 1.3.12"; exit 2; }

OLD=$(node -e "console.log(require('./package.json').version)")
if [ "$(printf '%s\n%s\n' "$OLD" "$NEW" | sort -V | tail -1)" = "$OLD" ] && [ "$NEW" != "$OLD" ]; then
  echo "！新版本 $NEW 必须大于当前 $OLD"; exit 2
fi
DATE=$(date +%Y-%m-%d)
NOTE=${NOTE:-"发版 $NEW"}
echo "版本 $OLD → $NEW · $DATE · $NOTE"

if [ "$MODE" = preview ]; then
  echo "[preview] 会做：改 package.json、在 CHANGELOG 顶部插入一条、重建 dist/install.sh、生成 dist-site/、上传 3 个对象、同步 profile。"
  echo "[preview] 未写入任何文件。"
  exit 0
fi

# 1) 版本号
python3 - "$NEW" <<'PY'
import json, sys
p = "package.json"; d = json.load(open(p)); d["version"] = sys.argv[1]
open(p, "w").write(json.dumps(d, ensure_ascii=False, indent=2) + "\n")
PY

# 2) CHANGELOG（同版本已存在就不重复插）
python3 - "$NEW" "$DATE" "$NOTE" <<'PY'
import sys, pathlib
ver, date, note = sys.argv[1:4]
p = pathlib.Path("CHANGELOG.md"); s = p.read_text(encoding="utf-8")
head = f"## {ver} · {date}"
if head in s:
    print(f"   CHANGELOG 已有 {ver}，跳过")
    sys.exit(0)
entry = f"{head}\n\n- {note}\n\n"
anchor = "## "
idx = s.find(anchor, s.find("\n\n"))
if idx < 0:
    s = s + "\n" + entry
else:
    s = s[:idx] + entry + s[idx:]
p.write_text(s, encoding="utf-8")
print(f"   CHANGELOG 插入 {ver}")
PY

# 3) 重建 + 生成站点 + 上传 + 回读校验
if [ "$MODE" = dry ]; then
  bash tools/publish-oss.sh --dry-run
else
  bash tools/publish-oss.sh --guides
fi

# 4) 同步到 profile（宿主读的是这份副本）
if [ "$MODE" = real ]; then
  bash tools/mount-profile.sh "$ROOT" >/dev/null 2>&1 && echo "→ 已同步 profile：$ROOT"
  node lib/engine.js selfcheck /opt/dsh 2>&1 | head -2
fi

SHA=$(sha256sum dist/install.sh | cut -d' ' -f1)
SIZE=$(wc -c < dist/install.sh | tr -d ' ')
echo
echo "✅ $NEW 完成 · $SIZE 字节 · sha256 $SHA"
echo "   安装器 https://${OSS_BUCKET:-dshgo}.${OSS_ENDPOINT:-oss-cn-hangzhou.aliyuncs.com}/install.sh"
