#!/usr/bin/env bash
# 回读核对 OSS 桶里的 4 个站点对象：字节数、sha256、Content-Type、Cache-Control。
#   bash tools/verify-oss.sh
# 期望（1.7.5 自包含页）：
#   index.html 13068 · guide.md 7135 · 使用说明.md 7135 · SHA256SUMS 77
set -uo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
BASE="https://dshgo.oss-cn-hangzhou.aliyuncs.com"
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
fail=0

check() { # key expected_size
  local key="$1" want="$2"
  local out="$TMP/$(echo "$key" | tr '/ ' '__')"
  local code size sha hdrs
  code=$(curl -s -o "$out" -w '%{http_code}' "$BASE/$key")
  size=$(wc -c < "$out" | tr -d ' ')
  sha=$(sha256sum "$out" | cut -c1-12)
  hdrs=$(curl -sI "$BASE/$key" | tr -d '\r')
  local ct=$(printf '%s\n' "$hdrs" | awk -F': ' 'tolower($1)=="content-type"{print $2}')
  local cc=$(printf '%s\n' "$hdrs" | awk -F': ' 'tolower($1)=="cache-control"{print $2}')
  local lm=$(printf '%s\n' "$hdrs" | awk -F': ' 'tolower($1)=="last-modified"{print $2}')
  local mark="❌"
  [ "$code" = 200 ] && [ "$size" = "$want" ] && mark="✅"
  [ "$mark" = "❌" ] && fail=1
  printf '%s %-14s %7s/%s 字节  sha256:%s…\n   type=%s  cache=%s\n   改于 %s\n' \
    "$mark" "$key" "$size" "$want" "$sha" "${ct:-?}" "${cc:-无}" "${lm:-?}"
}

echo "线上 vs 期望（1.7.5 自包含页）"
check index.html 13068
check guide.md 7135
check 使用说明.md 7135
check SHA256SUMS 77
echo
echo "install.sh："
check install.sh 2271027

if [ "$fail" = 0 ]; then
  echo
  echo "全部一致 ✅ 线上已是自包含新页面"
else
  echo
  echo "有对象未覆盖 ❌ 需要重新上传（见 /sdcard/Download/DSH-Go/oss-1.7.4-fix/）"
fi
exit "$fail"
