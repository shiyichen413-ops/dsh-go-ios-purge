#!/usr/bin/env node
// 用 OSS REST API 直接上传对象（不依赖浏览器/控制台）。
//
//   OSS_AK=xxx OSS_SK=yyy node tools/oss-put.mjs \
//     --endpoint oss-cn-hangzhou.aliyuncs.com --bucket dshgo \
//     --file dist/install.sh --key install.sh
//
// 只做 PUT + 回读校验；上传后自动 HEAD 一次比对 Content-Length。
// 权限最小化：这个脚本只需要 oss:PutObject（和读取自己刚传的对象）。

import { readFileSync } from "node:fs";
import { createHash, createHmac } from "node:crypto";
import { basename } from "node:path";

const args = process.argv.slice(2);
const opt = (n, d) => {
  const i = args.indexOf(`--${n}`);
  return i >= 0 && args[i + 1] && !args[i + 1].startsWith("--") ? args[i + 1] : d;
};
const AK = opt("ak", process.env.OSS_AK || "");
const SK = opt("sk", process.env.OSS_SK || "");
const ENDPOINT = opt("endpoint", process.env.OSS_ENDPOINT || "oss-cn-hangzhou.aliyuncs.com");
const BUCKET = opt("bucket", process.env.OSS_BUCKET || "dshgo");
const FILE = opt("file", "dist/install.sh");
const KEY = opt("key", basename(FILE));
const CTYPE = opt("ctype", KEY.endsWith(".sh") ? "application/x-sh" : KEY.endsWith(".html") ? "text/html; charset=utf-8" : KEY.endsWith(".md") ? "text/markdown; charset=utf-8" : "application/octet-stream");
const DISP = opt("disposition", KEY.endsWith(".sh") ? 'attachment; filename="install.sh"' : "");
const CACHE = opt("cache-control", "");

if (!AK || !SK) {
  console.error("缺凭据：OSS_AK / OSS_SK（环境变量或 --ak/--sk）");
  process.exit(2);
}

const body = readFileSync(FILE);
const md5 = createHash("md5").update(body).digest("base64");
const date = new Date().toUTCString();
const resource = `/${BUCKET}/${KEY}`;
const headers = {
  "Content-Type": CTYPE,
  "Content-MD5": md5,
  Date: date,
};
if (DISP) headers["Content-Disposition"] = DISP;
if (CACHE) headers["Cache-Control"] = CACHE;

// OSS V1 签名：VERB\nContent-MD5\nContent-Type\nDate\nCanonicalizedOSSHeaders+CanonicalizedResource
const ossHeaders = Object.entries(headers)
  .filter(([k]) => k.toLowerCase().startsWith("x-oss-"))
  .map(([k, v]) => `${k.toLowerCase()}:${v}`)
  .sort()
  .join("\n");
const stringToSign = ["PUT", md5, CTYPE, date, ossHeaders ? ossHeaders + "\n" : "", resource].join("\n");
const signature = createHmac("sha1", SK).update(stringToSign).digest("base64");
headers.Authorization = `OSS ${AK}:${signature}`;

const url = `https://${BUCKET}.${ENDPOINT}/${encodeURIComponent(KEY)}`;
const put = await fetch(url, { method: "PUT", headers, body });
if (!put.ok) {
  console.error(`PUT 失败 HTTP ${put.status}: ${(await put.text()).slice(0, 300)}`);
  process.exit(1);
}
console.log(`PUT ok  ${KEY}  ${body.length} 字节  ${CTYPE}${CACHE ? "  cache=" + CACHE : ""}`);

const head = await fetch(url, { method: "HEAD" });
const len = Number(head.headers.get("content-length") || 0);
console.log(`HEAD ${head.status}  ${len} 字节  ${head.headers.get("content-type")}  ${head.headers.get("content-disposition") || ""}`);
if (len !== body.length) {
  console.error("⚠ 回读长度不一致");
  process.exit(1);
}
console.log(`直链：https://${BUCKET}.${ENDPOINT}/${KEY}`);
