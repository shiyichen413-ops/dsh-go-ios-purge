#!/usr/bin/env node
// 把 dsh-go-unrestricted 发到 GitHub —— 不依赖 git 二进制，只走 REST API。
//
// 为什么要这么一个脚本：这台机器（以及手机端 proot 环境）都没有 git，而
// GitHub 的 contents / releases / uploads 三个接口用 fetch 就够，逐文件 base64
// 上传 40 多个文件也就几十秒。
//
// 用法：
//   GITHUB_TOKEN=ghp_xxx node tools/publish-github.mjs
//   GITHUB_TOKEN=... node tools/publish-github.mjs --repo dsh-go-unrestricted --private
//   GITHUB_TOKEN=... node tools/publish-github.mjs --dry-run      # 只列要传什么
//
// 参数：
//   --token <t>       GitHub PAT（classic: repo 权限；fine-grained: Contents=Read/Write + Administration=Read/Write）
//   --owner <name>    默认从 GET /user 取
//   --repo <name>     默认 dsh-go-unrestricted
//   --tag <v>         默认读 package.json 的 version，前缀 v
//   --message <msg>   提交信息，默认 "dsh-go-unrestricted <version>"
//   --private         建成私有仓库（默认公开）
//   --description <s> 仓库描述
//   --configure       顺带把仓库「配置」也设上：描述 + topics + 关闭 wiki/projects
//   --dry-run         只打印将上传的文件清单
//
// 幂等：仓库已存在就复用；文件已存在就带 sha 覆盖；release 已存在就复用 tag。
// 任何一步失败都会打印 GitHub 返回的 message 原文并以 1 退出。

import { readFileSync, readdirSync, statSync } from 'node:fs'
import { join, relative, sep } from 'node:path'

const ROOT = process.cwd()
const API = 'https://api.github.com'

const args = process.argv.slice(2)
const flag = (name) => args.includes(`--${name}`)
const opt = (name, fallback = '') => {
  const i = args.indexOf(`--${name}`)
  return i >= 0 && args[i + 1] && !args[i + 1].startsWith('--') ? args[i + 1] : fallback
}

const TOKEN = opt('token') || process.env.GITHUB_TOKEN || process.env.GH_TOKEN || ''
const REPO = opt('repo', 'dsh-go-unrestricted')
const TAG_OPT = opt('tag')
const DRY = flag('dry-run')
const PRIVATE = flag('private')
const CONFIGURE = flag('configure')

const pkg = JSON.parse(readFileSync(join(ROOT, 'package.json'), 'utf8'))
const TAG = TAG_OPT || `v${pkg.version}`
const MESSAGE = opt('message', `dsh-go-unrestricted ${pkg.version}`)
const DESCRIPTION = opt('description', 'DSH 破甲插件：执行层补丁 + 25 层自检 + 三个可选模式 + 四个面板（dsh-purge 等价实现）')

// 发布白名单：目录递归收，文件逐个列。教程素材（zip / docx / pdf）与本地临时产物一律不发。
const INCLUDE_DIRS = ['lib', 'presets', 'test', 'tools']
const INCLUDE_FILES = ['package.json', 'cordis.patch.yml', 'README.md', 'INSTALL-TERMINAL.md', 'CHANGELOG.md', 'RELEASE.md', 'LICENSE', '.gitignore', 'install-presets.sh', 'dist/install.sh']
const SKIP = [/(^|\/)node_modules\//, /(^|\/)_reports\//, /\.log$/, /\.dshpurge\.bak$/, /(^|\/)\.git\//]

function walk(dir, out = []) {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const full = join(dir, entry.name)
    const rel = relative(ROOT, full).split(sep).join('/')
    if (SKIP.some((re) => re.test(rel + '/'))) continue
    if (entry.isDirectory()) walk(full, out)
    else if (entry.isFile()) out.push(rel)
  }
  return out
}

function collect() {
  const files = []
  for (const dir of INCLUDE_DIRS) {
    try { if (statSync(join(ROOT, dir)).isDirectory()) walk(join(ROOT, dir), files) } catch {}
  }
  for (const file of INCLUDE_FILES) {
    try { if (statSync(join(ROOT, file)).isFile()) files.push(file) } catch {}
  }
  return [...new Set(files)].sort()
}

async function call(method, path, body, { raw = false, base = API } = {}) {
  const res = await fetch(`${base}${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${TOKEN}`,
      Accept: 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      'User-Agent': 'dsh-go-unrestricted-publisher',
      ...(raw ? { 'Content-Type': 'application/octet-stream' } : body ? { 'Content-Type': 'application/json' } : {}),
    },
    body: raw ? body : body ? JSON.stringify(body) : undefined,
  })
  const text = await res.text()
  let json
  try { json = text ? JSON.parse(text) : {} } catch { json = { message: text.slice(0, 400) } }
  if (!res.ok) {
    const err = new Error(`${method} ${path} → ${res.status} ${json.message ?? text.slice(0, 300)}`)
    err.status = res.status
    err.body = json
    throw err
  }
  return json
}

async function main() {
  const files = collect()
  const total = files.reduce((n, f) => n + statSync(join(ROOT, f)).size, 0)
  console.log(`将发布 ${files.length} 个文件 / ${(total / 1024).toFixed(1)} KB → ${REPO} @ ${TAG}`)
  if (DRY) {
    for (const f of files) console.log(`  ${f}  ${statSync(join(ROOT, f)).size}`)
    return
  }

  if (!TOKEN) {
    console.error('缺 token：设 GITHUB_TOKEN 环境变量，或传 --token。')
    console.error('  classic PAT 要 repo 权限；fine-grained 要 Contents=Read and write + Administration=Read and write。')
    process.exit(2)
  }

  const me = await call('GET', '/user')
  const OWNER = opt('owner', me.login)
  console.log(`账号：${OWNER}`)

  // 1. 仓库
  let repo = null
  try {
    repo = await call('GET', `/repos/${OWNER}/${REPO}`)
    console.log(`仓库已存在：${repo.html_url}`)
  } catch (err) {
    if (err.status !== 404) throw err
    repo = await call('POST', '/user/repos', {
      name: REPO,
      description: DESCRIPTION,
      private: PRIVATE,
      has_issues: true,
      has_wiki: false,
      auto_init: false,
    })
    console.log(`已创建仓库：${repo.html_url}`)
  }

  // 2. 分支基线：空仓库直接往 main 写，非空仓库沿用默认分支
  const branch = repo.default_branch || 'main'

  // 2b. 仓库「配置」：只在显式 --configure 时动，免得覆盖用户手填的描述
  if (CONFIGURE) {
    const topics = [
      'dsh', 'deepseek-harness', 'dsh-plugin', 'unrestricted',
      'redteam', 'agent-preset', 'patching', 'self-check',
      'android', 'proot',
    ]
    try {
      await call('PATCH', `/repos/${OWNER}/${REPO}`, {
        description: DESCRIPTION,
        has_issues: true,
        has_wiki: false,
        has_projects: false,
        homepage: '',
      })
      await call('PUT', `/repos/${OWNER}/${REPO}/topics`, { names: topics })
      console.log(`仓库配置已更新：描述 + ${topics.length} 个 topic。`)
    } catch (err) {
      // topics 是较新的接口，权限不足时不该拖垮上传
      console.warn(`仓库配置跳过：${err.message}`)
    }
  }

  // 3. 逐文件上传（已存在就带 sha 覆盖）
  let written = 0
  for (const file of files) {
    const content = readFileSync(join(ROOT, file)).toString('base64')
    let sha
    try {
      const existing = await call('GET', `/repos/${OWNER}/${REPO}/contents/${encodeURI(file)}?ref=${branch}`)
      sha = existing.sha
      if (existing.size === statSync(join(ROOT, file)).size) {
        // 同尺寸也可能内容不同，但省一次写入：只有内容真的一样才跳过
        const same = existing.content && existing.content.replace(/\n/g, '') === content
        if (same) { written += 0; continue }
      }
    } catch (err) {
      if (err.status !== 404) throw err
    }
    await call('PUT', `/repos/${OWNER}/${REPO}/contents/${encodeURI(file)}`, {
      message: `${MESSAGE} · ${file}`,
      content,
      branch,
      ...(sha ? { sha } : {}),
    })
    written += 1
    process.stdout.write(`  ✓ ${file}\n`)
  }
  console.log(`上传完成：写入 ${written} 个，其余已是最新。`)

  // 4. Release + install.sh 附件（手机端只要这一个文件，走 release 比 raw 稳）
  let release = null
  try {
    release = await call('GET', `/repos/${OWNER}/${REPO}/releases/tags/${TAG}`)
    console.log(`Release ${TAG} 已存在，复用。`)
  } catch (err) {
    if (err.status !== 404) throw err
    release = await call('POST', `/repos/${OWNER}/${REPO}/releases`, {
      tag_name: TAG,
      target_commitish: branch,
      name: `dsh-go-unrestricted ${pkg.version}`,
      body: [
        `破甲插件 ${pkg.version}。`,
        '',
        '手机端只需要下载下面的 `install.sh`，它是自包含的（46 个文件在脚本里）：',
        '',
        '```bash',
        'cp /sdcard/Download/install.sh /root/ && cd /root && bash install.sh',
        'bash /root/.dsh/dsh-go/plugins/dsh-go-unrestricted/install-presets.sh --force   # 需要重置预设模板时',
        '```',
        '',
        '细节看仓库里的 `CHANGELOG.md` 与 `README.md`。',
      ].join('\n'),
    })
    console.log(`已创建 Release ${TAG}：${release.html_url}`)
  }

  const assetPath = join(ROOT, 'dist', 'install.sh')
  try {
    const assets = await call('GET', `/repos/${OWNER}/${REPO}/releases/${release.id}/assets`)
    if (assets.some((a) => a.name === 'install.sh')) {
      console.log('install.sh 附件已存在，跳过。')
    } else {
      const res = await fetch(`https://uploads.github.com/repos/${OWNER}/${REPO}/releases/${release.id}/assets?name=install.sh`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${TOKEN}`,
          'Content-Type': 'application/octet-stream',
          'User-Agent': 'dsh-go-unrestricted-publisher',
        },
        body: readFileSync(assetPath),
      })
      if (!res.ok) throw new Error(`上传 install.sh 失败：${res.status} ${await res.text()}`)
      console.log('install.sh 已作为 Release 附件上传。')
    }
  } catch (err) {
    console.warn(`附件步骤失败（仓库里的 dist/install.sh 仍然可用）：${err.message}`)
  }

  console.log('')
  console.log(`完成：${repo.html_url}`)
  console.log(`Release：${repo.html_url.replace(/\/$/, '')}/releases/tag/${TAG}`)
}

main().catch((err) => {
  console.error('发布失败：', err.message)
  if (err.body?.errors) console.error(JSON.stringify(err.body.errors, null, 2))
  process.exit(1)
})
