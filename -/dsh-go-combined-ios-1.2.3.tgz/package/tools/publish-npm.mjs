#!/usr/bin/env node
// 发布到 npm registry（纯 HTTP，不依赖 npm CLI / git）。
//
// 用法：
//   NPM_TOKEN=npm_xxx node tools/publish-npm.mjs                  # 发布当前 package.json 的版本
//   node tools/publish-npm.mjs --token npm_xxx --dry-run          # 只打包并打印清单
//   node tools/publish-npm.mjs --registry https://registry.npmjs.org --tag latest
//
// 为什么需要它：「插件市场」的 versions[].source 只支持 npm 与 git 两种，
// 而 git 源要求手机端有 git 且能 clone 得动 GitHub。npm 源配合 npmmirror 是国内最快的路径
// （实测 registry.npmmirror.com 单文件接口 0.23s）。发布到 npm 之后：
//   · npmmirror 自动镜像 → 国内直链 https://registry.npmmirror.com/<name>/<ver>/files/dist/install.sh
//   · 市场索引里 source: { type: "npm" } 就能真正「获取」
//
// token 权限：classic token 需要 Read and write；2FA 账号需用 Automation token。
// 本脚本只做一次 PUT，失败会打印 registry 返回的原文。

import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..');

function arg(name, fallback = '') {
  const i = process.argv.indexOf(`--${name}`);
  if (i < 0) return fallback;
  const next = process.argv[i + 1];
  return next && !next.startsWith('--') ? next : 'true';
}

const flag = (name) => process.argv.includes(`--${name}`);

const INCLUDE_DIRS = ['lib', 'presets', 'test', 'tools'];
const INCLUDE_FILES = [
  'package.json',
  'cordis.patch.yml',
  'README.md',
  'INSTALL-TERMINAL.md',
  'CHANGELOG.md',
  'RELEASE.md',
  'LICENSE',
  'install-presets.sh',
  // 必须带上：npmmirror 的单文件接口 `/{pkg}/{ver}/files/dist/install.sh`
  // 就是靠包里这个路径提供国内直链的，缺了它那条快链 404。
  'dist/install.sh',
];
const SKIP = /(?:node_modules|[\\/]_reports[\\/]|\.log$|\.dshpurge\.bak$|[\\/]\.git[\\/]|\.zip$|\.docx$|\.pdf$)/;

function walk(dir, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
    const abs = path.join(dir, entry.name);
    if (SKIP.test(abs)) continue;
    if (entry.isDirectory()) walk(abs, out);
    else if (entry.isFile()) out.push(abs);
  }
  return out;
}

function collect() {
  const files = [];
  for (const name of INCLUDE_FILES) {
    const abs = path.join(ROOT, name);
    if (fs.existsSync(abs)) files.push(abs);
  }
  for (const dir of INCLUDE_DIRS) {
    const abs = path.join(ROOT, dir);
    if (fs.existsSync(abs)) files.push(...walk(abs));
  }
  return [...new Set(files)];
}

// ── 最小 ustar 打包器（npm 只接受 tar.gz，内层路径必须带 package/ 前缀）──

function octal(value, width) {
  const text = value.toString(8);
  return `${'0'.repeat(Math.max(0, width - 1 - text.length))}${text}\0`;
}

function tarHeader({ name, size, mode, mtime }) {
  const header = Buffer.alloc(512, 0);
  let file = name;
  let prefix = '';
  if (Buffer.byteLength(file) > 100) {
    const cut = file.lastIndexOf('/', file.length - 1);
    prefix = file.slice(0, cut);
    file = file.slice(cut + 1);
    if (Buffer.byteLength(prefix) > 155 || Buffer.byteLength(file) > 100) {
      throw new Error(`路径过长，无法写进 ustar 头：${name}`);
    }
  }
  header.write(file, 0, 100, 'utf8');
  header.write(octal(mode, 8), 100, 8, 'ascii');
  header.write(octal(0, 8), 108, 8, 'ascii'); // uid
  header.write(octal(0, 8), 116, 8, 'ascii'); // gid
  header.write(octal(size, 12), 124, 12, 'ascii');
  header.write(octal(mtime, 12), 136, 12, 'ascii');
  header.write('        ', 148, 8, 'ascii'); // checksum 占位
  header.write('0', 156, 1, 'ascii'); // typeflag
  header.write('ustar\0', 257, 6, 'ascii');
  header.write('00', 263, 2, 'ascii');
  header.write(prefix, 345, 155, 'utf8');

  let sum = 0;
  for (const byte of header) sum += byte;
  header.write(`${sum.toString(8).padStart(6, '0')}\0 `, 148, 8, 'ascii');
  return header;
}

function packTarball(files, mtime) {
  const blocks = [];
  for (const abs of files) {
    const rel = path.relative(ROOT, abs).replace(/\\/g, '/');
    const body = fs.readFileSync(abs);
    const exec = /\.(?:sh|mjs|js|cjs)$/.test(rel) ? 0o755 : 0o644;
    blocks.push(tarHeader({ name: `package/${rel}`, size: body.length, mode: exec, mtime }));
    blocks.push(body);
    const pad = (512 - (body.length % 512)) % 512;
    if (pad) blocks.push(Buffer.alloc(pad, 0));
  }
  blocks.push(Buffer.alloc(1024, 0));
  return zlib.gzipSync(Buffer.concat(blocks), { level: 9 });
}

// ── manifest ──

function buildManifest(pkg, tarballName, tarball, registry) {
  const manifest = { ...pkg };
  delete manifest.private;
  delete manifest.devDependencies;
  delete manifest.scripts;
  delete manifest.files;
  const shasum = crypto.createHash('sha1').update(tarball).digest('hex');
  const integrity = `sha512-${crypto.createHash('sha512').update(tarball).digest('base64')}`;
  manifest.dist = {
    shasum,
    integrity,
    tarball: `${registry.replace(/\/+$/, '')}/${pkg.name}/-/${tarballName}`,
  };
  return manifest;
}

const WIN = /^[A-Za-z]:/.test(ROOT);

async function main() {
  const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  const registry = arg('registry', 'https://registry.npmjs.org');
  const token = arg('token') || process.env.NPM_TOKEN || process.env.NODE_AUTH_TOKEN || '';
  const version = arg('version', pkg.version);
  const tag = arg('tag', 'latest');
  const files = collect();

  const tarballName = `${pkg.name}-${version}.tgz`;
  const displayPkg = { ...pkg, version };
  const tarball = packTarball(files, Math.floor(Date.now() / 1000));

  let total = 0;
  for (const abs of files) total += fs.statSync(abs).size;
  console.log(`打包 ${files.length} 个文件 / ${(total / 1024).toFixed(1)} KB → ${tarballName}（${tarball.length} 字节）`);

  if (flag('dry-run')) {
    for (const abs of files) console.log(`  ${path.relative(ROOT, abs).replace(/\\/g, '/')}`);
    console.log(`目标 registry：${registry} · 版本 ${version} · tag ${tag}`);
    return;
  }
  if (!token) throw new Error('缺少 token：用 --token npm_xxx 或环境变量 NPM_TOKEN');
  if (WIN) console.log('提示：Windows 上 ustar 头无法保留 unix 权限位，npm 只读取文件内容，不影响安装。');

  const manifest = buildManifest(displayPkg, tarballName, tarball, registry);
  const body = {
    _id: pkg.name,
    name: pkg.name,
    description: pkg.description ?? '',
    'dist-tags': { [tag]: version },
    versions: { [version]: manifest },
    access: pkg.name.startsWith('@') ? 'restricted' : null,
    _attachments: {
      [tarballName]: {
        content_type: 'application/octet-stream',
        data: tarball.toString('base64'),
        length: tarball.length,
      },
    },
  };

  const res = await fetch(`${registry.replace(/\/+$/, '')}/${encodeURIComponent(pkg.name).replace('%40', '@')}`, {
    method: 'PUT',
    headers: {
      authorization: `Bearer ${token}`,
      'content-type': 'application/json',
      accept: 'application/json',
      'user-agent': 'dsh-go-unrestricted publish-npm',
    },
    body: JSON.stringify(body),
  });

  const text = await res.text();
  if (!res.ok) {
    throw new Error(`发布失败 HTTP ${res.status}：${text.slice(0, 1200)}`);
  }
  console.log(`发布成功：${pkg.name}@${version}`);
  console.log(`  https://www.npmjs.com/package/${pkg.name}`);
  console.log(`  国内镜像（约 1 分钟后可用）：https://registry.npmmirror.com/${pkg.name}/${version}/files/dist/install.sh`);
}

main().catch((error) => {
  console.error(`失败：${error.message}`);
  process.exitCode = 1;
});
