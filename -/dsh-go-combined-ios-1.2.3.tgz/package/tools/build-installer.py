#!/usr/bin/env python3
"""确定性重建 dist/install.sh：header + 全部文件块 + trailer。

替代旧 make-installer.py 的「就地替换」：那种做法在块被别处引用/重复时会整块丢掉。
这里每次都从树里重新生成块区，块顺序固定、内容就是当前文件，天然幂等。

用法：python3 tools/build-installer.py [--check]
"""
import os, re, sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(BASE, 'dist', 'install.sh')
HEAD_MARK = 'cat > "$DIR/'
TAIL_MARK = '# ── 挂进 profile ─'

ROOT_FILES = ['package.json', 'cordis.patch.yml', 'install-presets.sh', 'README.md',
              'CHANGELOG.md', 'INSTALL-TERMINAL.md', 'LICENSE', 'RELEASE.md', 'MIRRORS.md']
ROOT_DIRS = ['lib', 'presets', 'skills', 'skills-public', 'tools', 'panel-plugin']

def collect():
    rels = []
    for f in ROOT_FILES:
        if os.path.isfile(os.path.join(BASE, f)):
            rels.append(f)
    for d in ROOT_DIRS:
        root = os.path.join(BASE, d)
        for dp, _dn, fns in os.walk(root):
            for fn in sorted(fns):
                if fn.endswith('.bak'):
                    continue
                rels.append(os.path.relpath(os.path.join(dp, fn), BASE).replace(os.sep, '/'))
    return rels

def tag_of(rel):
    return '__DSHGO__' + re.sub(r'[^A-Za-z0-9]+', '_', rel).upper() + '__'

# ── 目录 ────────────────────────────────────────────────────────────────────
# 装到全新目录时子目录必须先存在：1.7.5 及之前 header 只写 `mkdir -p "$DIR/lib"`，
# 于是第 119 个块 `cat > "$DIR/lib/panel/actions.mjs"` 在干净机器上直接
#   line 15343: .../lib/panel/actions.mjs: No such file or directory
# set -e 立刻退出 → 面板与三模式预设全部缺失。这里按内嵌文件清单自动生成 mkdir。
MK_BEGIN = '# ── 目录（build-installer.py 自动生成，勿手改） ─'
MK_END = '# ── 目录结束 ─'


def dirs_of(rels):
    return sorted({os.path.dirname(r) for r in rels if os.path.dirname(r)})


def render_mkdir(rels):
    dirs = dirs_of(rels)
    items = ['"$DIR"'] + [f'"$DIR/{d}"' for d in dirs]
    return MK_BEGIN + '\nmkdir -p ' + ' \\\n  '.join(items) + '\n' + MK_END


def strip_mkdir(block):
    out, skip = [], False
    for line in block.split('\n'):
        if line.startswith(MK_BEGIN):
            skip = True
            continue
        if skip:
            if line.startswith(MK_END):
                skip = False
            continue
        if line.strip() == 'mkdir -p "$DIR/lib"':
            continue
        out.append(line)
    return '\n'.join(out)

text = open(SRC, encoding='utf-8').read()
head_at = text.index(HEAD_MARK)
# 尾段从「最后一行以标记开头」处切：工具脚本正文里也会出现这个字符串。
tail_at = max(i for i, line in enumerate(text.split('\n')) if False) if False else None
lines_all = text.split('\n')
cand = [i for i, line in enumerate(lines_all) if line.startswith(TAIL_MARK)]
tail_at = len('\n'.join(lines_all[:cand[-1]])) + (1 if cand[-1] else 0)
head = text[:head_at]
tail = text[tail_at:]

rels = collect()
head = strip_mkdir(head)
ANCHOR = 'echo "→ 写入 $DIR"'
if ANCHOR not in head:
    sys.exit('!! header 里找不到锚点 echo "→ 写入 $DIR"')
head = head.replace(ANCHOR, render_mkdir(rels) + '\n' + ANCHOR, 1)

parts = [head.rstrip('\n')]
n = 0
for rel in rels:
    path = os.path.join(BASE, rel)
    body = open(path, encoding='utf-8').read()
    if body.endswith('\n'):
        body = body[:-1]
    tag = tag_of(rel)
    if tag in body:
        sys.exit(f'!! {rel} 正文里出现标记 {tag}')
    parts.append(f'cat > "$DIR/{rel}" <<\'{tag}\'\n{body}\n{tag}')
    n += 1
parts.append('chmod +x "$DIR/tools/"*.sh "$DIR/tools/export-report.mjs" 2>/dev/null || true\n')
parts.append(tail)
out = '\n\n'.join(p if p.endswith('\n') else p for p in [parts[0]])  # placeholder
out = parts[0] + '\n\n' + '\n'.join(parts[1:-2]) + '\n\n' + parts[-2] + '\n' + parts[-1]

if '--check' in sys.argv:
    same = out == text
    print(('一致' if same else '不一致') + f' · {n} 个块 · {len(out.encode())} 字节')
    sys.exit(0 if same else 1)

open(SRC, 'w', encoding='utf-8').write(out)
print(f'重建完成：{n} 个块 · {len(out.encode())} 字节')
