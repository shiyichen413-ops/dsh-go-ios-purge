#!/usr/bin/env node
// 生成 dsh 插件市场索引（format 1）。
//
// 用法：
//   node tools/make-market-index.mjs                      # 写 dist/market/index.json 并自校验
//   node tools/make-market-index.mjs --registry https://registry.npmmirror.com
//   node tools/make-market-index.mjs --git https://gitee.com/<owner>/dsh-go-unrestricted --commit <40hex>
//   node tools/make-market-index.mjs --validate <url 或文件>   # 只校验
//
// 说明：format 1 的 versions[].source 只支持 npm 与 git 两种。
//   npm  → 装的是 `<name>@<version>`，需要包已发布到 npm（可指定 registry 作首选源）。
//   git  → 装的是 `git+<url>#<commit>`，需要 40 位小写 commit，且手机端有 git。
// 索引本身可以托管在任何 https 地址（GitHub Pages / jsDelivr / Gitee raw），
// 用户在「插件市场 → 添加索引源」里填那个 URL 就能看到本插件。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..');

function arg(name, fallback = '') {
  const i = process.argv.indexOf(`--${name}`);
  if (i < 0) return fallback;
  const next = process.argv[i + 1];
  return next && !next.startsWith('--') ? next : 'true';
}

const ICON_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#111827"/><path d="M17 21h30v6H17z" fill="#f9fafb"/><path d="M17 31h21v6H17z" fill="#9ca3af"/><path d="M17 41h30v6H17z" fill="#f9fafb"/><path d="M11 51 53 13" stroke="#ef4444" stroke-width="7" stroke-linecap="round"/></svg>`;
const ICON = `data:image/svg+xml;base64,${Buffer.from(ICON_SVG, 'utf8').toString('base64')}`;

const CATEGORIES = {
  agent: { title: { 'zh-cn': 'Agent 增强', en: 'Agent' } },
  context: { title: { 'zh-cn': '记忆上下文', en: 'Context' } },
  channel: { title: { 'zh-cn': '通道通知', en: 'Channel' } },
  ui: { title: { 'zh-cn': '界面外观', en: 'Interface' } },
  tool: { title: { 'zh-cn': '工具扩展', en: 'Tools' } },
  hosting: { title: { 'zh-cn': '宿主运维', en: 'Hosting' } },
};

const LABELS = {
  unrestricted: { title: { 'zh-cn': '无限制', en: 'Unrestricted' } },
  redteam: { title: { 'zh-cn': '红队', en: 'Red team' } },
  android: { title: { 'zh-cn': 'Android', en: 'Android' } },
  proot: { title: { 'zh-cn': 'proot 容器', en: 'proot' } },
  'self-check': { title: { 'zh-cn': '自检', en: 'Self-check' } },
  patching: { title: { 'zh-cn': '宿主补丁', en: 'Host patch' } },
  'no-root': { title: { 'zh-cn': '免 root', en: 'No root' } },
};

const SORT_KEYS = {
  added: { title: { 'zh-cn': '加入时间', en: 'Added' }, order: 'desc' },
};

function buildIndex({ registry, gitUrl, commit, version, publishTimestamp }) {
  const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  const ver = version || pkg.version;

  let source;
  if (gitUrl) {
    if (!/^[0-9a-f]{40}$/.test(commit)) {
      throw new Error('--git 需要 --commit 给出 40 位小写 commit');
    }
    source = { type: 'git', url: gitUrl, commit };
  } else {
    source = { type: 'npm', ...(registry ? { registry } : {}) };
  }

  const engines = pkg.dsh?.engines ?? pkg.dsh?.compat ?? null;
  const dshRange = typeof engines?.dsh === 'string' ? engines.dsh : (typeof pkg.dsh?.dsh === 'string' ? pkg.dsh.dsh : undefined);

  return {
    format: 1,
    title: {
      'zh-cn': 'DSH Go 破甲生态',
      en: 'DSH Go Unrestricted',
    },
    description: {
      'zh-cn': 'dsh-purge 在 Android / proot 上的等价实现：宿主补丁、25 层自检、三个可选模式与原生配置面板。',
      en: 'The dsh-purge equivalent for Android/proot: host patches, a 25-layer self-check, three presets and a native settings panel.',
    },
    metadata: { categories: CATEGORIES, labels: LABELS, sortKeys: SORT_KEYS },
    plugins: [
      {
        name: pkg.name,
        title: { 'zh-cn': 'DSH Go 破甲（无限制）', en: 'DSH Go Unrestricted' },
        description: {
          'zh-cn': '把 dsh-purge 1.7.14 的 88 条宿主补丁、25 层破甲自检、红队/无限制/无限制·子任务三个模式与配置面板搬进手机端 dsh-go。',
          en: 'Ports dsh-purge 1.7.14 (88 host patches, 25-layer self-check, red-team / unrestricted / unrestricted-child presets, settings panels) to dsh-go on Android.',
        },
        icon: ICON,
        author: 'lingsmall-code',
        homepage: 'https://github.com/lingsmall-code/dsh-go-unrestricted',
        repository: { url: 'https://github.com/lingsmall-code/dsh-go-unrestricted' },
        metadata: {
          category: 'agent',
          keywords: ['dsh', 'dsh-go', 'dsh-purge', 'unrestricted', 'redteam', 'android', 'proot', 'patch', 'self-check'],
          labels: ['unrestricted', 'redteam', 'android', 'proot', 'self-check', 'patching', 'no-root'],
          sortKeys: { added: 1 },
        },
        versions: [
          {
            version: ver,
            publishTimestamp: publishTimestamp || Math.floor(Date.now() / 1000),
            source,
            ...(dshRange ? { engines: { dsh: dshRange } } : {}),
          },
        ],
      },
    ],
  };
}

async function validateIndexUrl(target) {
  const file = path.join(ROOT, 'node_modules', '@deepseek-ai', 'dsh-plugin-market-index', 'lib', 'index.js');
  let parseMarketIndex;
  if (fs.existsSync(file)) {
    ({ parseMarketIndex } = await import(`file://${file.replace(/\\/g, '/')}`));
  } else {
    const host = 'D:/applications/Deepseek Harness/resources/app/dsh/node_modules/@deepseek-ai/dsh-plugin-market-index/lib/index.js';
    ({ parseMarketIndex } = await import(`file://${host}`));
  }
  let doc;
  let indexUrl = target;
  if (/^https?:/i.test(target)) {
    const res = await fetch(target, { headers: { accept: 'application/json' } });
    if (!res.ok) throw new Error(`下载索引失败：HTTP ${res.status}`);
    doc = await res.json();
  } else {
    if (!indexUrl) indexUrl = 'https://example.com/index.json';
    doc = JSON.parse(fs.readFileSync(target, 'utf8'));
  }
  return parseMarketIndex(doc, indexUrl);
}

async function main() {
  const only = arg('validate');
  if (only) {
    const parsed = await validateIndexUrl(only === 'true' ? '' : only);
    console.log(`索引校验通过：${parsed.plugins.length} 个插件 · ${parsed.title.en}`);
    return;
  }

  const registry = arg('registry');
  const gitUrl = arg('git');
  const commit = arg('commit');
  const version = arg('version');
  const publishTimestamp = Number(arg('timestamp', '0')) || undefined;

  const index = buildIndex({ registry, gitUrl, commit, version, publishTimestamp });
  const outDir = path.join(ROOT, 'dist', 'market');
  fs.mkdirSync(outDir, { recursive: true });
  const outFile = path.join(outDir, 'index.json');
  fs.writeFileSync(outFile, `${JSON.stringify(index, null, 2)}\n`, 'utf8');

  const parsed = await validateIndexUrl(outFile);
  const p = parsed.plugins[0];
  console.log(`已写 ${path.relative(ROOT, outFile)}（${fs.statSync(outFile).size} 字节）`);
  console.log(`校验通过：${p.name}@${p.versions[0].version} · source=${p.versions[0].source.type} · 分类 ${Object.keys(parsed.metadata.categories).length} 个`);
  console.log('');
  console.log('托管后把索引 URL 填进「插件市场 → 添加索引源」即可：');
  console.log(`  https://fastly.jsdelivr.net/gh/lingsmall-code/dsh-go-unrestricted@main/dist/market/index.json`);
}

main().catch((error) => {
  console.error(`失败：${error.message}`);
  process.exitCode = 1;
});
