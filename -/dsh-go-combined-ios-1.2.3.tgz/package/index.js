// dsh-go-combined-ios —— 一个包里两套东西：
//   lib/core/   dsh-go-purge 0.4.18：提示词注入层 + purge_* 工具 + 86 条补丁表
//   lib/        dsh-go-unrestricted 1.7.61：三套 agent 预设、面板、自检、引擎补丁引擎
// 默认只有 core 的补丁表会被 apply；unrestricted 的补丁走它自己的面板/CLI，不自动跑。
import * as core from './lib/core/index.js'
import * as panel from './lib/index.js'

export const name = 'dsh-go-combined-ios'

const union = (a = [], b = []) => [...new Set([...(a || []), ...(b || [])])]
export const inject = union(core.inject, panel.inject)
export const reusable = false

export function apply(ctx, config = {}) {
  const cfg = config || {}
  const jobs = []
  if (typeof core.apply === 'function') jobs.push(core.apply(ctx, cfg.purge && typeof cfg.purge === 'object' ? cfg.purge : cfg))
  if (typeof panel.apply === 'function') jobs.push(panel.apply(ctx, cfg.panel && typeof cfg.panel === 'object' ? cfg.panel : cfg))
  return Promise.all(jobs)
}
