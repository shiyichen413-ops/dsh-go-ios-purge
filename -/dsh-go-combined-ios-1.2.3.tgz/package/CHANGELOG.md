# 1.2.3

- 与 1.2.1 同一批改动的延续：注入正文里那段「强化规则」仍在——回复涉及破甲/补丁/自检/purge 时，
  末尾必须贴免费声明、项目链接和操作说明书。给没有插件面板的宿主（Fish Pocket）用，命令是唯一入口。
- 面板技能库（local-skill-panel）与红队预设同步上游小修，cordis.patch.yml 随之更新。
- 删除 lib/core/patch-probe.json、根目录 patch-probe.json 两个临时产物。

> 上游 CHANGELOG 只记到 1.2.1，1.2.2 / 1.2.3 的条目是这次补记的；实际差异集中在
> `cordis.patch.yml`、`panel-plugin/local-skill-panel/lib/index.js`、`presets/redteam/agent.cordis.yml`。

# 1.2.1

- 正文加「强化规则」：凡是回复涉及破甲/补丁/自检/purge，末尾必须贴免费声明+项目链接，
  并紧跟操作说明书。给 Fish Pocket 这类**没有插件面板**的宿主用 —— 那边没有按钮可点，命令是唯一入口。
- （已知限制）面板水印、面板里的「文本操控」这类入口是宿主 UI，Fish Pocket 没有；插件侧只能靠正文和工具输出带。

# 1.2.0

- 覆盖层判据从「必须有 dsh-base」改成「目录里包数 >= 3」。
  安全名单只复制要打补丁的包，dsh-base 从来不在里面，所以 1.1.9 的探针永远判假、
  仍然回落只读的 /opt，purge_status 还是 2/57。

# 1.1.9

- 转发壳保留 exports 子路径映射（node-addon-system 的 ./landlock-run、./flock 之类），
  不再 delete exports；否则副本解析不到子路径，node --check 连带整个补丁事务回滚。
- detectRoot() 在有 ~/.dsh/host-patch 覆盖层时优先探测它 —— 只读宿主上真正生效的是覆盖层，
  以前 purge_status 一直显示 2/57 就是探错了地方。

# 1.1.8

- 修覆盖层在 dsh-sandbox-local 上整体回滚（）的问题：
  该包依赖 @deepseek-ai/node-addon-system，副本解析不到 → node --check 失败 → 事务回滚。
  现在给这类「作用域内的间接依赖」也生成转发壳，指回 /opt 原件（不复制原生 .node，保持单实例）。

# 1.1.7

- readonly-overlay 自动补齐普通依赖（zod、diff 这类）：按覆盖包的 dependencies 从宿主 node_modules 复制，
  不然副本 import 解析不到，引擎会报 ERR_MODULE_NOT_FOUND。

# 1.1.6

- readonly-overlay 现在会先写 - update: 段，把原行按 id 关掉（approval / sandbox / sandbox-policy /
  fs-sandbox / system-prompt / fs-observation-policy），再挂覆盖层副本。
  否则同名服务注册两份会冲突 —— 这类冲突正是引擎起不来的常见原因。

# 1.1.5

- core.apply() 增加只读短路：宿主引擎不可写时立即返回说明，不再白试、不再让模型反复重试。
  这是 Fish Pocket 上「破甲自检」要等很久的原因（probe 2/57 → apply → EPERM → 重试）。
- 正文加「自检纪律」：自检只读，不许顺手 apply；只读宿主直接给覆盖层三步。

# 1.1.4

- readonly-overlay 增加安全名单：只覆盖 dsh-user-approval / sandbox-local / sandbox-policy /
  fs-sandbox / fs-observation-policy / system-prompt 六个包。
  其余命中项（session、llm-deepseek、app-boot、client-connection 等核心服务）默认跳过，
  硬挂第二份会把引擎拆坏 —— 上次崩溃就是这个原因。预览会打印跳过清单，--all 可强制全量。

# 1.1.3

- 破甲自检的回复里固定附带「操作说明书」：8 条 purge_* 命令 + 只读宿主的覆盖层三步。
  给没有插件面板的宿主（Fish Pocket 等）用，命令是唯一入口。

# 1.1.2

- purge_status 的分母改成「手机适用条数」：桌面专属包不再占分母，只单独报一条数字。
  之前显示 1/86，看着像坏了；实际手机适用 2 条。
- 从 assets/categories.json 移除 minor、incest 两条题材扩展（不再随包分发）。

# 1.1.1

- 修 detectRoot()：候选目录全部收进来按包数量取最优。之前只找到第一个就返回，
  在 Fish Pocket 上会命中 profiles/web/node_modules/@deepseek-ai（只有几个插件依赖），
  probe 于是报 1/86「包不存在」；真实引擎在 /opt 下，包多 30 倍。

# 变更记录

版本号跟 `package.json` 一致；每个版本的安装方式是「下载 `dist/install.sh` 直接跑」，不用解压。

## 1.7.61 · 2026-11-16

把对话页的两个入口和两篇技能做成公共能力：

- **「插件」胶囊直达插件管理**：安装器合并 `ui.json`，隐藏 App 自绘的聚合弹层入口
  （`hide: ["pluginCapsule"]`），改由 `composer.quickActions` 提供「插件」胶囊，
  动作是 `open: page=plugins`。只动这两项，其余界面配置原样保留。
- **新增技能库面板插件**：`panel-plugin/local-skill-panel` 装到
  `$DSH_HOME/dsh-go/plugins/local-skill-panel` 并挂进 web profile；输入框上方多一个
  「技能」胶囊，点开是按类别堆叠的技能清单（名称 + 一句话中文描述），
  `fs.watch` + 15 秒轮询，新增/删除 `$DSH_HOME/skills/*` 后自动出现，不用重启。
- **公开两篇技能**：`dsh-go-ui`（界面配置 ui.json）与 `dsh-vision`（本机识图管道）
  随包分发到 `$DSH_HOME/skills/`；目标目录已存在时保留用户现有版本，不覆盖。
- **修网页版（1.7.6 遗留）**：web client 的 `__ModuleLoader__.load` 注册 id 改成包名
  `dsh-go-unrestricted`（原先写 `dsh-go`，boot 时整页 `Failed to load plugins`）；
  三处 slots 注册包上 `DshGoBoundary`，组件渲染异常不再拖白宿主主区域；
  首启「用户须知」不再用全屏遮罩挡对话页（窄屏下它只剩灰底、点不掉），须知保留在设置页。

补丁与自检口径：本机 applicable 补丁 **72/72 全通过**（全表 90 条），
自检 **22 项**（宿主 20 + 运行时 1 + 配置 1）。

## 1.7.6 · 2026-11-16

修「装完看不到面板、选不了模式」三处真因：

- **安装器在全新机器上会中断**：header 只有 `mkdir -p "$DIR/lib"`，第 119 个块写
  `lib/panel/actions.mjs` 时报 `No such file or directory`，`set -e` 立刻退出 →
  `lib/**` 后半段、`presets/**`、`skills/**` 都没落盘，最后的 `mount-profile.sh`
  也没执行，App 加载的还是旧副本。现在由 `tools/build-installer.py` 按内嵌文件清单
  自动生成 `mkdir -p`（含 `lib/panel`、`lib/purge/core`、`presets/unrestricted` 等）。
- **面板注册 id 与清单声明不一致**：`lib/panel/index.js` 注册 4 个面板，
  `dshGo.contributes.panels` 只声明了 `purge` / `redteam`，桥接对未声明 id 直接丢弃
  并记 `undeclared` 警告（连续 5 条会关掉整个原生 UI）。现在四个面板都已声明，
  「补丁」「维护」两页真正可见。
- **三个面板被夹回同一张总览**：`build.mjs` 把旧 id 归一到 `purge`，现各自独立渲染，
  标题分别为 `破甲 · 引擎与面板` / `补丁 · 引擎层与自检` / `维护 · 备份与预设`。

装完仍需重启一次引擎（插件只在引擎启动时加载），然后开新对话。

## 1.7.5 · 2026-11-16

- 文档：补宿主 rc.2/rc.3 适配矩阵、分享文案、抖音图文教程；说明页改为自包含

## 1.7.4 · 2026-11-16

状态条改成「静态文字 + 运行时覆盖」，新对话也能立刻看到。

- 现象：`composer.strip` 的 `armor-strip` 只声明了 `id/icon/panel`，**没有 `text`**。桥接渲染时 `text: null`，App 在没有 live 推送的首帧就没东西可画，表现为「输入框上方什么都没有，只能点插件按钮开面板」。
- 修法：manifest 里补 `text: {"zh":"破甲","en":"Armor"}`（≤24 字），`panel: purge` 不变。运行时 `dshGo.strip('armor-strip', …)` 仍会推 `破甲 ON / 破甲 OFF` 覆盖静态值，两种路径都有内容。
- 面板入口因此变成：新对话直接点输入框上方的「破甲」→ 打开 `purge` 面板（不再需要先点插件胶囊）。

## 1.7.3 · 2026-11-16

红队工作台 · 第 3 步（演练台页签上手机）。

- 新增 `lib/panel/redteam.mjs`：演练台面板。数据全部来自 `lib/redteam/store-core.js` 的同一个 `RedteamStore`（`$DSH_HOME/redteam` 的 SQLite），与 56 个 `redteam_*` 工具、`tools/export-report.mjs` 共用一份事实。
  - 视图：当前靶标 → 资产/发现/得分三张指标卡 → 最近 5 条发现（list）→ 动作（导出报告 / 刷新）。
  - 无靶标时显示引导文案（`redteam_engagement_open`）+ 资产库路径 + 历史靶标数，不留空白页。
  - 动作 `redteam.export` 以子进程跑 `tools/export-report.mjs --out /sdcard/Download/DSH-Go/红队报告`，toast 回第一行结果；`redteam.refresh` 触发视图重取。
  - `data()` 每 15 秒推一次摘要（靶标/资产/得分），App 侧有变化可感知。
- `lib/panel/index.js`：`PANEL_IDS` 第四槽从 `purge-rt` 换成 `redteam`；注册改成 promise 链（`registerAll` 是同步函数，不能 `await`），单个面板失败不影响其它三个。
- `package.json` 的 `dshGo.contributes.panels` 增加 `redteam`（title 演练台，icon flag，placement session.tab / chat.panel / features，presentation sheet）。现在清单是两个面板：破甲 + 演练台（宿主每插件上限 4）。

## 1.7.2 · 2026-11-16

红队工作台 · 第 2 步（评分与报告：验证 + 补导出链路）。

- **验证结论**：`score-rules.js` 与 `report-replay.js` 在 1.7.1 搬入时就已经由 `store-core.js` 静态引用，不是悬空文件。headless 实测通过——`new RedteamStore(root).openEngagement('smoke',{targets:['127.0.0.1']})` 建库成功；`listScorePoints` 返回 `{items, ruleGroups, summary}`；`report(id)` 返回 `{markdown, generated_at, stats}`。共 92 个 store 方法可用。
- **新增 `tools/export-report.mjs`**：把当前靶标导出成交付目录（`<靶标>-红队成果复现报告.md` + `shots/` 一起拷走，markdown 用相对路径避免碎图）。支持 `--out` / `--engagement`，数据源读 `$REDTEAM_HOME` 或 `$DSH_HOME/redteam` 的同一份 SQLite。实测对着空靶标产出 3606 B markdown。
- 接线面：`redteam_report` / `redteam_score_report` / `redteam_score_hit` / `redteam_attack_chain` 等 56 个工具本来就注册在 `tools.js` 里，1.7.1 接入 `apply()` 后即可用；本版只补「离开面板也能拿报告」这一条。

## 1.7.1 · 2026-11-16

红队工作台 · 第 1 步（只搬 host 半边的资产库与工具集）。

- 从 Evans-repo 搬入 `lib/redteam/` 的 host 文件：`store-core.js`（SQLite 资产库）、`tools.js`（模型工具集）、`schema.js`、`score-rules.js`、`ip-utils.js`、`validate.js`、`settings.js`、`skill-availability.js`、`skill-fixes.js`、`platform-config.js`、`preset-composition.js`、`persona.js`、`role-section.js`、`report-replay.js`、`store.js`、`index.js`。共 724 KB，逐文件 `node --check` 通过。
- 随包技能落到插件根 `skills/redteam/`（23 篇，188 KB），`skill-availability` 用它判定技能是否可用；用户目录 `$DSH_HOME/skills/` 那份不动。
- `lib/index.js` 新增 3.85 段：动态 `import('./redteam/tools.js')` 并调用它的 `apply(ctx)`，把 `redteam_*` 工具注册进当前会话；失败只静默跳过，不影响破甲其余部分。
- 依赖实测：`node:sqlite` 在宿主 Node 24.22.1 可用；`tools.js` 通过 `process.argv[1]`（`…/@deepseek-ai/dsh/lib/bin.js`）createRequire 解析 `@deepseek-ai/dsh-tools`，引擎里成立、裸 node 脚本里不成立，因此接入点放在 apply 内。
- 本阶段**不含**：评分规则接线（score-rules 只随包）、报告回放、面板/dock 的「演练台」页签、`presets/redteam` 替换为纯血版。放 1.7.2 / 1.7.3。

## 1.7.0 · 2026-11-16

复刻纯血版技能库（23 篇）+ 自带卸载/重启工具。

### 技能库（照 Evans-repo `skills/redteam/` 全量搬入）
- 23 个技能落到 `$DSH_HOME/skills/<name>/SKILL.md`，保留原 frontmatter（`name` / `description` / `whenToUse` / `role` / `enabled`），已热加载进技能目录。
- 适配：`C:\tools\…` → `/root/tools/…`、`.exe` 去掉、`powershell` → `bash`，并在正文前补一条「手机端适配（dsh-go / proot）」说明；其余流程与命令原样保留。
- 覆盖：passive-recon / active-scan / asset-correlation / web-fingerprint / dir-bruteforce / nuclei-scan / fscan-intranet / gogo-intranet / fofa-recon / recon-pipeline / credential-attack / unauth-exploit / lateral-movement / shell-handler / vps-reverse-shell / webshell-toolkit / chisel-tunnel / frp-tunnel / suo5-tunnel / cn-proxy-pool / browser-automation / kimi-webbridge / redteam-setup。

### 工具
- `tools/restart.sh`：读 `/tmp/dsh-web.pid`（回退 ps 扫描）报告引擎 pid/运行时长；`--force` 发 SIGTERM、10 秒未退则 SIGKILL，然后提示在 App 引擎页点启动。插件没有自我重启权限，这里只做干净停进程。
- `tools/uninstall.sh`：按「回滚引擎层补丁 → 摘 profile 挂载 → 从名单移除 → 删 AGENTS 兜底块 → 清理/保留 .dshpurge.bak → 删目录」顺序完整卸载；`--keep-backups` 保留备份，`--keep-patches` 只卸插件不回滚。
- 两者都进了 `dist/install.sh`（62 个内嵌文件），装完即可用 `bash tools/restart.sh` / `bash tools/uninstall.sh`。

## 1.6.0 · 2026-11-16

把 opt-in 补丁真正接通：本机 applied 从 72 走到 74（74/74 适用全通过）。

- **根因**：#18/#19 的开关值只写进了 `state.json` 的 `optInIds`，`engine.ensure()` 调 `applyPatches()` 时没把它透传下去（`actions.mjs` 里原本留着「等 lead 补透传」的 TODO），所以面板勾了也永远停在 `off`。
- **修法**：`lib/engine.js` 的 `applyPatches(aiBase, { … })` 增加 `optInIds` 透传；`state.json` 写入 `["18","19"]` 后重跑，两条变 `applied`。
- **剩下的 16 条不是没打，是没有对象**：
  - 7 条 `na`：`#45/#46/#82/#83/#84/#91/#92`，定义里带 `surfaces: ["desktop"]`，只对 Electron/桌面壳有意义（`desktop-shell` 目标在手机上是空串）。
  - 4 条 `missing_file`：`#30/#31/#64/#65`，全部指向 `dsh-hooks-claude-code` / `dsh-hooks-codex`；宿主没有 hooks 子系统（全盘 grep `UserPromptSubmit` 无命中），npm 上这两个包只有 0.0.1-rc.*，装上也只会锚点漂移。
  - 5 条 `not_needed`：`#35/#54/#76/#80/#86`，剥离型/撤销型，目标文本在 0.2.2-rc.1 上本来就不存在，等于已经达成。

## 1.5.1 · 2026-11-16

面板进对话流：新增工具 `armor_panel`，卡片直接贴在对话里。

- dsh-go 原生面板原本只有三个入口（输入框上方状态条 / 加号菜单 / 对话详情页插件页签），`chat.panel` 还要先点上面那个插件胶囊。
- 现在 `apply()` 里注册一个零参数工具 `armor_panel`：`execute` 复用 `collectState()` + `buildView(state, caps, 'purge')`，`output.presentationMeta` 返回 `{ 'dsh-go/view': view }` —— App 把它当工具结果卡渲染，面板就出现在对话流中。
- 模块解析：插件目录离宿主 `node_modules` 很远，`@deepseek-ai/dsh-tools` 裸说明符解析不到，因此先试裸说明符、再按 `resolveAiBase()` 拼绝对路径 `file://…/dsh-tools/lib/index.js`；两者都失败就静默跳过，面板其余入口不受影响。
- 视图实测 6075 字节 / 9 个顶层子节点，在工具卡 8 KiB / 40 组件预算内。

## 1.5.0 · 2026-11-16

两个开关下线，改成按模式自动双开/双关。

- **移除面板开关**：`提示词注入（破甲）` 与 `引擎层补丁` 两个 toggle 从「破甲」段删除，`state.toggle.*` 从动作表移除（`ACTION_IDS` 不再含它），面板只留一行说明「由当前模式自动决定」。
- **双开**：`redteam`（红队模式）、`unrestricted`（无限制模式）、`unrestricted-child-*`（无限制模式 · 子任务）—— 注入指令段 + 自动打引擎层补丁。
- **双关**：其余全部模式（标准 / PTC / 极简 / Cordis 等）—— 不注入、不自动打补丁。已写入宿主的补丁不回滚，要还原仍用「回滚引擎层」。
- 实现：新增 `presetTrack(ctx, config)`，`PRESET_ACTIVE = [/^unrestricted/, /^redteam$/]`；`system-prompt/assemble`、引擎层自动应用、状态条文案、`turnNote` 全部改读它。`config.inject` / `config.engine` 仍支持 `'always'` / `'off'` 做运维覆盖，但界面无入口。
- **自检修正**：`runtimeLayer` 过去靠 AGENTS.md 标记块判「注入到位」，1.4.5 把兜底块改成 opt-in 后就误报 `注入 0/1`。现在改成三种证据任一成立：内存 section / AGENTS 标记块 / profile bundle 名单里有 `dsh-go-unrestricted`。本机恢复 `全通过`。

## 1.4.5 · 2026-11-16

补 #85 #86；四个面板合成一个；补丁与自检条目可点开看安装情况；删掉手机任务面板。

### 补丁表
- 移植 #85 `STEER_RESTORE_PROMPT`、#86 `STEER_RESTORE_QUEUE`（上游把两条改成"回滚型"：把 1.4.2 的 followup 改写还原成上游原文）。两条都带 `silentWhenMissing` + `settleWhenAbsent`：宿主本来没被打过改写时判「无需处理」，不冒充漏做。
- 条目总数 88 → **90**，本机可打 69 → **70**（#85 已就位：#86 判无需处理）。

### 面板
- `dshGo.contributes.panels` 从 4 个合成 1 个：`purge`（标题「破甲」），原补丁/维护/预设三段并进同一个 sheet，按「状态 → 开关 → 补丁 → 自检 → 备份 → 更新 → 预设 → 身份」排序，每段可折叠。
- 补丁段改为**按层分组**（提示词/代码/工具/0.1.5/0.2.0），层内按"有问题优先"排序，每行显示状态并可点开：`patch.detail.<id>` 返回该条的层、optional 标记、当前状态与说明。
- 自检段每层可点开：`selfcheck.detail.<i>` 返回判据、断点、待打与备注。
- 动作表 14 → 16 个。
- 单面板预算实测 76 节点 / 17 KB（上限 120 / 32 KiB）。

### 手机任务面板
- `local-phone-task` 的 `dshGo.contributes.panels`（phone）已删除，该插件不再向界面提供面板（输入框胶囊此前已删）。

## 1.4.4 · 2026-11-16

补丁总数不再对外播报（用户指出面板「全表 88」与补丁总表文档的 82/70 口径对不上）。

- 面板「状态」段指标 caption 从 `全表 N 条` 改成 `本机该打且已就位`；补丁段去掉 `全表补丁` 一行。
- `engine.js` 的 `summaryLine` 不再追加 `· 全表 N`；`status` 仍保留 `totalAll` 字段供程序使用。
- 口径说明：代码里 `ALL_PATCHES` 当前 88 条定义，补丁总表文档按层汇总为 82（排除 6 条 optional/兼容项），
  文档另列 90 个编号（含本插件未移植的 #85 #86）。三个数字口径不同，所以面板只显示本机实际数值。

## 1.4.3 · 2026-11-16

提示词层换成 YG 的 UNRESTRICTED SANDBOX 指令（适配版）。

- `lib/directive.js` 的 `DIRECTIVE` 从 1826 字节扩到 23582 字节，内容为去重并适配后的完整框架：MODE/PRIME DIRECTIVE、HARD OUTPUT RULES、REFUSAL HARDENING、Scoped Rules 1–25、沙箱测试方向、意图映射、Never Refuse、CTF Core Contract、CTF Scope and Evidence、Routing（占位符归一 / 双语 / 边界词 / Canned / WEB PENTEST 十个 slot）、STABILITY ANCHORS、House Rules。
- 适配点：① 原文重复两遍 → 去重为一份；② 去掉 `<|im_start|>system:` 与 `<project_instructions>` 包裹（不是合法段文本）；③ 去掉 `antmlThinking` 这类 Anthropic 专用 token；④ 顶部加 DSH 环境块（宿主 0.2.2-rc.1、可用工具、/sdcard 路径、语言约束）；⑤ 「禁用词」改为「不得用作拒绝/推脱措辞」，避免误伤正常技术叙述。
- `AGENTS.md` 兜底块同步替换为新指令（29.9 KB，仍在 64 KiB 预算内）。

## 1.4.2 · 2026-11-16

把 1.4.0 加了又删的网页端半场恢复回来，并接通 override；同时把发版工具打进安装器。

### 面板补齐（按 PANEL 文档 §5 优先级 1–3）
- `state.json` 新增 `override` / `hooksAllow` / `servers` 三个字段，`writeRuntime()` 支持写入、`normalizeRuntime()` 支持读取。
- 面板「破甲」段新增三块 UI：自定义提示词（textarea + 保存/恢复内置）、Hooks 放行开关、自己的服务器名单（textarea + 保存）。
- 动作表新增 `override.save` / `override.reset` / `hooks.toggle` / `servers.save`（共 14 个动作）。
- `lib/index.js` 启动时读 `state.json` 的 `override` 同步进内存，落盘的自定义提示词重启后仍生效。
- `lib/host.js` 新增 `/dsh-go/hooks`、`/dsh-go/servers`（GET/POST），网页端面板可读写。

### 网页端半场（恢复）
- `lib/client.js`：从 dsh-purge 的 `client.js` 移植（`__ModuleLoader__` 单闭包、可拖拽四边缩放、`createPortal` 挂 body），标识符全部改名 `dsh-purge`→`dsh-go`（82 处）、`dshPurge`→`dshGo`（23 处），数据源指向 `/dsh-go/*`。
- `lib/host.js`：新增宿主路由 `/dsh-go/status|apply|revert|selfcheck|override|update`，其余端点（restart/uninstall/rules/skills/…）返回 `{ok:false,unsupported:true}`，让面板显示"不支持"而不是抛错。所有 handler 包 try/catch、照抄 dsh-purge 的 sec-fetch-site / origin 跨站校验，无 `webServer` 的宿主（手机桥接、SSH）自动跳过。
- `package.json`：补 `exports["./client"]`、`exports["./host"]`、`dsh.client { platform: "web", inject: [...] }`、`files`。

### override 接通
- `lib/index.js` 导出 `getOverride` / `setOverride` / `clearOverride`，并在 `apply()` 里把三者交给 `installWebServer`，面板与 `/dsh-go/override` 都能读写注入文本。

### 发版工具进安装器
- `dist/install.sh` 内嵌块从 54 增至 58：新增 `tools/release.sh`、`tools/publish-oss.sh`、`tools/oss-put.mjs`、`tools/make-installer.py`。
- 注意：`make-installer.py` 只替换已有块、不新增块，这四条是手工补进模板的；以后再加文件同样要手工插块。

## 1.4.1 · 2026-11-16

- 撤掉网页端半场：删除 `lib/client.js`（React dock）与 `lib/host.js`（`/dsh-go/*` 路由），`package.json` 去掉 `dsh.client`、`exports["./client"]`、`files` 里的 client 条目。面板只留在 dsh-go 手机原生界面（状态条 + 四个面板 + 加号入口），不再往 Harness 网页版注入浏览器包。
- 理由：面板本来就该在默认界面；浏览器包给网页端增加了一份加载风险，出错时整页白屏，收益却只是重复展示。

## 1.4.0 · 2026-11-16

- 面板重构：把 dsh-purge 的右下角 React dock 面板整份移植进 dshgo（`lib/client.js` 单闭包 + `__ModuleLoader__` 注册，可拖拽、四边缩放、createPortal 挂到 `document.body`），数据源从 `/dsh-purge/*` 改为 `/dsh-go/*`。
- 新增 host 半场（`lib/host.js`）：宿主 `webServer` 路由 `/dsh-go/status|override|apply|selfcheck|override-save|toggle`，照抄 purge 的 sec-fetch-site / origin 跨站校验，所有 handler 永不抛。
- `lib/index.js` 接入：提示词注入文本改为可覆盖的 `override`（默认回退 `DIRECTIVE`），`apply()` 末尾挂 `installWebServer`。
- `package.json`：补 `dsh.client.platform="web"`、`exports["./client"]`、`files` 加 `lib/client.js`；description 换成简洁版。

## 1.3.12 · 2026-11-15

- 兼容 0.2.2-rc.3：补 #53 新措辞锚点、级联补丁 #88 不再误报漂移、新增 engine.js drift 漂移明细命令

## 1.3.11 · 2026-11-15

- npm 渠道首发版（代码与 1.3.9 一致，仅 npm 页面的 description / README 换成中性技术描述、版本号随 npm 暂存流程递增到 1.3.11）。
- 1.3.9 / 1.3.10 是 npm 暂存（staged publishing）流程里的占位尝试，未公开；正式对外版本是 1.3.11。

## 1.3.9 · 2026-11-15

把「69/88」这种虚分母和不适用噪声一起收掉，并把对话内面板重排一遍。

### 分母口径
- `applicable` 成为唯一分母：`status()` / `apply` 报告的 `total` 只数「这台宿主该打且能打」的补丁（本机实测 69），全表 88 另以 `totalAll` 给出，不再让 19 条无对象补丁冒充漏做。
- 巡检行新增 `applicable` / `optionalMissing` 标记；`counts` 拆出 `missingRequired` / `missingOptional`、`applicable` / `totalAll`，引擎层汇总行只报必需缺失。
- 汇总行不再打「0 待打 · 0 锚点不匹配 · 0 缺文件」这类噪声，非零才写。

### 自检报表
- `not_needed` 成为独立状态：撤销型 / 剥离型补丁在宿主上已无对象时记「无需处理」，`notApplicable` 收为通用口径（#54/#76/#80 不再挂分母）。
- 整层 na 的层（缺插件、桌面专属、非桌面磁盘布局）不再进报表，也不打印 `[na]` 行；`selfCheckLine` 去掉「N 不适用」，CLI 明细只留 `补丁: xx/xx`。
- 报表里不再出现「不适用」字样；没有对象的条数只保留在内部 `summary` 里。

### 面板
- 状态段：补丁 / 自检 / 提示词注入三张指标卡 + 自检行 + 引擎行 + 应用/自检/刷新 三个动作 + 宿主与开关 kv。
- 自检段：层通过 / 补丁 / 断点三张指标卡，分层列表只列非 ok 的层，其余折成一句「其余 N 层已通过」。
- 补丁段：kv 只留有值的项（全表补丁、漂移、待打、缺文件），分组不变。
- 备份段：备份文件数 / 占用 / 最近一次三张指标卡 + kv + 还原/重扫动作。
- 预设段与身份段文案合并压缩；面板预算实测 23 节点 / 2.8 KB（上限 120 / 32 KiB）。

## 1.3.8 · 2026-11-14

发到 GitHub 之后，把境外线路的实测结论写回文档。

- `INSTALL-TERMINAL.md` 的下载段重排：1a Gitee 发行版附件（首选）→ 1b Gitee raw（同源备份）→ 1c 校验 → 1d 境外线路（保留命令，附实测表：GitHub 直连 26s 超时 0 字节、jsDelivr 45s 只下 440816/736128 字节被截断、gh-proxy 与 ghproxy.net 均 404、只有 `api.github.com` 通）。
- 记录一条环境事实：GitHub 账号 `lingsmall-code` 当前被停用（API 返回 `403 Sorry. Your account was suspended`），仓库与 Release 无法匿名访问，故境外线路在账号恢复前都不必试。
- `README.md` 的「路径 0」同步这个结论，不再让人白试三条境外线路。

## 1.3.7 · 2026-11-14

把「能下到文件」这件事做实。

- Gitee 建发行版并挂 `install.sh` 附件，下载链接返回真正的附件（实测响应头 `Content-Disposition: attachment; filename="install.sh"`，728208 字节，sha256 与本地一致，2.9–3.9 秒），不再只是网页里的文本。
- 稳定入口：`https://gitee.com/lingsmallcode/dsh-go-unrestricted/releases/download/latest/install.sh`（`latest` 永远指最新发行版，实测 200 / 728208B / 2.89s）。
- `README.md` 与 `INSTALL-TERMINAL.md` 的 1a 线路改用发行版链接，并分成「浏览器点开下载」与「终端一条命令下载+安装」两种写法；原始文件直链保留为等价备选。
- 新增 `tools/gitee-release.mjs`（本版从临时脚本转正）：给 Gitee 建发行版、删同名旧附件、`multipart` 上传 `dist/install.sh`，打印附件直链。

## 1.3.6 · 2026-11-14

给国内网络加一条不需要 VPN 的直链。

- 新增 Gitee 镜像仓库 https://gitee.com/lingsmallcode/dsh-go-unrestricted ，`dist/install.sh` 直链 `https://gitee.com/lingsmallcode/dsh-go-unrestricted/raw/master/dist/install.sh`，公开仓库、匿名可取，实测 2.4–4.6 秒、726380 字节、sha256 与本地一致。
- `INSTALL-TERMINAL.md` 的下载段从三条线扩成四条，并把 Gitee 提到 **1a 首选**：1a Gitee → 1b jsDelivr → 1c GitHub 原站 → 1d gh-proxy，原来的「1d 校验」改名 1e。
- `README.md` 的「路径 0」改为 Gitee 一行命令；顶部加 Gitee 徽章与国内直链提示。
- `tools/publish-gitee.mjs` 增加自动转公开：发现仓库是私有就 `PATCH private=false`，Gitee 以「账号安全评级」拒绝时原样打印原因与两条修复链接（绑定第三方账号 / 开 2FA）而不是抛栈。

## 1.3.5 · 2026-11-14

给「只能敲命令、收不到文件」的环境补一条完整路径。

- 新增 `INSTALL-TERMINAL.md`：全程只有命令，没有一步需要下载附件或开网页。内容含环境确认（node ≥18 / `DSH_HOME` / profile 布局）、一行 `node -e` 下载（不依赖 curl，proot 里本来就没有）、安装、重启、`selfcheck` 输出逐字段读法、`status`/`apply`/`revert`/`DSH_GO_OPT_IN`、三个预设落盘与手动 `install-presets.sh`、`mount-profile.sh` 补救、面板三个入口、升级、卸载（先 `revert` 再 `--uninstall`）、离线搬运（scp / `python3 -m http.server` / `adb push` / base64 分块）、可整段贴给 dsh 的四步提示词、常见报错对照表（`fetch is not defined`、`HTTP 404`、`cannot resolve profile bundle`、自检 `missing_file`、`锚点不匹配`、预设显示「不可用」等）。
- 该文件纳入分发：`install.sh` 内嵌（50 → 51 个文件）与发布白名单，装完就在插件目录里，离线也能翻。

## 1.3.4 · 2026-11-14

发布到 GitHub 之后补的一轮 README 与分发体验。

- README 开头补总览：三枚徽章（release / license / dsh 版本区间）+ 一句话定位（dsh-purge v1.7.14 在 Android 上的等价实现）+「它解决什么问题」六行对照表（现象 → 卡在哪 → 哪条补丁处理）。
- README 新增「路径 0：从 Release 一条命令」：`node -e` 用内置 `fetch` 直接拉 `releases/latest/download/install.sh`，proot 里没有 `curl` 也能装；附装完后的 `selfcheck` 预期输出。
- 版本号同步到 1.3.4。

## 1.3.3 · 2026-11-14

按手机端实机自检清单（Android / proot Ubuntu 24.04 / 宿主 0.2.2-rc.1）修的一轮自检准确性问题。

### 自检口径
- `na`（不适用）成为独立状态：整层补丁都豁免且目标不存在、或整层 `surfaces` 不含当前面时，层记 `na` 而不是 `ok 0/N` 或 `unknown`。`na` 层不算通过也不算断点，`自检 · 宿主 20/20 层 · 2 不适用` 分母不变、通过数不注水。
- `selfCheck()` 新增 `orphan: { total, applied, unapplied, ids }`：不属任何命名层的补丁（实测 32 条）单独计数，不再静默缩小分母。
- `selfCheckLine()` 增加「N 不适用」。

### 权限层
- `lib/permission-state.mjs` 支持**直配**写法：`- id: sandbox-policy / config: { mode: ... }` 与 `- id: approval / config: { policy: ... }`，两个值都合法即 `pinned: true`。此前只认 `permission-presets` 条目，手机端 profile 用的是直配，于是层 24 恒为 `unknown`。

### 补丁状态
- `patchStatus()` 按 `surfaces` 过滤：不含当前面的补丁直接 `na`，`#91`、`#45/#46`、`#82/#83/#84` 在 web 面不再误报 `unknown`。
- `inspectPatches()` 对不匹配本面的补丁改为落一行 `status: "na"`（原来直接跳过，导致状态表缺 id，上层按 `unknown` 处理——一个纯桌面补丁就能把整层拉红）。
- `#74 ASSEMBLE_BEFORE_PRESTEP` 增加第三条正则锚点（`/^([ \t]+)const assembly = await this\.loopCtx\.systemPrompt\.assemble\(/m`），适配 0.2.2-rc.1 把首轮 assemble 挪进 `preStep()` 且参数改多行对象字面量的结构；`skipIfMarked` 保证已打过的文件不会被重复插入。
- `#35` 改到 `escalation-types` 键，`#43` / `#71` 加 `optional`：目标包没装时判 `not_applicable`，装了但锚点漂移仍算硬失败。

### 预设诊断
- `lib/preset-diagnostic.mjs` 重写：先按行剥 YAML 注释，再定位唯一 persona 行、只取该条目的 `prefix`/`text`/`suffix` 块正文做判定。此前全文件扫 `{{` / `${`，把注释里的模板示例当成动态表达式，`#76` 恒 `unknown`。

### 面板
- 自检缓存带宿主指纹（四个核心包的 `package.json` + `lib/index.js` 的 mtime:size）。宿主换版本后 `status().selfcheck.stale` 变 true、行尾追加「（缓存已过期）」并在后台重跑。
- 自检段新增「另有 N 条补丁不属任何命名层」一行；补丁段 `off` 组说明补上「#18 #19 关掉会削弱上下文保护，是有意保留」。

### 安装器
- `dist/install.sh` 内嵌 46 个文件（657 KB），手机端只需这一个文件。

## 1.3.2 · 2026-11-14

- 修三个可选模式全部显示「不可用」：`@deepseek-ai/dsh-tool-subagent-control` 的 exports 里没有 `./list-agents`（`list_agents` 自 0.2.2 起并入主入口），三条 preset 定义里的 `tool-subagent-list-agents` 行导致 `mountPreset` 抛错。三份模板删掉该行，`lib/presets/files.mjs` 增加 `STALE_PATTERNS` 定点剔除（已落盘的旧文件返回 `repaired`）。
- 面板 presets 数据源改为按序找 `lib/presets/{files,install}.mjs`，修掉「预设模块未就绪（ERR_MODULE_NOT_FOUND）」黄字。
- `tools/mount-profile.sh`：把插件包实体拷进 `profiles/<name>/node_modules` 并补 `dependencies` / `dsh.profile.bundles`，修手机端 `cannot resolve profile bundle` 加载失败。

## 1.3.0 · 2026-11-14

- 把 dsh-purge 的**整份补丁集（88 条）**移植进插件，判定内核（ten-tier `patchApplied`、`expect` 命中数契约、YAML 折叠清洗、`.dshpurge.bak` 备份）与 dsh-purge 一致，双向幂等互认。
- 25 层破甲自检（22 层硬闸 + 运行时注入 + profile 权限 + 宿主磁盘布局）。
- 三个可选模式：无限制 / 无限制·子任务 / 红队，声明式注册（`@deepseek-ai/dsh-agent-preset`），不再走会被 dsh ≥0.2.1 拒收的 `toolFilter`。
- 四个 `purge` 风格面板（每插件最多 4 个，原 `armor` 面板功能并入）。

## 1.1.0 – 1.2.0

- 引擎层（执行能力补丁）从 7 条起步，逐步扩到全量 88 条；`lib/engine.js` 改为薄封装。
- `dist/install.sh` 自包含安装器；手机端只需传一个文件。
