# iOS / 内嵌运行时适配说明

目标环境：dsh-go iOS App 1.1.0，内嵌引擎 DSH 0.2.2-rc.1 / Node 24.22.1，容器路径形如
`/private/var/mobile/Containers/Data/Application/<UUID>/Library/Application Support/runtime/rootfs/root`。

这个环境跟 Android/proot、桌面端有三处硬差别，上游的默认写法全部会挂：

## 1 · 没有子进程（`spawn` 不可用）

上游两处依赖 `child_process`：

- `patches/lib/core.mjs` 的 `verifyFile()` 对每个改过的 `.js` 跑 `execFileSync(node, ['--check', file])`；
- `lib/tools.js` 的 `runPatchScript()` 用 `execFile(node, ['patches/purge-patch.mjs', mode])`。

没有 `spawn` 时两处都必失败：前者会让事务逻辑把刚打的补丁**整体回滚**（现象：`apply` 说「补丁已重打」，实际 0 条生效），后者让 `probe` 永远「扫描失败」。

处理：

- `runPatchScript()` 改成进程内 `await import('patches/lib/core.mjs')` 后直接调 `probe/apply/restore`，并给 import 加时间戳做 cache-busting（改补丁逻辑不必重启引擎）；
- `verifyFile()` 把「起不了子进程」的错误码（`EPERM/ENOENT/ENOSYS/EACCES`、无 `status`、stderr 含 spawn/not permitted）判成 `UNVERIFIED` 放行，只有真正的语法错误（有退出码 + stderr）才算失败。

## 2 · 引擎包不在桌面路径

`detectRoot()` 原来只找 `/opt/dsh/node_modules/@deepseek-ai`、`~/.npm-global`、`/usr/local/lib` 和 `npm root -g`。
内嵌运行时把包放在 `<容器>/Library/Application Support/dsh-runtime/tree/node_modules/@deepseek-ai`。

处理：先按 `process.execPath` / `process.cwd()` / `import.meta.url` 逐级向上找 `node_modules/@deepseek-ai`，
再用 `createRequire(import.meta.url).resolve('@deepseek-ai/dsh-base/package.json')` 反推目录，最后才回落原表。

## 3 · 路径里有空格

容器路径含 `Application Support`。`new URL(import.meta.url).pathname` 会给出 `Application%20Support`，
于是 `patches/patches.json` 永远 `ENOENT`（报错形如 `open '.../Application%20Support/.../patches.json'`）。

处理：`resolvePatchesFile()` 改用 `path.dirname(fileURLToPath(import.meta.url))`。

## 4 · 预设里的 anchor-gate 写死了安卓路径

`cordis.patch.yml` 内联的红队预设里有一行：

```yaml
- id: anchor-gate
  name: file:///root/.dsh/.agent-presets/redteam/anchor-gate.mjs
```

iOS 上没有 `/root/.dsh`，模块 `never started`，宿主就把整条红队预设判 broken，
下拉里显示「红队模式 · 不可用」。

注意：预设内容是**整份内联在 `cordis.patch.yml`** 里的，宿主**不读** `$DSH_HOME/.agent-presets/*.yml`
（那是模板副本，只在插件 `install-presets` 时落盘）。只改模板不起作用。

处理：从内联段移除 anchor-gate。它只做首轮限输出（`maxBootstrapSteps: 2`、`bootstrapMaxTokens: 8192`），
缺了不影响红队工作，只是首轮可能话多。要恢复就把路径改成真实容器路径并对空格做 `%20` 编码。

## 其它

- `lib/redteam/role-section.js` 顶部 `import { isRedteamSession } from '../identity.js'` —— 上游仓库里没有这个文件，
  也没人 import 本模块，一直没炸。合并包改成局部实现（按预设 id 判断是否红队会话）。
- 预设模板里 `skill-filesystem.config.customSkillDirs` 写的是 `/root/.dsh/skills`，iOS 上这两个目录不存在；
  skill-filesystem 遇到缺失目录会跳过，不影响挂载，但红队看不到随包技能。需要的话改成真实路径。
