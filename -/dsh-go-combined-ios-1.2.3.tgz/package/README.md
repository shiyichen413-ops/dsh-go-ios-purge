# dsh-go-combined

> ### ⚠️ 二改声明
>
> **本项目是二改（fork 合并修改）作品，不是原创。**
>
> 主体来自两份上游代码：
>
> - **[dsh-purge](https://github.com/NANA7MI0/dsh-purge-go)（dsh-go-purge 0.4.18）** —— 作者 **NANA7MI0**；其原始作者为 **YuJunZhiXue**。本项目把它的提示词注入层、`purge_*` 工具与全部补丁表原样搬进 `lib/core/`。
> - **[dsh-go-unrestricted](https://github.com/lingsmall-code/dsh-go-unrestricted) 1.7.61** —— 提供三套 agent 预设、面板、自检与引擎补丁引擎，位于 `lib/`、`presets/`、`panel-plugin/`。
>
> 本项目只做三件事：**把两者合进一个 bundle**、**补 iOS / Fish Pocket 内嵌运行时适配**、**重新打包发布**。注入与补丁能力本身来自上游，出问题请先对照上游。
>
> 因为包含 AGPL-3.0 代码，本仓库整体按 **AGPL-3.0** 发布；二次分发必须保留本声明与 `NOTICE`，并同样开源。

> 项目地址：<https://github.com/jixiaolan7/dsh-go-purge-ios>　·　完全免费，禁止倒卖

把两套 DSH 破甲/红队实现合成一个 bundle：**一个包、一次登记、两套能力**。

| 子系统 | 来源 | 目录 | 提供什么 |
| --- | --- | --- | --- |
| 注入层 + 工具 | [dsh-go-purge](https://github.com/NANA7MI0/dsh-purge-go) 0.4.18 | `lib/core/` | 系统提示扩展（`prompt-inject.md`、变体、按模型映射）、`purge_*` 工具、引擎补丁表 |
| 面板 + 预设 + 自检 | [dsh-go-unrestricted](https://github.com/lingsmall-code/dsh-go-unrestricted) 1.7.61 | `lib/`、`presets/`、`panel-plugin/` | `unrestricted` / `unrestricted-child` / `redteam` 三套 agent 预设、四个面板、`selfcheck`、它自己的补丁引擎 |

`index.js` 把两边各自的 `apply()` 挂在同一个插件上，`inject` 取并集。

## 本版（1.2.0）：补丁层终于读得对了

三个版本连着修的是一条链，症状都一样——`purge_status` 永远显示 `2/57`：

| 版本 | 问题 | 修法 |
| --- | --- | --- |
| 1.1.7–1.1.8 | `dsh-sandbox-local` 依赖 `@deepseek-ai/node-addon-system`，覆盖层副本解析不到 → `node --check` 失败 → **整个补丁事务回滚**，`--apply` 打印 `ok 0 · 失败 1` | 给「作用域内的间接依赖」也生成转发壳，指回 `/opt` 原件（不复制原生 `.node`，保持单实例） |
| 1.1.9 | 转发壳生成时 `delete pkg.exports`，而 `node-addon-system` 是被**子路径**引用的（`./landlock-run`、`./flock`）→ `Cannot find module` | 每个子路径生成对应转发文件，`exports` 原样指过去 |
| 1.2.0 | `detectRoot()` 判覆盖层的条件是「有 `dsh-base`」，可安全名单从来不含 `dsh-base` → 判假，回落到只读的 `/opt` | 判据改成「目录里包数 ≥ 3」 |

现在自检读的是真正在跑的覆盖层：

```
root: ~/.dsh/host-patch/node_modules/@deepseek-ai
tally: {"no_pkg":72,"applied":14}
```

`applied 14` 是真的生效数。`no_pkg 72` 不是坏了——覆盖层只复制了 16 个包，其余补丁在这层里没有目标文件；原始引擎 `/opt` 那侧仍是 `applied 2 · hit 29`（29 条随时可打）。

## 1.1.4：覆盖层加安全名单，不再「一打就炸」

之前的覆盖层是全量的：补丁命中的 36 个包全被复制一份挂上去，其中 `dsh-session`、`dsh-llm-deepseek`、`dsh-app-boot`、`dsh-client-connection` 这些是**引擎核心服务**，挂第二份就等于同一服务被实例化两次，启动直接崩、无限重启。

1.1.4 起只覆盖 6 个「改了也不会拆坏引擎」的包：

```
dsh-user-approval  dsh-sandbox-local  dsh-fs-sandbox
dsh-fs-observation-policy  dsh-system-prompt  dsh-sandbox-policy
```

其余 30 个默认跳过，预览时会打印跳过清单；确实要全量得显式 `--all`。

```bash
node tools/readonly-overlay.mjs            # 预览：要覆盖谁、跳过谁
node tools/readonly-overlay.mjs --apply    # 执行（改前自动备份 patch 文件）
node tools/readonly-overlay.mjs --rollback # 撤销
```

## 1.1.3 起适配鱼袋（Fish Pocket）

鱼袋是 iOS 上原生跑 DSH 的宿主。它不是唯一宿主——**dsh-go 同样能用**，本包对两边都在测。这一版把鱼袋上会让上游代码整块判死的三个特征逐条对上；改的都是宿主无关的健壮性，dsh-go 上不受影响：

| 症状 | 根因 | 修法 |
| --- | --- | --- |
| 自检报 `1/86 · 84 条包不存在`，看着像全坏了 | `detectRoot()` 找到第一个候选就 return，命中的是 `profiles/web/node_modules/@deepseek-ai`（只有几个插件依赖） | 候选目录全部收进来**按包数量取最优**，正确落到 `/opt/dsh/nodejs-project/node_modules/@deepseek-ai` |
| 插件页红色「异常」：`failed to import: Cannot find package 'dsh-go-unrestricted'` | 包内 `cordis.patch.yml` 的 entry 还写着上游包名，而 bundle 已改名 `dsh-go-combined` | entry 的 `id` / `name` 同步改成 `dsh-go-combined` |
| 红队预设整条 broken | `anchor-gate` 挂 `file:///root/.dsh/...`，iOS 的 `HOME` 不是 `/root` | 这条从内联段移除；`customSkillDirs` 同步改成真实的 `$DSH_HOME` |
| 自检结论给了却不知道下一步点哪 | Fish Pocket 没有插件面板，工具是唯一入口 | `purge_status` 回复固定附**操作说明书**：8 条 `purge_*` 命令 + 只读宿主覆盖层三步 |

另外 1.1.2 起 `purge_status` 的分母改成「手机适用条数」，桌面专属包不再占分母。

## 装

**iOS（鱼袋 / dsh-go）看 [INSTALL-IOS.md](INSTALL-IOS.md)，一条命令：**

```bash
tar -xzf dsh-go-combined-1.1.3.tgz
PKG=$PWD/package bash scripts/install-ios.sh
```

桌面 / 有终端的主机：

```bash
# 目标：<DSH_HOME>/profiles/web/node_modules/dsh-go-combined
#      并在 profiles/web/package.json 的 dsh.profile.bundles 里加 dsh-go-combined
dsh plugin --profile web add /path/to/dsh-go-combined
```

装完重启引擎。默认只有 `lib/core` 的补丁表会被 `purge_patch_apply` 应用；`lib/` 那套补丁引擎走它自己的面板/CLI，**不会自动跑**，两边不会互相覆盖。

装到 Fish Pocket 这类非 root 宿主后，先自检一遍路径：

```bash
grep -n "/root/.dsh" ~/.dsh/profiles/web/node_modules/dsh-go-combined/cordis.patch.yml
# 有命中就说明 HOME 不是 /root，换成你的真实路径：
sed -i '' "s|/root/.dsh|$HOME/.dsh|g" ~/.dsh/profiles/web/node_modules/dsh-go-combined/cordis.patch.yml
```

## 补丁层怎么用

```
purge_status                                   # 两层状态
purge_patch_apply {"mode":"probe"}             # 只扫不改
purge_patch_apply {"mode":"apply"}             # 打补丁（先备份到 <DSH_HOME>/dsh-purge/patches-backup-*）
purge_patch_apply {"mode":"restore"}           # 从最近一次备份还原
```

宿主把引擎装成**只读**时（Fish Pocket、dsh-Go 的 App 包内运行时），`apply` 写不进去，要先建覆盖层：

```bash
cd <plugin>/tools
node readonly-overlay.mjs            # 只看计划：命中哪些包、要不要写 patch
node readonly-overlay.mjs --apply    # 复制到 ~/.dsh/host-patch 并写 insert 行（改前自动备份）
node readonly-overlay.mjs --rollback # 撤销
```

## iOS / 内嵌运行时的适配（见 `IOS-NOTES.md`）

上游的几处桌面假设在 iOS 上不成立，都会让补丁层或预设整块判死，本包已修：

1. `detectRoot()` 只认 `/opt/dsh`、npm 全局等桌面路径 → 改成从引擎自身路径向上找 `@deepseek-ai`，并用 `createRequire` 反解；
2. `resolvePatchesFile()` 用 `new URL(import.meta.url).pathname` → 容器路径里的空格变 `%20`，`patches.json` 永远 ENOENT，改用 `fileURLToPath()`；
3. `verifyFile()` / `runPatchScript()` 依赖子进程（`node --check`、`execFile(purge-patch.mjs)`）→ 内嵌运行时没有 `spawn`，改成进程内调用 + `UNVERIFIED` 降级；
4. 红队预设的 `anchor-gate` 写死 `file:///root/.dsh/...` → iOS 无此路径，模块 never started 会让整条预设 broken，已从 `cordis.patch.yml` 内联段移除。

## 目录

```
index.js                合并入口（挂 core + panel 两套 apply）
cordis.patch.yml        bundle patch：本插件 + 三套预设（plugins 内联声明）
lib/core/               purge：注入层、purge_* 工具、patches/（86 条表 + 应用器）
lib/                    unrestricted：面板、selfcheck、它自己的补丁引擎、redteam 逻辑
tools/                  发布脚本 + readonly-overlay.mjs（只读宿主覆盖层）
presets/                预设模板副本（真正生效的是 cordis.patch.yml 里内联的那份）
skills/ skills-public/  随包技能
panel-plugin/           技能库面板插件
```

## 关于本包做了什么（给评估者）

- 它是一份 **DSH bundle 插件**，安装方式是复制目录 + 在 `profiles/web/package.json` 里登记包名，不改动系统。
- 运行时它做两件事：① 在组装 system prompt 时插入一段可自定义的指令文本（`prompt-inject.md`，用户可改可关）；② 提供一组工具，用于查看自身状态、切换文本变体、以及**在用户显式执行时**对引擎配置文件做替换（默认不执行，`--apply` 才动手，`--rollback` 撤销）。
- 它不安装后台服务、不常驻进程、不访问网络上的第三方服务、不读写与 DSH 无关的目录。
- 卸载：删除 `node_modules/dsh-go-combined` 并把包名从 `bundles` 移除，重启即恢复原状。

## 免费声明

**本项目完全免费。** 作者不收任何费用、不卖授权、不卖源码，也没有付费版、内测版、"高级授权"。

- 在闲鱼 / 淘宝 / 群里看到有人拿这个收钱、收费代装、收费"解锁"：那是倒卖，与本项目无关，**别付钱**；
- 破甲自检的结论行、`purge_status` 的顶部都会打印这句话，对照一下就知道对方给你装的是不是原版；
- 二次分发请保留本段与 `NOTICE`（AGPL-3.0 也要求保留来源与许可）。

## 许可

合并包整体 **AGPL-3.0**：`lib/core/` 来自 AGPL-3.0 的 dsh-go-purge；`lib/`、`presets/` 等来自 MIT 的 dsh-go-unrestricted（MIT → AGPL 兼容，反之不行）。详见 `NOTICE`。
