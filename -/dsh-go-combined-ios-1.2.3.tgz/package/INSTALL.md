# 安装

## 方式一：从 GitHub 源装（推荐）

```bash
dsh plugin --profile web add jixiaolan7/dsh-go-purge-ios
```

装完**完全退出 dsh 再启动**才会加载。iOS 客户端（DSH Go / Fish Pocket）没有终端时，在电脑上对同一台主机执行；
或用客户端「插件 › 发现 › 添加索引源」挂索引后点装。

## 方式二：离线拷目录

```bash
git clone https://github.com/jixiaolan7/dsh-go-purge-ios.git
mkdir -p "${DSH_HOME:-$HOME/.dsh}/dsh-go/plugins"
cp -R dsh-go-purge-ios "${DSH_HOME:-$HOME/.dsh}/dsh-go/plugins/dsh-go-combined"
# 然后在 ${DSH_HOME}/profiles/web/package.json 的 dsh.profile.bundles 里加 "dsh-go-combined"
```

## 装完检查

```bash
cd "${DSH_HOME:-$HOME/.dsh}/dsh-go/plugins/dsh-go-combined"
node lib/core/patches/purge-patch.mjs probe    # 补丁层分布（桌面/Android 有子进程时可用）
```

对话里调 `purge_status` 看两层状态；面板在「插件」页签。

## iOS 注意

见 `IOS-NOTES.md`：内嵌运行时没有子进程、引擎包不在桌面路径、路径含空格、预设里的 anchor-gate 写死安卓路径 ——
这四处都已在本包里修好。但**依赖子进程的 CLI 入口**（`purge-patch.mjs`、`selfcheck` 的命令行）在 iOS 上仍然跑不了，
要用对话里的工具或面板。
