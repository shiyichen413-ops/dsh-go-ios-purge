---
name: dsh-vision
description: 让没有视觉能力的模型也能看图。把图片送进任意 OpenAI 兼容的视觉模型，拿回纯文字证据（OCR、界面结构、图表读数、差异描述），再交给当前文本模型继续干活。适用于用户贴图、截图、报错窗口、长截图、设计稿、图表，或要求「看图并定位文字坐标」。自带 dsh-see 命令行、可选 MCP 工具 mcp__vision__see_image / see_ocr / see_many / see_latest，以及 modlens_read_image 通道。
whenToUse: 会话里出现图片（聊天附件 sha256、文件路径、URL、手机截图），或用户问「图里写了什么」「这张截图什么情况」「帮我看看这个界面」「识别一下这个报错/表格」「这两张图差在哪」，而当前模型本身不支持图像输入时。纯文字任务不要加载。
---

# dsh-vision：给无视觉模型装上眼睛

文本模型不能直接读像素。做法是**把图送进一个视觉模型，拿回文字证据，再喂回当前模型**——
换任何主模型都能继续看图，代价只是多一次小请求。

这个技能描述的是通用管道与用法；本机有没有装好、走哪条通道，按下面的「选择入口」现场确认。

## 选择入口（按可用性从高到低）

| 优先级 | 入口 | 前提 | 用法 |
|---|---|---|---|
| 1 | 原生工具 `modlens_read_image` | harness 里配了 modlens 视觉引擎 | 直接传路径 / `sha256:...` / URL |
| 2 | MCP 工具 `mcp__vision__see_image`、`see_ocr`、`see_many`、`see_latest` | profile 里注册了 vision MCP server（改了要重启 App 才加载） | 传 `image` + `question` |
| 3 | 命令行 `dsh-see` | 本机装了这条管道（见「自建管道」） | `dsh-see <图片> [--ask "..."]` |
| 4 | 裸通道 | 只有一个 OpenAI 兼容的视觉模型 key | 见下面「最小可用实现」 |

**先探测，再选路**：`command -v dsh-see`、工具列表里有没有 `mcp__vision__*`、
`npx -y @liustack/modlens doctor` 看原生通道。都没有就走第 4 条，别假装能看图。

## 图片参数怎么写

| 来源 | 写法 |
|---|---|
| 本地文件 | `/root/workspace/shot.jpg`、`/sdcard/DCIM/Screenshots/a.png` |
| 聊天里贴的图 | `sha256:<64位hex>`（工具回话给的 `attachment-id:` 去掉前缀直接用） |
| 不知道哪张 | `latest`（取附件库最新一张） |
| 远程图 | `https://...` |

附件库一般在 `$DSH_HOME/attachments/v1/files/`，按 sha256 分两级目录：
`…/files/<前2位>/<完整sha256>/<原文件名>`。找不到就先 `ls -lt` 排一下时间。

## 常用命令（装了 `dsh-see` 时）

```sh
dsh-see latest --ask "这个界面报什么错？"
dsh-see /sdcard/DCIM/Screenshots/a.png --mode ocr
dsh-see long.png --mode ocr --tiles 4
dsh-see a.png b.png --ask "两张图差在哪"
dsh-see shot.png --crop 0,0,1080,240 --mode ocr
dsh-see shot.png --mode ocr_bbox
dsh-see design.png --mode ui
dsh-see chart.png --mode chart
dsh-see img.png --mode inspect
dsh-see img.png --model <模型id> --json
dsh-see-selftest
```

## 模式（提示词模板，谁实现都该有这几档）

| mode | 产出 |
|---|---|
| `auto` | 结构化全量：主体 / 布局 / 图中文字 / 关键数据 |
| `describe` | 自然语言描述 |
| `ocr` | 原样抄出全部文字，不解释 |
| `ocr_bbox` | 原文 + 0–1000 归一化文本框坐标 |
| `ui` | 界面还原：元素、层级、位置、可见文案 |
| `chart` | 图表读数：坐标轴、系列、数值 |
| `inspect` | 质量检查与不确定性清单 |

## 工程要点（自建时按这几条做，能省掉八成坑）

1. **先预处理再送模**：EXIF 摆正、透明压白底、CMYK/P/16bit 归一到 RGB、
   长边默认 1568（大多数视觉模型的有效上限就在这附近），超长截图纵向切块、
   相邻块留 8–10% 重叠，否则跨块的行会被截断成两半。
2. **失败要能切**：多条模型链 + 多条 key 通道，429/5xx/超时各重试 2 次、指数退避。
   视觉模型对同一张图的表现差异很大，切到能读出来为止。
3. **缓存按内容**：`图片哈希 + 模式 + 问题 + 缩放参数` 做键，重复问 0 成本；
   设上限（本机 400 条）自动清理。
4. **密钥单独放**：`env` 文件 600 权限，不进技能目录以外的任何地方，**任何情况下不输出**。
5. **只回文字证据**：让视觉模型输出结论和转录，不要让主模型「猜」图里有什么。

## 最小可用实现（没有任何现成管道时）

任意 OpenAI 兼容的视觉模型都能顶。骨架：

```sh
# 1) 预处理（PIL）：长边 1568，透明压白底，超长图切块
python3 - <<'PY'
from PIL import Image
im = Image.open("in.png").convert("RGBA")
bg = Image.new("RGB", im.size, "white"); bg.paste(im, mask=im.split()[3])
w, h = bg.size; s = 1568 / max(w, h)
if s < 1: bg = bg.resize((int(w*s), int(h*s)), Image.LANCZOS)
bg.save("out.jpg", quality=92)
PY

# 2) 送模（OpenAI 兼容：POST /chat/completions，图片走 base64 data URL）
IMG=$(base64 -w0 out.jpg)
curl -s "$VISION_BASE/chat/completions" \
  -H "Authorization: Bearer $VISION_KEY" -H "Content-Type: application/json" \
  -d "{\"model\":\"$VISION_MODEL\",\"messages\":[{\"role\":\"user\",\"content\":[
        {\"type\":\"text\",\"text\":\"只做 OCR：原样抄出图中全部文字，保留换行，不要解释。\"},
        {\"type\":\"image_url\",\"image_url\":{\"url\":\"data:image/jpeg;base64,$IMG\"}}]}]}" \
  | python3 -c 'import json,sys; print(json.load(sys.stdin)["choices"][0]["message"]["content"])'
```

`VISION_BASE` / `VISION_KEY` / `VISION_MODEL` 三个值来自你自己的服务商，放 `env`，别写进技能或提示词。

可选的模型分工：一个强模型做 `auto/ui/chart`，一个 OCR 专用模型做 `ocr/ocr_bbox`，
读不准时交叉验证——同一个数字两个模型都读成一样才算数。

## 接到 harness 里（两种）

- **MCP（推荐，工具直接可用）**：在 `$DSH_HOME/profiles/web/cordis.patch.yml` 里给 MCP 加条目。
  注意该文件**只能覆盖已有 entry，新增必须写成 `- insert:` 列表**，改完重启 App 才会加载 `mcp__vision__*`。
- **纯 CLI**：把 `dsh-see` 放进 `PATH`。MCP 没起来时命令行功能完全一样，先跑通这条再上 MCP。

## 排障

| 现象 | 原因 |
|---|---|
| `mcp__vision__*` 工具不出现 | profile 改了没重启 App；或 MCP 条目写法不是 `insert:` |
| `dsh-see` 没在 PATH | 安装目录没进 PATH，用绝对路径调 |
| 读出来一片乱码/空 | 图太大被压缩过头、或本来就是低分辨率截图；先 `--crop` 放大局部再读 |
| 同一张图两次结果不同 | 缓存键变了（问题文本、缩放参数变了）；固定参数再比 |
| 原生 modlens 通道不通 | `npx -y @liustack/modlens doctor` 看 resolved route |

## 判断标准

- 图片里有**文字**的任务，一律以 OCR 转录为准，不要凭主模型的「常识」补全数字和编号。
- 视觉模型给的坐标、字段名、界面文案，要当成**证据**引用，不要在转述时加工。
- 拿不准就明说哪一块不确定，别把猜测写成事实。

## 许可与免责

本技能只描述方法，不含任何密钥与账号。视觉模型的调用费用、内容政策、数据去向由你选的服务商决定——
涉及隐私截图、证件、聊天记录时，先确认服务商的数据留存策略再上传。
