#!/usr/bin/env bash
# dsh-go-combined 一键安装（iOS 本机宿主：鱼袋 / dsh-go）
#
#   bash install-ios.sh              # 装到当前 DSH_HOME
#   bash install-ios.sh --check      # 只体检，不动文件
#   bash install-ios.sh --uninstall  # 卸载（保留备份）
#
# 需要一个已经解开的包目录（解压 dsh-go-combined-*.tgz 后的 package/，或 git clone 的仓库根目录）。
# 不加参数时用脚本所在目录的上一级（即仓库根）。
set -euo pipefail

PKG="${PKG:-$(cd "$(dirname "$0")/.." && pwd)}"
DSH_HOME="${DSH_HOME:-$HOME/.dsh}"
PROFILE="$DSH_HOME/profiles/web"
TARGET="$PROFILE/node_modules/dsh-go-combined"
MODE="${1:-install}"

say() { printf '\033[36m›\033[0m %s\n' "$*"; }
ok()  { printf '\033[32m✓\033[0m %s\n' "$*"; }
bad() { printf '\033[31m✗\033[0m %s\n' "$*"; }

[ -f "$PKG/package.json" ] || { bad "找不到 $PKG/package.json，用 PKG=/路径 bash install-ios.sh 指定"; exit 1; }
[ -d "$PROFILE" ] || { bad "没有 $PROFILE —— DSH_HOME 不对？当前 DSH_HOME=$DSH_HOME"; exit 1; }

VER=$(node -e "process.stdout.write(require('$PKG/package.json').version)")
NAME=$(node -e "process.stdout.write(require('$PKG/package.json').name)")
say "包：$NAME@$VER"
say "目标：$TARGET"

# ---- 体检 ----
check() {
  local src="$PKG"; [ -d "$TARGET" ] && src="$TARGET"
  local fail=0
  [ -f "$src/index.js" ] && ok "index.js 在" || { bad "index.js 缺失"; fail=1; }
  local cid
  cid=$(node -e "
    const fs=require('fs');
    const s=fs.readFileSync('$src/lib/client.js','utf8');
    const m=s.match(/__ModuleLoader__\.load\(\{\s*id:\s*\"([^\"]+)\"/);
    process.stdout.write(m?m[1]:'')
  " 2>/dev/null || true)
  if [ "$cid" = "$NAME" ]; then ok "client.js 注册 id = $cid"; else bad "client.js 注册 id ($cid) ≠ 包名 ($NAME) —— 会报 Cannot find package"; fail=1; fi
  local rootref
  rootref=$(grep -c "/root/\.dsh" "$src/cordis.patch.yml" 2>/dev/null || true)
  if [ "${rootref:-0}" -gt 0 ]; then say "cordis.patch.yml 里 $rootref 处 /root/.dsh（安装时会改成 $DSH_HOME）"; else ok "cordis.patch.yml 路径无需修"; fi
  [ "$fail" = 0 ] && ok "体检通过" || bad "体检有问题，见上"
  return $fail
}

if [ "$MODE" = "--check" ] || [ "$MODE" = "check" ]; then check; exit $?; fi

# ---- 卸载 ----
if [ "$MODE" = "--uninstall" ] || [ "$MODE" = "uninstall" ]; then
  if [ -d "$TARGET" ]; then
    mv "$TARGET" "$TARGET.uninstalled-$(date +%m%d%H%M)"
    ok "已移走：$TARGET → $(basename "$TARGET").uninstalled-*"
  else
    say "本来就没装"
  fi
  node -e "
    const fs=require('fs'),p='$PROFILE/package.json';
    const j=JSON.parse(fs.readFileSync(p,'utf8'));
    j.dsh=j.dsh||{}; j.dsh.profile=j.dsh.profile||{};
    j.dsh.profile.bundles=(j.dsh.profile.bundles||[]).filter(x=>x!=='$NAME');
    fs.writeFileSync(p,JSON.stringify(j,null,2)+'\n');
  "
  ok "已从 bundles 名单移除；重启引擎后不再加载"
  exit 0
fi

# ---- 安装 ----
[ -d "$TARGET" ] && { mv "$TARGET" "$TARGET.bak-$(date +%m%d%H%M)"; say "旧版本已备份为 $(basename "$TARGET").bak-*"; }

mkdir -p "$PROFILE/node_modules"
cp -R "$PKG" "$TARGET"
ok "已复制到 node_modules"

# 修 /root/.dsh → 真实 DSH_HOME（iOS 的 HOME 不是 /root）
node -e "
  const fs=require('fs'),f='$TARGET/cordis.patch.yml';
  let s=fs.readFileSync(f,'utf8');
  const n=(s.match(/\/root\/\.dsh/g)||[]).length;
  if(n){fs.writeFileSync(f,s.split('/root/.dsh').join('$DSH_HOME'));console.log('  修正 '+n+' 处 /root/.dsh');}
"

# 登记到 profile 的 bundles 与 dependencies
node -e "
  const fs=require('fs'),p='$PROFILE/package.json';
  const j=JSON.parse(fs.readFileSync(p,'utf8'));
  j.dsh=j.dsh||{}; j.dsh.profile=j.dsh.profile||{};
  const b=j.dsh.profile.bundles=j.dsh.profile.bundles||[];
  if(!b.includes('$NAME')) b.push('$NAME');
  j.dependencies=j.dependencies||{};
  if(!j.dependencies['$NAME']) j.dependencies['$NAME']='file:node_modules/$NAME';
  fs.writeFileSync(p,JSON.stringify(j,null,2)+'\n');
  console.log('  bundles 已包含 $NAME');
"
ok "profile 已登记"

echo
check || true
echo
say "下一步：完全退出 App 再打开（重启引擎）"
say "起来后对话里发「破甲自检」，看注入层/补丁层两层状态"
say "卸载：bash $0 --uninstall"
