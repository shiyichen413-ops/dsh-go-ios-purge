# 发布到 GitHub

```bash
cd dsh-go-combined            # 解包后的目录
git init -b main
git add -A
git commit -m "dsh-go-combined 1.0.0: 合并 dsh-go-purge 注入层与 dsh-go-unrestricted 面板/预设，附 iOS 适配"
git remote add origin git@github.com:<你的账号>/dsh-go-combined.git
git push -u origin main

# 发一个可安装的包（走 npm 或 GitHub Release 都行）
npm publish --access public          # 需要先在 npm 登录
# 或：把 DSH-Go/dsh-go-combined-1.0.0.tgz 上传到 GitHub Release
```

## 许可注意

本包包含 `lib/core/`（来自 **AGPL-3.0** 的 dsh-go-purge），因此整体按 **AGPL-3.0** 发布。
MIT 的那部分（`lib/`、`presets/` 等，来自 dsh-go-unrestricted）可以并入 AGPL，反过来不行。
仓库里 `LICENSE` 放 AGPL-3.0 全文，`NOTICE` 写明两份上游来源与作者。

如果不想背 AGPL：只发 `lib/`、`presets/`、`panel-plugin/`、`skills*/` 那部分（纯 MIT），
注入层让用户自己装 dsh-go-purge，通过 `dsh.profile.bundles` 两个包并存。
